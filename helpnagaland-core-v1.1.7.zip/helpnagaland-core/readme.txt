=== Help Nagaland Core ===
Contributors: nagalandme
Tags: civic, reporting, nagaland, alcohol, drugs
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.1.7
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Core platform for Clean Nagaland, a civic reporting system for alcohol and drug activity in Nagaland. Operated by Nagaland Me.

== Description ==

Help Nagaland Core powers helpnagaland.com, a citizen reporting platform built by Nagaland Me to address alcohol and drug activity in Nagaland. The plugin runs two independent reporting pipelines:

= Alcohol pipeline (public) =

Citizens pin alcohol sale locations on a public map. Every submission requires live GPS and a live camera photo taken at the location. Reports are reviewed by a human moderator before appearing on the public map. Photos are automatically deleted after 30 days to minimize long term liability.

= Drug pipeline (confidential) =

Citizens submit drug activity reports that are never published. Reports flow to the admin only, and optionally to vetted partner organizations. Reporter phone numbers are encrypted with AES-256-GCM in a separate vault and cannot be revealed without deliberate admin action.

= Design principles =

* User safety first: reporter physical safety takes precedence over report completeness.
* Data minimization: the smallest data set for the shortest time.
* Verification through friction: live GPS and live camera are features, not obstacles.
* No individual naming: submissions describe locations and patterns, never people.
* Transparency of outcomes: monthly numbers are published regardless of whether they embarrass anyone.
* Moderation before publication: no automated approval, ever.

= Phase 1 scope =

This release contains the foundation layer: database schema, plugin activation and deactivation handlers, custom roles and capabilities, and the protected uploads directory. Submission forms, moderation dashboards, REST API, and public map rendering are added in later phases.

== Installation ==

1. Upload the entire helpnagaland-core directory to /wp-content/plugins/
2. Activate the plugin through the Plugins screen in WordPress admin
3. On activation the plugin creates its database tables, seeds default options, registers custom roles, and creates the protected uploads directory
4. Review settings once the Settings screen is added in Phase 7
5. Configure a real cron job (see "System cron is required" below). The plugin schedules photo retention, fingerprint cleanup, and other privacy-sensitive jobs through wp_schedule_event, which only fires on incoming traffic. A site without enough traffic during the scheduled window will let private data outlive its documented retention.

== System cron is required ==

The plugin promises retention windows (photos auto-deleted after 30 days, rejected reports purged on schedule, device fingerprints aged out). These promises are only kept if scheduled jobs actually run on time. WP-Cron is traffic-driven and not reliable for this.

On the server, disable WP-Cron and trigger it from system cron instead.

In wp-config.php:

    define( 'DISABLE_WP_CRON', true );

In the system crontab (every 15 minutes is fine):

    */15 * * * * curl -fsS https://helpnagaland.com/wp-cron.php?doing_wp_cron >/dev/null 2>&1

Verify after a day that retention jobs have processed expected rows by checking the audit log.

== Frequently Asked Questions ==

= Does deactivating the plugin delete my data? =

No. Deactivation only unschedules cron events and flushes rewrite rules. All data, tables, options, roles, and uploaded media remain intact. You can re-activate the plugin at any time to resume operation.

= What happens on uninstall? =

Uninstall is a no-op unless you have explicitly enabled data deletion in the Danger Zone settings. Without that explicit opt in, uninstalling the plugin leaves all data intact so you can reinstall later without loss.

= Why does the platform look different from other reporting sites? =

It is designed to look like a civic tool rather than a marketing site. Dark theme, restrained colour palette, no illustrations. The visual language matches the seriousness of the subject matter.

== Changelog ==

= 1.0.0 =
* Initial foundation release. Schema, activation, deactivation, roles, and uninstall handler.
