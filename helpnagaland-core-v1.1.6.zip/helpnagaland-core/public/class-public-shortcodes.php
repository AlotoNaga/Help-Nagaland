<?php
/**
 * Public Shortcodes: five shortcodes that render the reporter-facing UI.
 *
 *   [hnc_alcohol_form]        Live GPS + live camera alcohol submission form.
 *   [hnc_drug_form]           Optional media + optional phone drug form.
 *   [hnc_alcohol_map]         Public map with approved alcohol pins.
 *   [hnc_status_check]        Input a tracking code, see status.
 *   [hnc_transparency_page]   Published monthly transparency snapshots.
 *
 * Each shortcode renders a static HTML scaffold with a data-hnc-screen
 * attribute. The real work (fetching data, submitting, rendering rows)
 * happens in the matching JS module loaded by HNC_Public_Enqueue.
 *
 * Design rules:
 *   - Shortcodes render HTML ONLY. They do not call any REST endpoint
 *     at PHP render time. This keeps page caching working.
 *   - HTML is escaped via esc_html/esc_attr. JS-rendered content is
 *     escaped in the JS module (see public-common.js ui.esc).
 *   - Killswitch state is rendered server-side AS DATA ATTRIBUTE only.
 *     JS reads it and shows an appropriate message. This avoids an
 *     extra roundtrip on page load.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Public_Shortcodes
 */
final class HNC_Public_Shortcodes {


	const SC_ALCOHOL_FORM = 'hnc_alcohol_form';
	const SC_DRUG_FORM    = 'hnc_drug_form';
	const SC_ALCOHOL_MAP  = 'hnc_alcohol_map';
	const SC_STATUS_CHECK = 'hnc_status_check';
	const SC_TRANSPARENCY = 'hnc_transparency_page';


	/**
	 * Register all shortcodes.
	 *
	 * @return void
	 */
	public static function init() {
		add_shortcode( self::SC_ALCOHOL_FORM, array( __CLASS__, 'render_alcohol_form' ) );
		add_shortcode( self::SC_DRUG_FORM,    array( __CLASS__, 'render_drug_form' ) );
		add_shortcode( self::SC_ALCOHOL_MAP,  array( __CLASS__, 'render_alcohol_map' ) );
		add_shortcode( self::SC_STATUS_CHECK, array( __CLASS__, 'render_status_check' ) );
		add_shortcode( self::SC_TRANSPARENCY, array( __CLASS__, 'render_transparency' ) );
	}


	/* ------------------------------------------------------------------
	 * ALCOHOL FORM
	 * ------------------------------------------------------------------ */

	/**
	 * [hnc_alcohol_form] shortcode.
	 *
	 * Attributes:
	 *   - title       Heading text. Default "Report an alcohol location".
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public static function render_alcohol_form( $atts ) {
		$atts = shortcode_atts(
			array(
				'title' => __( 'Report an alcohol location', 'helpnagaland-core' ),
			),
			is_array( $atts ) ? $atts : array(),
			self::SC_ALCOHOL_FORM
		);

		$districts  = self::districts();
		$categories = self::categories( 'alcohol' );
		$patterns   = self::time_patterns();

		ob_start();
		?>
		<div class="hnc-public-wrap" data-hnc-screen="alcohol-form">
			<h2 class="hnc-public-title"><?php echo esc_html( $atts['title'] ); ?></h2>

			<p class="hnc-public-intro"><?php esc_html_e( 'Your report is anonymous. You will need to be physically at the location, with GPS and camera enabled, to submit. Photos are used for moderation only and are deleted 30 days after approval.', 'helpnagaland-core' ); ?></p>

			<div class="hnc-ks-banner" data-hnc-ks-banner hidden>
				<strong><?php esc_html_e( 'Submissions are temporarily paused.', 'helpnagaland-core' ); ?></strong>
				<span data-hnc-ks-message></span>
			</div>

			<form class="hnc-form" data-hnc-form="alcohol" novalidate>
				<?php self::render_honeypot_field(); ?>
				<input type="hidden" name="device_fingerprint" data-hnc-fp value="" />
				<input type="hidden" name="time_on_form_seconds" data-hnc-timer value="0" />

				<div class="hnc-field">
					<label><?php esc_html_e( 'District', 'helpnagaland-core' ); ?></label>
					<select name="district" required>
						<option value=""><?php esc_html_e( 'Select a district', 'helpnagaland-core' ); ?></option>
						<?php foreach ( $districts as $d ) : ?>
							<option value="<?php echo esc_attr( $d ); ?>"><?php echo esc_html( $d ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>

				<div class="hnc-field">
					<label><?php esc_html_e( 'Category', 'helpnagaland-core' ); ?></label>
					<select name="category" required>
						<option value=""><?php esc_html_e( 'Select a category', 'helpnagaland-core' ); ?></option>
						<?php foreach ( $categories as $key => $label ) : ?>
							<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>

				<div class="hnc-field">
					<label><?php esc_html_e( 'Time pattern', 'helpnagaland-core' ); ?></label>
					<select name="time_pattern" required>
						<option value=""><?php esc_html_e( 'Select a time pattern', 'helpnagaland-core' ); ?></option>
						<?php foreach ( $patterns as $key => $label ) : ?>
							<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>

				<div class="hnc-field">
					<label><?php esc_html_e( 'Short description (optional)', 'helpnagaland-core' ); ?></label>
					<textarea name="description" maxlength="400" rows="3" placeholder="<?php esc_attr_e( 'Optional. What did you see? No names, no phone numbers.', 'helpnagaland-core' ); ?>"></textarea>
					<small class="hnc-field-hint"><?php esc_html_e( 'Optional. Max 400 characters. Do not include names or phone numbers.', 'helpnagaland-core' ); ?></small>
				</div>

				<fieldset class="hnc-field-group" data-hnc-gps>
					<legend><?php esc_html_e( 'Your location', 'helpnagaland-core' ); ?></legend>
					<p class="hnc-gps-status" data-hnc-gps-status><?php esc_html_e( 'Location not captured yet.', 'helpnagaland-core' ); ?></p>
					<button type="button" class="hnc-btn hnc-btn-secondary" data-hnc-gps-btn><?php esc_html_e( 'Capture GPS', 'helpnagaland-core' ); ?></button>
					<input type="hidden" name="lat" data-hnc-lat value="" />
					<input type="hidden" name="lng" data-hnc-lng value="" />
					<input type="hidden" name="gps_accuracy" data-hnc-acc value="" />
				</fieldset>

				<fieldset class="hnc-field-group" data-hnc-camera>
					<legend><?php esc_html_e( 'Live photo', 'helpnagaland-core' ); ?></legend>
					<p class="hnc-field-hint"><?php esc_html_e( 'Photo must be taken right now with your camera. Gallery uploads are not accepted.', 'helpnagaland-core' ); ?></p>
					<div class="hnc-camera-stage">
						<video class="hnc-camera-video" data-hnc-camera-video playsinline muted hidden></video>
						<canvas class="hnc-camera-canvas" data-hnc-camera-canvas hidden></canvas>
						<img class="hnc-camera-preview" data-hnc-camera-preview alt="" hidden />
					</div>
					<div class="hnc-camera-controls">
						<button type="button" class="hnc-btn hnc-btn-secondary" data-hnc-camera-start><?php esc_html_e( 'Open camera', 'helpnagaland-core' ); ?></button>
						<button type="button" class="hnc-btn hnc-btn-secondary" data-hnc-camera-flip hidden aria-label="<?php esc_attr_e( 'Flip camera', 'helpnagaland-core' ); ?>"><?php esc_html_e( 'Flip camera', 'helpnagaland-core' ); ?></button>
						<button type="button" class="hnc-btn hnc-btn-primary" data-hnc-camera-capture hidden><?php esc_html_e( 'Capture', 'helpnagaland-core' ); ?></button>
						<button type="button" class="hnc-btn hnc-btn-secondary" data-hnc-camera-retry hidden><?php esc_html_e( 'Retake', 'helpnagaland-core' ); ?></button>
					</div>
					<input type="hidden" name="photo_timestamp" data-hnc-photo-ts value="" />
				</fieldset>

				<div class="hnc-field">
					<label class="hnc-check">
						<input type="checkbox" required data-hnc-terms />
						<?php esc_html_e( 'I confirm I am physically at this location, the photo is live, and I have no names or phone numbers in my description.', 'helpnagaland-core' ); ?>
					</label>
				</div>

				<button type="submit" class="hnc-btn hnc-btn-primary hnc-btn-submit" data-hnc-submit disabled>
					<?php esc_html_e( 'Submit report', 'helpnagaland-core' ); ?>
				</button>

				<div class="hnc-result" data-hnc-result hidden role="status" aria-live="polite" aria-atomic="true"></div>
			</form>
		</div>
		<?php
		return ob_get_clean();
	}


	/* ------------------------------------------------------------------
	 * DRUG FORM
	 * ------------------------------------------------------------------ */

	/**
	 * [hnc_drug_form] shortcode.
	 *
	 * @param array $atts Attributes.
	 * @return string
	 */
	public static function render_drug_form( $atts ) {
		$atts = shortcode_atts(
			array(
				'title' => __( 'Report drug activity', 'helpnagaland-core' ),
			),
			is_array( $atts ) ? $atts : array(),
			self::SC_DRUG_FORM
		);

		$districts  = self::districts();
		$categories = self::categories( 'drug' );

		ob_start();
		?>
		<div class="hnc-public-wrap hnc-drug-wrap" data-hnc-screen="drug-form">
			<h2 class="hnc-public-title"><?php echo esc_html( $atts['title'] ); ?></h2>

			<div class="hnc-confidential-banner">
				<strong><?php esc_html_e( 'Your report is confidential.', 'helpnagaland-core' ); ?></strong>
				<p><?php esc_html_e( 'Drug reports never appear on any public map. No GPS is needed. No live photo is needed. Your report stays with the Nagaland Me moderation team and, if you consent, trusted partners.', 'helpnagaland-core' ); ?></p>
			</div>

			<div class="hnc-ks-banner" data-hnc-ks-banner hidden>
				<strong><?php esc_html_e( 'Submissions are temporarily paused.', 'helpnagaland-core' ); ?></strong>
				<span data-hnc-ks-message></span>
			</div>

			<form class="hnc-form" data-hnc-form="drug" novalidate enctype="multipart/form-data">
				<?php self::render_honeypot_field(); ?>
				<input type="hidden" name="device_fingerprint" data-hnc-fp value="" />
				<input type="hidden" name="time_on_form_seconds" data-hnc-timer value="0" />

				<div class="hnc-field">
					<label><?php esc_html_e( 'District', 'helpnagaland-core' ); ?></label>
					<select name="district" required>
						<option value=""><?php esc_html_e( 'Select a district', 'helpnagaland-core' ); ?></option>
						<?php foreach ( $districts as $d ) : ?>
							<option value="<?php echo esc_attr( $d ); ?>"><?php echo esc_html( $d ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>

				<div class="hnc-field">
					<label><?php esc_html_e( 'Category', 'helpnagaland-core' ); ?></label>
					<select name="category" required>
						<option value=""><?php esc_html_e( 'Select a category', 'helpnagaland-core' ); ?></option>
						<?php foreach ( $categories as $key => $label ) : ?>
							<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>

				<div class="hnc-field">
					<label><?php esc_html_e( 'Area description', 'helpnagaland-core' ); ?></label>
					<textarea name="area_desc" required maxlength="500" rows="3" placeholder="<?php esc_attr_e( 'Where is this happening? Describe the area. Do not use names.', 'helpnagaland-core' ); ?>"></textarea>
					<small class="hnc-field-hint"><?php esc_html_e( 'Max 500 characters. Do not include names, phone numbers, or house numbers.', 'helpnagaland-core' ); ?></small>
				</div>

				<div class="hnc-field">
					<label><?php esc_html_e( 'Pattern of activity', 'helpnagaland-core' ); ?></label>
					<textarea name="pattern" required maxlength="400" rows="2" placeholder="<?php esc_attr_e( 'When? How often? Who seems to be involved (without names)?', 'helpnagaland-core' ); ?>"></textarea>
				</div>

				<div class="hnc-field">
					<label><?php esc_html_e( 'Vehicles involved (optional)', 'helpnagaland-core' ); ?></label>
					<input type="text" name="vehicle_info" maxlength="200" placeholder="<?php esc_attr_e( 'Color, type. Partial plate if you remember it.', 'helpnagaland-core' ); ?>" />
				</div>

				<div class="hnc-field">
					<label><?php esc_html_e( 'Media (optional)', 'helpnagaland-core' ); ?></label>
					<input type="file" name="media" accept="image/jpeg,image/png,image/webp,video/mp4,video/quicktime" data-hnc-media-input />
					<small class="hnc-field-hint"><?php esc_html_e( 'Photos or short videos. Gallery uploads are OK. Will be deleted 90 days after resolution.', 'helpnagaland-core' ); ?></small>
				</div>

				<fieldset class="hnc-field-group">
					<legend><?php esc_html_e( 'Contact mode', 'helpnagaland-core' ); ?></legend>
					<label class="hnc-check">
						<input type="radio" name="submission_mode" value="anonymous" checked data-hnc-mode />
						<?php esc_html_e( 'Anonymous. Do not contact me.', 'helpnagaland-core' ); ?>
					</label>
					<label class="hnc-check">
						<input type="radio" name="submission_mode" value="phone" data-hnc-mode />
						<?php esc_html_e( 'I want the moderation team to be able to call me for follow-up.', 'helpnagaland-core' ); ?>
					</label>
				</fieldset>

				<div class="hnc-phone-block" data-hnc-phone-block hidden>
					<div class="hnc-field">
						<label><?php esc_html_e( 'Phone number', 'helpnagaland-core' ); ?></label>
						<input type="tel" name="phone" pattern="[+0-9 ]{10,15}" placeholder="+91 98765 43210" />
						<small class="hnc-field-hint"><?php esc_html_e( 'Encrypted in the vault. Never sent to anyone without your second confirmation.', 'helpnagaland-core' ); ?></small>
					</div>
					<div class="hnc-field">
						<label class="hnc-check">
							<input type="checkbox" name="phone_consent" value="1" data-hnc-phone-consent />
							<?php esc_html_e( 'I consent to being contacted by the Nagaland Me moderation team about this report.', 'helpnagaland-core' ); ?>
						</label>
					</div>
				</div>

				<button type="submit" class="hnc-btn hnc-btn-primary hnc-btn-submit" data-hnc-submit>
					<?php esc_html_e( 'Submit report', 'helpnagaland-core' ); ?>
				</button>

				<div class="hnc-result" data-hnc-result hidden role="status" aria-live="polite" aria-atomic="true"></div>
			</form>
		</div>
		<?php
		return ob_get_clean();
	}


	/* ------------------------------------------------------------------
	 * ALCOHOL MAP
	 * ------------------------------------------------------------------ */

	/**
	 * [hnc_alcohol_map] shortcode.
	 *
	 * Attributes:
	 *   - height   Map height in px. Default 520.
	 *
	 * @param array $atts Attributes.
	 * @return string
	 */
	public static function render_alcohol_map( $atts ) {
		$atts = shortcode_atts(
			array(
				'height' => 520,
			),
			is_array( $atts ) ? $atts : array(),
			self::SC_ALCOHOL_MAP
		);
		$height = max( 300, min( 1200, (int) $atts['height'] ) );

		ob_start();
		?>
		<div class="hnc-public-wrap hnc-map-wrap" data-hnc-screen="alcohol-map">
			<div class="hnc-map-header">
				<h2 class="hnc-public-title"><?php esc_html_e( 'Alcohol locations reported', 'helpnagaland-core' ); ?></h2>
				<p class="hnc-field-hint"><?php esc_html_e( 'Pins show approved reports snapped to a 50-meter grid. Similar reports within 100 meters are merged.', 'helpnagaland-core' ); ?></p>
			</div>

			<div class="hnc-map-filters">
				<select data-hnc-map-filter="district">
					<option value=""><?php esc_html_e( 'All districts', 'helpnagaland-core' ); ?></option>
					<?php foreach ( self::districts() as $d ) : ?>
						<option value="<?php echo esc_attr( $d ); ?>"><?php echo esc_html( $d ); ?></option>
					<?php endforeach; ?>
				</select>
				<select data-hnc-map-filter="category">
					<option value=""><?php esc_html_e( 'All categories', 'helpnagaland-core' ); ?></option>
					<?php foreach ( self::categories( 'alcohol' ) as $key => $label ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>

			<div class="hnc-map-canvas" style="height: <?php echo esc_attr( $height ); ?>px;" data-hnc-map></div>
			<div class="hnc-map-loading" data-hnc-map-loading><?php esc_html_e( 'Loading map...', 'helpnagaland-core' ); ?></div>
			<div class="hnc-map-count" data-hnc-map-count></div>
		</div>
		<?php
		return ob_get_clean();
	}


	/* ------------------------------------------------------------------
	 * STATUS CHECK
	 * ------------------------------------------------------------------ */

	/**
	 * [hnc_status_check] shortcode.
	 *
	 * @param array $atts Attributes.
	 * @return string
	 */
	public static function render_status_check( $atts ) {
		$atts = shortcode_atts(
			array(
				'title' => __( 'Check your report status', 'helpnagaland-core' ),
			),
			is_array( $atts ) ? $atts : array(),
			self::SC_STATUS_CHECK
		);

		ob_start();
		?>
		<div class="hnc-public-wrap hnc-status-wrap" data-hnc-screen="status-check">
			<h2 class="hnc-public-title"><?php echo esc_html( $atts['title'] ); ?></h2>
			<p class="hnc-field-hint"><?php esc_html_e( 'Enter the 8-character tracking code you received when you submitted the report.', 'helpnagaland-core' ); ?></p>

			<form class="hnc-form hnc-status-form" data-hnc-status-form novalidate>
				<div class="hnc-field">
					<label><?php esc_html_e( 'Tracking code', 'helpnagaland-core' ); ?></label>
					<input type="text" name="code" required maxlength="9" placeholder="ABCD-EFGH" data-hnc-status-code autocomplete="off" />
				</div>

				<fieldset class="hnc-field-group">
					<legend><?php esc_html_e( 'Report type', 'helpnagaland-core' ); ?></legend>
					<label class="hnc-check">
						<input type="radio" name="report_type" value="alcohol" checked />
						<?php esc_html_e( 'Alcohol', 'helpnagaland-core' ); ?>
					</label>
					<label class="hnc-check">
						<input type="radio" name="report_type" value="drug" />
						<?php esc_html_e( 'Drug', 'helpnagaland-core' ); ?>
					</label>
				</fieldset>

				<button type="submit" class="hnc-btn hnc-btn-primary"><?php esc_html_e( 'Check status', 'helpnagaland-core' ); ?></button>
			</form>

			<div class="hnc-status-result" data-hnc-status-result hidden role="status" aria-live="polite" aria-atomic="true"></div>
		</div>
		<?php
		return ob_get_clean();
	}


	/* ------------------------------------------------------------------
	 * TRANSPARENCY PAGE
	 * ------------------------------------------------------------------ */

	/**
	 * [hnc_transparency_page] shortcode.
	 *
	 * @param array $atts Attributes.
	 * @return string
	 */
	public static function render_transparency( $atts ) {
		$atts = shortcode_atts(
			array(
				'title' => __( 'Monthly transparency report', 'helpnagaland-core' ),
			),
			is_array( $atts ) ? $atts : array(),
			self::SC_TRANSPARENCY
		);

		ob_start();
		?>
		<div class="hnc-public-wrap hnc-transparency-wrap" data-hnc-screen="transparency">
			<h2 class="hnc-public-title"><?php echo esc_html( $atts['title'] ); ?></h2>
			<p class="hnc-field-hint"><?php esc_html_e( 'Published on the 1st of every month. Numbers are aggregate only; no individual report is identifiable.', 'helpnagaland-core' ); ?></p>

			<div class="hnc-transparency-downloads">
				<a href="<?php echo esc_url( rest_url( HNC_API_NAMESPACE . '/transparency/export/csv' ) ); ?>" class="hnc-btn hnc-btn-secondary" download><?php esc_html_e( 'Download all as CSV', 'helpnagaland-core' ); ?></a>
				<a href="<?php echo esc_url( rest_url( HNC_API_NAMESPACE . '/transparency/export/json' ) ); ?>" class="hnc-btn hnc-btn-secondary" target="_blank" rel="noopener"><?php esc_html_e( 'View as JSON', 'helpnagaland-core' ); ?></a>
			</div>

			<div class="hnc-transparency-list" data-hnc-transparency-list>
				<p class="hnc-transparency-loading"><?php esc_html_e( 'Loading...', 'helpnagaland-core' ); ?></p>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}


	/* ------------------------------------------------------------------
	 * SHARED HELPERS
	 * ------------------------------------------------------------------ */

	/**
	 * Render the honeypot field. Browsers and humans do not see this;
	 * many bots fill every input they find and get caught server-side.
	 *
	 * @return void
	 */
	private static function render_honeypot_field() {
		echo '<div style="position:absolute;left:-9999px;top:-9999px;" aria-hidden="true">';
		echo '<label>' . esc_html__( 'Do not fill this field', 'helpnagaland-core' ) . '</label>';
		echo '<input type="text" name="hnc_hp" tabindex="-1" autocomplete="off" />';
		echo '</div>';
	}

	/**
	 * Return the district list from the option.
	 *
	 * @return array
	 */
	private static function districts() {
		$raw  = get_option( 'hnc_districts', '[]' );
		$list = json_decode( (string) $raw, true );
		return is_array( $list ) ? $list : array();
	}

	/**
	 * Return categories (alcohol or drug) from the option.
	 *
	 * @param string $pipeline 'alcohol' or 'drug'.
	 * @return array
	 */
	private static function categories( $pipeline ) {
		$key  = ( 'drug' === $pipeline ) ? 'hnc_drug_categories' : 'hnc_alcohol_categories';
		$raw  = get_option( $key, '{}' );
		$list = json_decode( (string) $raw, true );
		return is_array( $list ) ? $list : array();
	}

	/**
	 * Return time patterns for the alcohol form.
	 *
	 * @return array
	 */
	private static function time_patterns() {
		$raw = get_option( 'hnc_time_patterns', '' );
		if ( '' !== $raw ) {
			$list = json_decode( (string) $raw, true );
			if ( is_array( $list ) ) {
				return $list;
			}
		}
		return array(
			'morning'   => __( 'Morning (6am to 12pm)', 'helpnagaland-core' ),
			'afternoon' => __( 'Afternoon (12pm to 5pm)', 'helpnagaland-core' ),
			'evening'   => __( 'Evening (5pm to 9pm)', 'helpnagaland-core' ),
			'night'     => __( 'Night (9pm to midnight)', 'helpnagaland-core' ),
			'late'      => __( 'Late night (midnight to 6am)', 'helpnagaland-core' ),
			'all_day'   => __( 'All day', 'helpnagaland-core' ),
		);
	}

	/**
	 * Check whether any HNC shortcode is present in the given content.
	 * Used by HNC_Public_Enqueue to conditionally load assets.
	 *
	 * @param string $content Post content.
	 * @return array { alcohol_form, drug_form, alcohol_map, status_check, transparency }
	 */
	public static function detect_shortcodes( $content ) {
		$out = array(
			'alcohol_form' => false,
			'drug_form'    => false,
			'alcohol_map'  => false,
			'status_check' => false,
			'transparency' => false,
		);
		if ( ! is_string( $content ) || '' === $content ) {
			return $out;
		}
		$out['alcohol_form'] = has_shortcode( $content, self::SC_ALCOHOL_FORM );
		$out['drug_form']    = has_shortcode( $content, self::SC_DRUG_FORM );
		$out['alcohol_map']  = has_shortcode( $content, self::SC_ALCOHOL_MAP );
		$out['status_check'] = has_shortcode( $content, self::SC_STATUS_CHECK );
		$out['transparency'] = has_shortcode( $content, self::SC_TRANSPARENCY );
		return $out;
	}

	/**
	 * Return true if any HNC shortcode is present.
	 *
	 * @param string $content Content.
	 * @return bool
	 */
	public static function has_any_shortcode( $content ) {
		$d = self::detect_shortcodes( $content );
		foreach ( $d as $v ) {
			if ( $v ) {
				return true;
			}
		}
		return false;
	}
}
