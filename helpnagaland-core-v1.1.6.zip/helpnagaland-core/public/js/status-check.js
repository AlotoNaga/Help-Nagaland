/**
 * status-check.js — look up a report by tracking code.
 *
 * Normalises the code client-side (uppercase, strip non-alphanumerics,
 * re-insert the dash) so a reporter who typed 'abcdefgh' or 'abcd efgh'
 * still gets a valid lookup. The server does its own normalisation.
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var forms = document.querySelectorAll('[data-hnc-status-form]');
		forms.forEach(initForm);
	});

	function normalizeCode(raw) {
		var s = String(raw || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
		if (s.length !== 8) return '';
		return s.slice(0, 4) + '-' + s.slice(4);
	}

	function initForm(form) {
		var HNC    = window.HNC_PUBLIC;
		var result = form.parentElement.querySelector('[data-hnc-status-result]');
		var codeIn = form.querySelector('[data-hnc-status-code]');
		var typeInputs = form.querySelectorAll('[name="report_type"]');

		form.addEventListener('submit', function (e) {
			e.preventDefault();
			var raw  = codeIn ? codeIn.value : '';
			var code = normalizeCode(raw);
			if (!code) {
				HNC.ui.showResult(result, '<p>' + HNC.ui.esc(HNC.i18n.invalid_code_format) + '</p>', 'error');
				return;
			}
			var reportType = 'alcohol';
			for (var i = 0; i < typeInputs.length; i++) {
				if (typeInputs[i].checked) { reportType = typeInputs[i].value; }
			}

			var path = (reportType === 'drug' ? 'drug/status/' : 'alcohol/status/') + encodeURIComponent(code);
			HNC.api.get(path).then(function (resp) {
				var d = (resp && resp.data) || {};
				HNC.ui.showResult(result, renderAlcoholOrDrug(d, reportType), 'info');
			}).catch(function (err) {
				if (err && err.status === 404) {
					HNC.ui.showResult(result, '<p>' + HNC.ui.esc(HNC.i18n.status_not_found) + '</p>', 'error');
				} else {
					HNC.ui.showResult(result, '<p>' + HNC.ui.esc(HNC.ui.translateError(err)) + '</p>', 'error');
				}
			});
		});
	}

	function renderAlcoholOrDrug(d, reportType) {
		var HNC = window.HNC_PUBLIC;
		var label = statusLabel(d.status);
		var rows = [];

		rows.push('<p><strong>' + HNC.ui.esc(HNC.i18n.tracking_code_is) + '</strong> <code class="hnc-code">' + HNC.ui.esc(d.code || '') + '</code></p>');
		rows.push('<p><strong>Status:</strong> ' + HNC.ui.esc(label) + '</p>');

		if (reportType === 'alcohol') {
			if (d.district)      rows.push('<p><strong>District:</strong> ' + HNC.ui.esc(d.district) + '</p>');
			if (d.category)      rows.push('<p><strong>Category:</strong> ' + HNC.ui.esc(d.category) + '</p>');
			if (d.verified_by_operator) {
				rows.push('<p><em>' + HNC.ui.esc(HNC.i18n.reports_verified_by_operator || 'Verified by operator site visit') + '</em></p>');
			}
			if (d.report_count) {
				rows.push('<p><strong>' + HNC.ui.esc(HNC.i18n.total_reports || 'Total reports:') + '</strong> ' + HNC.ui.esc(d.report_count) + '</p>');
			}
			if (d.rejection_reason) {
				rows.push('<p><strong>Reason:</strong> ' + HNC.ui.esc(d.rejection_reason) + '</p>');
			}
		}

		if (d.submitted_at) {
			rows.push('<p class="hnc-field-hint"><strong>Submitted:</strong> ' + HNC.ui.esc(d.submitted_at) + ' UTC</p>');
		}
		return rows.join('');
	}

	function statusLabel(s) {
		var i = (window.HNC_PUBLIC && window.HNC_PUBLIC.i18n) || {};
		switch (s) {
			case 'received':  return i.status_received  || 'Received';
			case 'pending':   return i.status_received  || 'Received';
			case 'approved':  return i.status_approved  || 'Approved';
			case 'rejected':  return i.status_rejected  || 'Rejected';
			case 'hold':      return i.status_hold      || 'Hold';
			case 'archived':  return i.status_archived  || 'Archived';
			case 'resolved':  return i.status_resolved  || 'Resolved';
			case 'acted_on':  return i.status_acted_on  || 'Acted on';
			case 'closed':    return i.status_closed    || 'Closed';
			default:          return s || '';
		}
	}
}());
