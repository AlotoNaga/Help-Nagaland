/**
 * transparency.js — renders the published monthly snapshot list.
 *
 * Consumes GET /hnc/v1/transparency. Renders one card per published
 * month. Each card has four alcohol numbers + four drug numbers, the
 * publish date, the optional admin note, and a per-month CSV download
 * link.
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var wraps = document.querySelectorAll('[data-hnc-screen="transparency"]');
		wraps.forEach(initTransparency);
	});

	function initTransparency(wrap) {
		var HNC  = window.HNC_PUBLIC;
		var list = wrap.querySelector('[data-hnc-transparency-list]');
		if (!list) return;

		HNC.api.get('transparency').then(function (resp) {
			var rows = (resp && resp.data) || [];
			if (!Array.isArray(rows) || rows.length === 0) {
				list.innerHTML = '<p class="hnc-field-hint">' + HNC.ui.esc(HNC.i18n.no_results || 'No published snapshots yet.') + '</p>';
				return;
			}
			list.innerHTML = rows.map(renderCard).join('');
		}).catch(function (err) {
			list.innerHTML = '<p class="hnc-field-hint">' + HNC.ui.esc(HNC.ui.translateError(err)) + '</p>';
		});
	}

	function renderCard(row) {
		var HNC = window.HNC_PUBLIC;
		var esc = HNC.ui.esc;
		var i   = HNC.i18n;
		var cfg = HNC.config || {};
		var base = cfg.rest_url || '/wp-json/hnc/v1/';
		var csvUrl = base + 'transparency/export/csv/' + encodeURIComponent(row.year) + '/' + encodeURIComponent(row.month);

		var alcohol = row.alcohol || {};
		var drug    = row.drug || {};

		return '' +
			'<div class="hnc-transparency-card">' +
				'<h3 class="hnc-transparency-period">' + esc(row.period || (row.year + '-' + String(row.month).padStart(2, '0'))) + '</h3>' +
				'<div class="hnc-transparency-grid">' +
					'<div class="hnc-transparency-col">' +
						'<h4>' + esc(i.alcohol || 'Alcohol') + '</h4>' +
						'<ul>' +
							'<li>' + esc(alcohol.received || 0) + ' ' + esc(i.received || 'received') + '</li>' +
							'<li>' + esc(alcohol.approved || 0) + ' ' + esc(i.approved || 'approved') + '</li>' +
							'<li>' + esc(alcohol.rejected || 0) + ' ' + esc(i.rejected || 'rejected') + '</li>' +
							'<li>' + esc(alcohol.acted_by_police || 0) + ' ' + esc(i.acted_police || 'acted on by police') + '</li>' +
						'</ul>' +
					'</div>' +
					'<div class="hnc-transparency-col">' +
						'<h4>' + esc(i.drug || 'Drug') + '</h4>' +
						'<ul>' +
							'<li>' + esc(drug.received || 0) + ' ' + esc(i.received || 'received') + '</li>' +
							'<li>' + esc(drug.approved || 0) + ' ' + esc(i.approved || 'approved') + '</li>' +
							'<li>' + esc(drug.forwarded || 0) + ' ' + esc(i.forwarded || 'forwarded') + '</li>' +
							'<li>' + esc(drug.acted || 0) + ' ' + esc(i.status_acted_on || 'acted on') + '</li>' +
						'</ul>' +
					'</div>' +
				'</div>' +
				(row.note ? '<p class="hnc-transparency-note">' + esc(row.note) + '</p>' : '') +
				'<p class="hnc-transparency-meta">' +
					'<span>Published ' + esc(row.published_at || '') + ' UTC</span> · ' +
					'<a href="' + esc(csvUrl) + '" download>' + esc(i.download_csv || 'Download CSV') + '</a>' +
				'</p>' +
			'</div>';
	}
}());
