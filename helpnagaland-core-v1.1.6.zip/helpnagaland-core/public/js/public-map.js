/**
 * public-map.js — Leaflet map of approved alcohol pins.
 *
 * Consumes GET /hnc/v1/alcohol/pins. Renders each pin as a marker.
 * Pins with verified_by_operator get a distinct style. Clicking a pin
 * opens a popup with district, category, report count, and a link to
 * check the status by tracking code.
 *
 * Leaflet is loaded by the enqueue layer before this script runs, so
 * `L` is a global by the time DOMContentLoaded fires.
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var wraps = document.querySelectorAll('[data-hnc-screen="alcohol-map"]');
		wraps.forEach(initMap);
	});

	function initMap(wrap) {
		var HNC = window.HNC_PUBLIC;
		if (!HNC || typeof L === 'undefined') return;

		var mapEl    = wrap.querySelector('[data-hnc-map]');
		var loading  = wrap.querySelector('[data-hnc-map-loading]');
		var countEl  = wrap.querySelector('[data-hnc-map-count]');
		var district = wrap.querySelector('[data-hnc-map-filter="district"]');
		var category = wrap.querySelector('[data-hnc-map-filter="category"]');

		if (!mapEl) return;

		// Default center: Dimapur area. Close enough to the populated
		// regions of Nagaland that the default view always has some
		// markers in frame.
		var map = L.map(mapEl, { scrollWheelZoom: false }).setView([25.9, 93.8], 9);

		L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
			maxZoom: 18,
			attribution: '© OpenStreetMap contributors'
		}).addTo(map);

		var layerGroup = L.layerGroup().addTo(map);

		function load() {
			if (loading) { loading.hidden = false; }
			var params = new URLSearchParams();
			if (district && district.value) params.set('district', district.value);
			if (category && category.value) params.set('category', category.value);
			var qs = params.toString();
			var path = 'alcohol/pins' + (qs ? ('?' + qs) : '');

			HNC.api.get(path).then(function (resp) {
				layerGroup.clearLayers();
				var pins = (resp && resp.data && resp.data.pins) || [];
				var bounds = [];

				pins.forEach(function (p) {
					if (typeof p.lat !== 'number' || typeof p.lng !== 'number') return;
					var verified = !!p.verified_by_operator;
					var marker = L.circleMarker([p.lat, p.lng], {
						radius: verified ? 10 : 7,
						color: verified ? '#F5C518' : '#10B981',
						weight: 2,
						fillColor: verified ? '#F5C518' : '#10B981',
						fillOpacity: 0.75
					});

					var popup =
						'<div class="hnc-popup">' +
						'<strong>' + HNC.ui.esc(p.district || '') + '</strong><br>' +
						HNC.ui.esc(p.category_label || p.category || '') + '<br>' +
						HNC.ui.esc((p.report_count || 1) + ' ' + (HNC.i18n.total_reports || 'reports')) +
						(verified ? '<br><em>' + HNC.ui.esc(HNC.i18n.reports_verified_by_operator || 'Verified') + '</em>' : '') +
						'</div>';
					marker.bindPopup(popup);
					marker.addTo(layerGroup);
					bounds.push([p.lat, p.lng]);
				});

				if (countEl) {
					countEl.textContent = (pins.length === 1)
						? '1 pin shown.'
						: (pins.length + ' pins shown.');
				}
				if (bounds.length > 0) {
					map.fitBounds(bounds, { padding: [40, 40], maxZoom: 13 });
				}
				if (loading) { loading.hidden = true; }
			}).catch(function () {
				if (loading) { loading.hidden = true; }
				if (countEl) { countEl.textContent = HNC.i18n.loading || ''; }
			});
		}

		if (district) district.addEventListener('change', load);
		if (category) category.addEventListener('change', load);
		load();
	}
}());
