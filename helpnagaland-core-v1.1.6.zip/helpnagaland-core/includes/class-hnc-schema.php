<?php
/**
 * Database schema for Help Nagaland Core.
 *
 * All CREATE TABLE statements live in this file. When the schema needs to
 * change, you:
 *
 *   1. Modify the CREATE TABLE statement(s) below.
 *   2. Bump HNC_DB_VERSION in helpnagaland-core.php.
 *   3. On next page load, the main bootstrap detects the version mismatch and
 *      calls HNC_Schema::install() which runs dbDelta to apply the changes.
 *
 * dbDelta is idempotent when used correctly, but it is also picky about
 * formatting. The rules are:
 *
 *   - Each column on its own line.
 *   - Use KEY not INDEX for secondary indexes.
 *   - Two spaces between "PRIMARY KEY" and the column definition.
 *   - No backticks around column or table names.
 *   - No FOREIGN KEY constraints (dbDelta drops them silently).
 *
 * Foreign key style relationships are enforced in PHP code at the model layer
 * rather than at the database layer. This matches the WordPress convention.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Schema
 *
 * Handles creation, upgrade, and teardown of all database tables used by
 * the Help Nagaland Core plugin.
 */
final class HNC_Schema {


	/* --------------------------------------------------------------
	 * TABLE NAME HELPERS
	 * --------------------------------------------------------------
	 *
	 * All HNC tables are prefixed with the WordPress prefix plus "hnc_".
	 * For the default WP install this gives names like wp_hnc_alcohol_reports.
	 * Always access table names through the helper methods below, never
	 * hardcode a table name elsewhere in the codebase.
	 */

	/**
	 * Returns the full name of the hnc_alcohol_reports table.
	 *
	 * @return string
	 */
	public static function table_alcohol_reports() {
		global $wpdb;
		return $wpdb->prefix . HNC_TABLE_PREFIX . 'alcohol_reports';
	}

	/**
	 * Returns the full name of the hnc_drug_reports table.
	 *
	 * @return string
	 */
	public static function table_drug_reports() {
		global $wpdb;
		return $wpdb->prefix . HNC_TABLE_PREFIX . 'drug_reports';
	}

	/**
	 * Returns the full name of the hnc_phone_vault table.
	 *
	 * @return string
	 */
	public static function table_phone_vault() {
		global $wpdb;
		return $wpdb->prefix . HNC_TABLE_PREFIX . 'phone_vault';
	}

	/**
	 * Returns the full name of the hnc_audit_log table.
	 *
	 * @return string
	 */
	public static function table_audit_log() {
		global $wpdb;
		return $wpdb->prefix . HNC_TABLE_PREFIX . 'audit_log';
	}

	/**
	 * Returns the full name of the hnc_device_fingerprints table.
	 *
	 * @return string
	 */
	public static function table_device_fingerprints() {
		global $wpdb;
		return $wpdb->prefix . HNC_TABLE_PREFIX . 'device_fingerprints';
	}

	/**
	 * Returns the full name of the hnc_transparency_snapshots table.
	 *
	 * @return string
	 */
	public static function table_transparency_snapshots() {
		global $wpdb;
		return $wpdb->prefix . HNC_TABLE_PREFIX . 'transparency_snapshots';
	}

	/**
	 * Returns the full name of the hnc_partners table.
	 *
	 * @return string
	 */
	public static function table_partners() {
		global $wpdb;
		return $wpdb->prefix . HNC_TABLE_PREFIX . 'partners';
	}

	/**
	 * Partner forwards junction table (Phase 10).
	 *
	 * @return string
	 */
	public static function table_partner_forwards() {
		global $wpdb;
		return $wpdb->prefix . HNC_TABLE_PREFIX . 'partner_forwards';
	}

	/**
	 * Returns all HNC table names as an array.
	 *
	 * @return string[]
	 */
	public static function all_tables() {
		return array(
			self::table_alcohol_reports(),
			self::table_drug_reports(),
			self::table_phone_vault(),
			self::table_audit_log(),
			self::table_device_fingerprints(),
			self::table_transparency_snapshots(),
			self::table_partners(),
			self::table_partner_forwards(),
		);
	}


	/* --------------------------------------------------------------
	 * INSTALL
	 * -------------------------------------------------------------- */

	/**
	 * Install or upgrade all tables. Safe to run multiple times.
	 *
	 * @return void
	 */
	public static function install() {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();

		$statements = array(
			self::create_alcohol_reports( $charset_collate ),
			self::create_drug_reports( $charset_collate ),
			self::create_phone_vault( $charset_collate ),
			self::create_audit_log( $charset_collate ),
			self::create_device_fingerprints( $charset_collate ),
			self::create_transparency_snapshots( $charset_collate ),
			self::create_partners( $charset_collate ),
			self::create_partner_forwards( $charset_collate ),
		);

		foreach ( $statements as $sql ) {
			// dbDelta returns an array of results, mostly informational.
			// We intentionally do not halt on individual statement failures
			// because dbDelta sometimes returns non fatal notices.
			dbDelta( $sql );
		}
	}

	/**
	 * Drop all tables. Called only from uninstall.php with explicit opt in.
	 *
	 * @return void
	 */
	public static function drop_all() {
		global $wpdb;
		foreach ( self::all_tables() as $table ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->query( "DROP TABLE IF EXISTS {$table}" );
		}
	}

	/**
	 * Verify that all expected tables exist in the database.
	 * Used by the health check screen.
	 *
	 * @return array Map of table name => bool exists.
	 */
	public static function verify() {
		global $wpdb;
		$result = array();
		foreach ( self::all_tables() as $table ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$found            = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
			$result[ $table ] = ( $found === $table );
		}
		return $result;
	}


	/* --------------------------------------------------------------
	 * TABLE: hnc_alcohol_reports
	 * --------------------------------------------------------------
	 *
	 * Holds every alcohol report, from pending through archived. The lat/lng
	 * columns store the grid snapped coordinates used for public display.
	 * The lat_raw/lng_raw columns store the original GPS reading and are
	 * admin only.
	 */
	private static function create_alcohol_reports( $charset_collate ) {
		$table = self::table_alcohol_reports();
		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			public_code VARCHAR(9) NOT NULL,
			lat DECIMAL(10,7) NOT NULL,
			lng DECIMAL(10,7) NOT NULL,
			lat_raw DECIMAL(10,7) NOT NULL,
			lng_raw DECIMAL(10,7) NOT NULL,
			district VARCHAR(60) NOT NULL DEFAULT '',
			category VARCHAR(40) NOT NULL,
			description TEXT NULL,
			time_pattern VARCHAR(30) NULL,
			photo_uuid CHAR(36) NULL,
			photo_hash CHAR(64) NULL,
			device_hash CHAR(64) NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			verified_by_operator TINYINT(1) NOT NULL DEFAULT 0,
			merged_into BIGINT UNSIGNED NULL,
			report_count INT UNSIGNED NOT NULL DEFAULT 1,
			phone_vault_id BIGINT UNSIGNED NULL,
			submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			moderated_at DATETIME NULL,
			moderator_id BIGINT UNSIGNED NULL,
			rejection_reason VARCHAR(120) NULL,
			archived_at DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY public_code (public_code),
			KEY status_submitted (status, submitted_at),
			KEY district_category (district, category),
			KEY device_hash (device_hash),
			KEY merged_into (merged_into),
			KEY phone_vault_id (phone_vault_id),
			KEY lat_lng (lat, lng),
			KEY moderator_id (moderator_id)
		) {$charset_collate};";
	}


	/* --------------------------------------------------------------
	 * TABLE: hnc_drug_reports
	 * --------------------------------------------------------------
	 *
	 * Drug reports are confidential. No row in this table should ever be
	 * exposed via a public REST endpoint. Aggregate counts only are allowed
	 * on the transparency page.
	 */
	private static function create_drug_reports( $charset_collate ) {
		$table = self::table_drug_reports();
		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			public_code VARCHAR(9) NOT NULL,
			district VARCHAR(60) NOT NULL,
			area_desc VARCHAR(200) NOT NULL,
			category VARCHAR(40) NOT NULL,
			pattern TEXT NOT NULL,
			vehicle_info VARCHAR(100) NULL,
			media_uuid CHAR(36) NULL,
			media_type VARCHAR(20) NULL,
			media_hash CHAR(64) NULL,
			submission_mode VARCHAR(20) NOT NULL DEFAULT 'anonymous',
			phone_vault_id BIGINT UNSIGNED NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			severity_flag TINYINT NULL,
			submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			moderated_at DATETIME NULL,
			moderator_id BIGINT UNSIGNED NULL,
			resolved_at DATETIME NULL,
			archived_at DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY public_code (public_code),
			KEY status_submitted (status, submitted_at),
			KEY district_category (district, category),
			KEY submission_mode (submission_mode),
			KEY phone_vault_id (phone_vault_id),
			KEY severity_flag (severity_flag),
			KEY moderator_id (moderator_id)
		) {$charset_collate};";
	}


	/* --------------------------------------------------------------
	 * TABLE: hnc_phone_vault
	 * --------------------------------------------------------------
	 *
	 * Encrypted phone storage. Phones are encrypted with AES-256-GCM. The
	 * encryption key itself is NOT stored anywhere in the database. It is
	 * derived at vault unlock time from a passphrase known only to the admin,
	 * held in a PHP session for at most 15 minutes, then discarded.
	 *
	 * If the admin forgets the passphrase, the vault is permanently
	 * inaccessible. This is a deliberate design choice.
	 */
	private static function create_phone_vault( $charset_collate ) {
		$table = self::table_phone_vault();
		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			report_type VARCHAR(20) NOT NULL,
			report_id BIGINT UNSIGNED NOT NULL,
			encrypted_phone VARBINARY(255) NOT NULL,
			nonce VARBINARY(16) NOT NULL,
			tag VARBINARY(16) NOT NULL,
			consent_forward TINYINT(1) NOT NULL DEFAULT 0,
			consent_partner VARCHAR(60) NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			scheduled_delete_at DATETIME NOT NULL,
			deleted_at DATETIME NULL,
			PRIMARY KEY  (id),
			KEY report_lookup (report_type, report_id),
			KEY scheduled_delete_at (scheduled_delete_at),
			KEY deleted_at (deleted_at)
		) {$charset_collate};";
	}


	/* --------------------------------------------------------------
	 * TABLE: hnc_audit_log
	 * --------------------------------------------------------------
	 *
	 * Immutable record of every admin action, partner action, and sensitive
	 * system event. Entries are append only. The admin UI does not expose
	 * a delete button. Logs are retained for 5 years then archived to cold
	 * storage by the retention cron.
	 */
	private static function create_audit_log( $charset_collate ) {
		$table = self::table_audit_log();
		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			event_type VARCHAR(40) NOT NULL,
			actor_id BIGINT UNSIGNED NULL,
			report_type VARCHAR(20) NULL,
			report_id BIGINT UNSIGNED NULL,
			action VARCHAR(40) NOT NULL,
			detail TEXT NULL,
			ip_hash CHAR(64) NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY event_type (event_type),
			KEY actor_id (actor_id),
			KEY report_lookup (report_type, report_id),
			KEY created_at (created_at)
		) {$charset_collate};";
	}


	/* --------------------------------------------------------------
	 * TABLE: hnc_device_fingerprints
	 * --------------------------------------------------------------
	 *
	 * Non reversible device fingerprint hashes used for rate limiting and
	 * abuse detection. The hash is derived from stable browser properties
	 * and cannot be used to identify a person, but it is stable enough
	 * to catch repeat abusers.
	 */
	private static function create_device_fingerprints( $charset_collate ) {
		$table = self::table_device_fingerprints();
		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			device_hash CHAR(64) NOT NULL,
			first_seen DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			last_seen DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			submission_count_24h INT UNSIGNED NOT NULL DEFAULT 0,
			submission_count_total INT UNSIGNED NOT NULL DEFAULT 0,
			flagged TINYINT(1) NOT NULL DEFAULT 0,
			flag_reason VARCHAR(120) NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY device_hash (device_hash),
			KEY flagged (flagged),
			KEY last_seen (last_seen)
		) {$charset_collate};";
	}


	/* --------------------------------------------------------------
	 * TABLE: hnc_transparency_snapshots
	 * --------------------------------------------------------------
	 *
	 * Monthly aggregate statistics published on the transparency page.
	 * Snapshots are never edited once published. Corrections are added
	 * as appended notes.
	 */
	private static function create_transparency_snapshots( $charset_collate ) {
		$table = self::table_transparency_snapshots();
		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			period_year SMALLINT NOT NULL,
			period_month TINYINT NOT NULL,
			alcohol_received INT NOT NULL DEFAULT 0,
			alcohol_approved INT NOT NULL DEFAULT 0,
			alcohol_rejected INT NOT NULL DEFAULT 0,
			alcohol_acted_by_police INT NOT NULL DEFAULT 0,
			drug_received INT NOT NULL DEFAULT 0,
			drug_approved INT NOT NULL DEFAULT 0,
			drug_forwarded INT NOT NULL DEFAULT 0,
			drug_acted INT NOT NULL DEFAULT 0,
			published_at DATETIME NULL,
			admin_note TEXT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY period (period_year, period_month),
			KEY published_at (published_at)
		) {$charset_collate};";
	}


	/* --------------------------------------------------------------
	 * TABLE: hnc_partners
	 * --------------------------------------------------------------
	 *
	 * Vetted partner organizations that may receive forwarded drug reports.
	 * In Phase 1 this table is created but not populated. Partner onboarding
	 * is deferred to Phase 10.
	 */
	private static function create_partners( $charset_collate ) {
		$table = self::table_partners();
		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			slug VARCHAR(60) NOT NULL DEFAULT '',
			name VARCHAR(120) NOT NULL,
			wp_user_id BIGINT UNSIGNED NOT NULL,
			contact_email VARCHAR(190) NULL,
			contact_gpg_fingerprint VARCHAR(64) NULL,
			onboarded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			last_login DATETIME NULL,
			active TINYINT(1) NOT NULL DEFAULT 1,
			PRIMARY KEY  (id),
			UNIQUE KEY wp_user_id (wp_user_id),
			UNIQUE KEY slug (slug),
			KEY active (active)
		) {$charset_collate};";
	}


	/* --------------------------------------------------------------
	 * TABLE: hnc_partner_forwards
	 * --------------------------------------------------------------
	 *
	 * Junction table tracking each (partner, drug_report) pair that has
	 * been forwarded. Partners see only rows in this table scoped to
	 * their partner_id. Moderators can see every row.
	 *
	 * States:
	 *   forwarded_at    - set at insert (the moment HNC_Drug_Forward fires)
	 *   acknowledged_at - partner clicked "I have seen this" in their dashboard
	 *   acted_at        - partner marked the case as "acted on" (took action)
	 *   closed_at       - partner marked the case as closed (no further work)
	 *
	 * A single drug report can have multiple forward rows (one per partner
	 * it was forwarded to). This is intentional: a case can engage both a
	 * health partner and a legal liaison simultaneously.
	 */
	private static function create_partner_forwards( $charset_collate ) {
		$table = self::table_partner_forwards();
		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			partner_id BIGINT UNSIGNED NOT NULL,
			report_id BIGINT UNSIGNED NOT NULL,
			forwarded_by_user_id BIGINT UNSIGNED NULL,
			forwarded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			acknowledged_at DATETIME NULL,
			acted_at DATETIME NULL,
			closed_at DATETIME NULL,
			partner_note TEXT NULL,
			moderator_note TEXT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY partner_report (partner_id, report_id),
			KEY partner_id (partner_id),
			KEY report_id (report_id),
			KEY forwarded_at (forwarded_at),
			KEY acknowledged_at (acknowledged_at)
		) {$charset_collate};";
	}
}
