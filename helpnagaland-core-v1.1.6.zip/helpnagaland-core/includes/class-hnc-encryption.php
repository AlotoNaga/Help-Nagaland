<?php
/**
 * Encryption primitives for the phone vault.
 *
 * This class handles all cryptographic operations related to the encrypted
 * phone number store. The threat model is:
 *
 *   - An attacker with full database access (leaked backup, compromised
 *     hosting account, SQL injection) must NOT be able to read phone numbers.
 *   - An attacker with full filesystem access (same paths as above) must NOT
 *     be able to read phone numbers either.
 *   - A subpoena demanding disclosure of reporter identities must result in
 *     a truthful answer: "We cannot disclose what we cannot read."
 *
 * To achieve this, the encryption key is NEVER persisted anywhere. The key
 * is derived at vault unlock time from a passphrase that only the admin
 * knows. Derivation uses Argon2id with high memory and iteration cost. The
 * derived key is held in a PHP session for at most 15 minutes. After that
 * it is wiped and the admin must re-enter the passphrase.
 *
 * If the admin forgets the passphrase, the vault is permanently inaccessible.
 * This is the cost of the guarantee.
 *
 * Algorithms:
 *
 *   - Passphrase derivation: Argon2id (PASSWORD_ARGON2ID), or
 *     PASSWORD_BCRYPT fallback if Argon is unavailable.
 *   - Symmetric encryption: AES-256-GCM via OpenSSL.
 *   - Random bytes: random_bytes() which uses a cryptographic RNG.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Encryption
 */
final class HNC_Encryption {


	/**
	 * OpenSSL cipher name.
	 */
	const CIPHER = 'aes-256-gcm';

	/**
	 * AES-GCM nonce length in bytes.
	 */
	const NONCE_LEN = 12;

	/**
	 * AES-GCM auth tag length in bytes.
	 */
	const TAG_LEN = 16;

	/**
	 * Derived key length in bytes (AES-256 needs 32).
	 */
	const KEY_LEN = 32;

	/**
	 * Salt length for key derivation, in bytes.
	 */
	const KDF_SALT_LEN = 16;

	/**
	 * PBKDF2-SHA256 iteration count for new installs. OWASP 2023
	 * recommends at least 310,000 for PBKDF2-HMAC-SHA256. Older vaults
	 * record their own iteration count in meta and are decrypted with
	 * that value; only freshly-set passphrases use this default.
	 *
	 * Filterable via `hnc_vault_pbkdf2_iterations`.
	 */
	const PBKDF2_ITERATIONS_DEFAULT = 310000;

	/**
	 * Fallback iteration count for vaults whose meta pre-dates the
	 * `pbkdf2_iter` field. Matches the hard-coded value used in
	 * plugin v1.0.0 so those vaults remain decryptable after upgrade.
	 */
	const PBKDF2_ITERATIONS_LEGACY = 200000;

	/**
	 * Session key used to store the derived key and its expiry. The key is
	 * stored base64 encoded to avoid binary data issues in some session handlers.
	 */
	const SESSION_KEY_DATA   = 'hnc_vault_key_b64';
	const SESSION_KEY_EXPIRY = 'hnc_vault_key_expiry';

	/**
	 * Option key storing the Argon2id hash of the passphrase (for verification)
	 * AND the KDF salt (for re-derivation) AND the kdf algorithm tag.
	 *
	 * Stored as JSON: { "salt": base64, "hash": argon-hash, "alg": "argon2id" }
	 */
	const OPT_VAULT_META = 'hnc_vault_meta';


	/* ------------------------------------------------------------------
	 * PASSPHRASE SETUP
	 * ------------------------------------------------------------------ */

	/**
	 * Determine whether the vault passphrase has been set for this install.
	 *
	 * @return bool
	 */
	public static function passphrase_is_set() {
		$meta = self::get_vault_meta();
		return ! empty( $meta['hash'] ) && ! empty( $meta['salt'] );
	}

	/**
	 * Set the vault passphrase. Called ONCE during initial setup. If called
	 * again, this function refuses to overwrite unless the caller explicitly
	 * passes $force = true, because changing the passphrase makes all
	 * existing encrypted phones unreadable.
	 *
	 * In normal operation, a passphrase is set once per install and never
	 * changed. If a rotation is genuinely needed, all vault rows must be
	 * decrypted with the old key and re-encrypted with the new one in a
	 * single transaction. That migration flow is out of scope for Phase 2.
	 *
	 * @param string $passphrase Admin-chosen passphrase.
	 * @param bool   $force      If true, overwrite an existing passphrase
	 *                           (WITHOUT re-encrypting existing vault data).
	 *                           Use with extreme caution.
	 * @return bool True on success.
	 */
	public static function set_passphrase( $passphrase, $force = false ) {
		$passphrase = (string) $passphrase;
		if ( strlen( $passphrase ) < 12 ) {
			return false;
		}

		if ( self::passphrase_is_set() && ! $force ) {
			return false;
		}

		try {
			$salt_bytes = random_bytes( self::KDF_SALT_LEN );
		} catch ( Throwable $t ) {
			return false;
		}

		$salt_b64 = base64_encode( $salt_bytes );

		// Hash the passphrase itself for verification on subsequent unlocks.
		// We use password_hash because it is designed for this. Note that
		// password_hash already embeds its own salt, which is separate from
		// the KDF salt used to derive the symmetric key.
		$algo = defined( 'PASSWORD_ARGON2ID' ) ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT;
		$opts = array();
		if ( PASSWORD_ARGON2ID === $algo ) {
			$opts = array(
				'memory_cost' => 65536, // 64 MB
				'time_cost'   => 4,
				'threads'     => 2,
			);
		}

		$hash = password_hash( $passphrase, $algo, $opts );
		if ( false === $hash || null === $hash ) {
			return false;
		}

		/*
		 * Record the PBKDF2 iteration count used to derive the symmetric
		 * key. Storing this with the meta lets us bump the default
		 * iteration count in future versions without breaking older
		 * vaults: they continue to decrypt with the iteration count
		 * originally used at set_passphrase() time.
		 */
		$pbkdf2_iterations = (int) apply_filters(
			'hnc_vault_pbkdf2_iterations',
			self::PBKDF2_ITERATIONS_DEFAULT
		);
		if ( $pbkdf2_iterations < 100000 ) {
			$pbkdf2_iterations = self::PBKDF2_ITERATIONS_DEFAULT;
		}

		$meta = array(
			'alg'          => ( PASSWORD_ARGON2ID === $algo ) ? 'argon2id' : 'bcrypt',
			'salt'         => $salt_b64,
			'hash'         => $hash,
			'set_at'       => current_time( 'mysql' ),
			'kdf_iter'     => $opts['time_cost'] ?? 0,
			'kdf_mem'      => $opts['memory_cost'] ?? 0,
			'pbkdf2_iter'  => $pbkdf2_iterations,
		);

		update_option( self::OPT_VAULT_META, $meta, false );

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_vault( HNC_Logger::ACTION_VAULT_PASSPHRASE );
		}

		return true;
	}


	/* ------------------------------------------------------------------
	 * VAULT SESSION (KEY UNLOCK)
	 * ------------------------------------------------------------------ */

	/**
	 * Unlock the vault for the current admin session by verifying the
	 * supplied passphrase and deriving the symmetric key. On success the
	 * key is stored in the PHP session for up to the configured number of
	 * minutes.
	 *
	 * @param string $passphrase Admin-entered passphrase.
	 * @return bool True on success.
	 */
	public static function unlock( $passphrase ) {
		$passphrase = (string) $passphrase;
		$meta       = self::get_vault_meta();

		if ( empty( $meta['hash'] ) || empty( $meta['salt'] ) ) {
			// No passphrase was ever set.
			if ( class_exists( 'HNC_Logger' ) ) {
				HNC_Logger::log_vault( HNC_Logger::ACTION_VAULT_FAIL, 0, array( 'reason' => 'no_passphrase' ) );
			}
			return false;
		}

		// Verify against the stored hash.
		if ( ! password_verify( $passphrase, $meta['hash'] ) ) {
			if ( class_exists( 'HNC_Logger' ) ) {
				HNC_Logger::log_vault( HNC_Logger::ACTION_VAULT_FAIL, 0, array( 'reason' => 'bad_passphrase' ) );
			}
			return false;
		}

		// Derive the symmetric key using PBKDF2 with the stored salt.
		// We use PBKDF2 here because we need a deterministic output that
		// re-derives the same key every session. password_hash/verify cannot
		// be used for that because password_hash output is not deterministic.
		$salt_bytes = base64_decode( (string) $meta['salt'], true );
		if ( false === $salt_bytes || strlen( $salt_bytes ) !== self::KDF_SALT_LEN ) {
			return false;
		}

		$key = self::derive_key( $passphrase, $salt_bytes );
		if ( strlen( $key ) !== self::KEY_LEN ) {
			return false;
		}

		// Stash in session for the configured window.
		$minutes = (int) get_option( 'hnc_vault_session_minutes', 15 );
		if ( $minutes < 1 ) {
			$minutes = 15;
		}
		$expiry = time() + ( $minutes * 60 );

		self::ensure_session_started();
		$_SESSION[ self::SESSION_KEY_DATA ]   = base64_encode( $key );
		$_SESSION[ self::SESSION_KEY_EXPIRY ] = $expiry;

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_vault(
				HNC_Logger::ACTION_VAULT_UNLOCK,
				0,
				array( 'expires_at' => gmdate( 'Y-m-d H:i:s', $expiry ) )
			);
		}

		// Wipe the passphrase from memory as best we can.
		// PHP strings are immutable so this is mostly symbolic, but it
		// signals intent to any future reviewer.
		$passphrase = str_repeat( "\0", strlen( $passphrase ) );
		unset( $passphrase );

		return true;
	}

	/**
	 * Lock the vault by wiping the session key. Called when the admin
	 * clicks Lock, on logout, or when the expiry passes.
	 *
	 * @return void
	 */
	public static function lock() {
		self::ensure_session_started();
		if ( isset( $_SESSION[ self::SESSION_KEY_DATA ] ) ) {
			// Overwrite with zeros before unsetting to reduce memory residue.
			$_SESSION[ self::SESSION_KEY_DATA ] = str_repeat( "\0", strlen( (string) $_SESSION[ self::SESSION_KEY_DATA ] ) );
			unset( $_SESSION[ self::SESSION_KEY_DATA ] );
		}
		if ( isset( $_SESSION[ self::SESSION_KEY_EXPIRY ] ) ) {
			unset( $_SESSION[ self::SESSION_KEY_EXPIRY ] );
		}

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_vault( HNC_Logger::ACTION_VAULT_LOCK );
		}
	}

	/**
	 * True if the vault is currently unlocked in this session and has not expired.
	 *
	 * @return bool
	 */
	public static function is_unlocked() {
		self::ensure_session_started();
		if ( empty( $_SESSION[ self::SESSION_KEY_DATA ] ) ) {
			return false;
		}
		$expiry = isset( $_SESSION[ self::SESSION_KEY_EXPIRY ] ) ? (int) $_SESSION[ self::SESSION_KEY_EXPIRY ] : 0;
		if ( $expiry < time() ) {
			// Expired. Lock it.
			self::lock();
			return false;
		}
		return true;
	}

	/**
	 * Seconds remaining in the current unlock window, or 0 if locked.
	 *
	 * @return int
	 */
	public static function unlock_seconds_remaining() {
		self::ensure_session_started();
		if ( ! self::is_unlocked() ) {
			return 0;
		}
		$expiry = (int) $_SESSION[ self::SESSION_KEY_EXPIRY ];
		return max( 0, $expiry - time() );
	}


	/* ------------------------------------------------------------------
	 * ENCRYPT / DECRYPT
	 * ------------------------------------------------------------------ */

	/**
	 * Encrypt a plaintext string for storage in the phone vault.
	 *
	 * Returns an array:
	 *   [
	 *     'ciphertext' => binary,
	 *     'nonce'      => binary (12 bytes),
	 *     'tag'        => binary (16 bytes),
	 *   ]
	 *
	 * Returns null if the vault is locked or on error.
	 *
	 * Requires the vault to be unlocked in the current session.
	 *
	 * @param string $plaintext The raw string.
	 * @return array|null
	 */
	public static function encrypt( $plaintext ) {
		$key = self::current_session_key();
		if ( null === $key ) {
			return null;
		}

		try {
			$nonce = random_bytes( self::NONCE_LEN );
		} catch ( Throwable $t ) {
			return null;
		}

		$tag = '';
		// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		$ciphertext = @openssl_encrypt(
			(string) $plaintext,
			self::CIPHER,
			$key,
			OPENSSL_RAW_DATA,
			$nonce,
			$tag,
			'', // AAD
			self::TAG_LEN
		);

		if ( false === $ciphertext ) {
			return null;
		}

		return array(
			'ciphertext' => $ciphertext,
			'nonce'      => $nonce,
			'tag'        => $tag,
		);
	}

	/**
	 * Decrypt ciphertext to the original string.
	 *
	 * @param string $ciphertext Binary ciphertext.
	 * @param string $nonce      Binary nonce.
	 * @param string $tag        Binary auth tag.
	 * @return string|null Decrypted plaintext, or null on failure.
	 */
	public static function decrypt( $ciphertext, $nonce, $tag ) {
		$key = self::current_session_key();
		if ( null === $key ) {
			return null;
		}

		// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		$plaintext = @openssl_decrypt(
			(string) $ciphertext,
			self::CIPHER,
			$key,
			OPENSSL_RAW_DATA,
			(string) $nonce,
			(string) $tag
		);

		return ( false === $plaintext ) ? null : $plaintext;
	}


	/* ------------------------------------------------------------------
	 * INTERNAL HELPERS
	 * ------------------------------------------------------------------ */

	/**
	 * Derive the symmetric key from the passphrase and salt using PBKDF2-SHA256.
	 * Deterministic output so we can re-derive on every unlock.
	 *
	 * @param string $passphrase Passphrase.
	 * @param string $salt_bytes Binary salt (16 bytes).
	 * @return string 32-byte binary key.
	 */
	private static function derive_key( $passphrase, $salt_bytes ) {
		/*
		 * Read iteration count from vault meta when available so a vault
		 * created on an earlier version keeps decrypting with its own
		 * iteration count. Vaults created at v1.1.0 or later use the
		 * higher OWASP-recommended default (see
		 * PBKDF2_ITERATIONS_DEFAULT). Absence of the field means the
		 * passphrase was set on v1.0.0: use PBKDF2_ITERATIONS_LEGACY.
		 */
		$meta       = get_option( self::OPT_VAULT_META, array() );
		$iterations = isset( $meta['pbkdf2_iter'] )
			? (int) $meta['pbkdf2_iter']
			: self::PBKDF2_ITERATIONS_LEGACY;
		if ( $iterations < 100000 ) {
			$iterations = self::PBKDF2_ITERATIONS_LEGACY;
		}
		return hash_pbkdf2( 'sha256', (string) $passphrase, (string) $salt_bytes, $iterations, self::KEY_LEN, true );
	}

	/**
	 * Get the current session-held symmetric key, or null if locked.
	 *
	 * @return string|null 32-byte binary key or null.
	 */
	private static function current_session_key() {
		if ( ! self::is_unlocked() ) {
			return null;
		}
		$b64 = isset( $_SESSION[ self::SESSION_KEY_DATA ] ) ? (string) $_SESSION[ self::SESSION_KEY_DATA ] : '';
		if ( '' === $b64 ) {
			return null;
		}
		$key = base64_decode( $b64, true );
		if ( false === $key || strlen( $key ) !== self::KEY_LEN ) {
			return null;
		}
		return $key;
	}

	/**
	 * Load the vault metadata option.
	 *
	 * @return array
	 */
	private static function get_vault_meta() {
		$meta = get_option( self::OPT_VAULT_META, array() );
		if ( ! is_array( $meta ) ) {
			return array();
		}
		return $meta;
	}

	/**
	 * Ensure a PHP session is running. WP does not start sessions by
	 * default, so we start one if headers have not been sent and none
	 * exists yet. This session is used ONLY for admin vault state and
	 * should never be started for anonymous public traffic.
	 *
	 * Callers should only invoke vault methods in admin contexts.
	 *
	 * @return void
	 */
	private static function ensure_session_started() {
		if ( PHP_SESSION_ACTIVE === session_status() ) {
			return;
		}
		// Session cannot start if headers have already been sent.
		if ( headers_sent() ) {
			return;
		}
		// Harden session cookie. These must be set before session_start.
		$cookie_params = array(
			'lifetime' => 0, // session cookie, closed with browser
			'path'     => defined( 'COOKIEPATH' ) ? COOKIEPATH : '/',
			'domain'   => defined( 'COOKIE_DOMAIN' ) ? COOKIE_DOMAIN : '',
			'secure'   => is_ssl(),
			'httponly' => true,
			'samesite' => 'Strict',
		);
		if ( PHP_VERSION_ID >= 70300 ) {
			session_set_cookie_params( $cookie_params );
		} else {
			session_set_cookie_params(
				$cookie_params['lifetime'],
				$cookie_params['path'] . '; samesite=Strict',
				$cookie_params['domain'],
				$cookie_params['secure'],
				$cookie_params['httponly']
			);
		}
		// Ignore errors. If sessions are disabled on the host, vault calls
		// will fail cleanly via is_unlocked returning false.
		// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.PHP.DiscouragedPHPFunctions.session_session_start
		@session_start();
	}
}
