<?php
/**
 * Alcohol pipeline: moderation actions.
 *
 * Every method here performs one moderator action against a row in the
 * hnc_alcohol_reports table. All actions:
 *
 *   1. Require the CAP_MODERATE_ALCOHOL capability.
 *   2. Validate the current status allows the transition.
 *   3. Write the change atomically with moderator_id and moderated_at.
 *   4. Log the action via HNC_Logger.
 *   5. Return true / result array on success, WP_Error on failure.
 *
 * Legal status transitions:
 *
 *   pending   -> approved | rejected | hold
 *   hold      -> pending  | approved | rejected
 *   approved  -> archived | rejected (rare, for re-consideration)
 *   rejected  -> (terminal; row is purged by retention cron)
 *   archived  -> (terminal; kept for reference)
 *
 * On reject, the photo is deleted immediately. The row remains for 7 days so
 * an operator can see why something was rejected, then retention cron purges
 * the whole row.
 *
 * On archive, nothing extra happens; photo is already long gone by the time
 * a pin is 12 months old because photo retention is 30 days.
 *
 * REST endpoints for these actions are NOT registered in Phase 3. The admin
 * UI in Phase 7 and the REST layer in Phase 6 will wire them up. This class
 * is the business-logic layer that both will call.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Alcohol_Moderation
 */
final class HNC_Alcohol_Moderation {


	/* ------------------------------------------------------------------
	 * ERROR CODES
	 * ------------------------------------------------------------------ */

	const ERR_UNAUTHORIZED   = 'hnc_unauthorized';
	const ERR_NOT_FOUND      = 'hnc_report_not_found';
	const ERR_BAD_STATUS     = 'hnc_bad_status_transition';
	const ERR_UPDATE_FAILED  = 'hnc_update_failed';
	const ERR_SAME_ID        = 'hnc_merge_same_id';
	const ERR_BAD_TARGET     = 'hnc_merge_bad_target';
	const ERR_BAD_REASON     = 'hnc_bad_rejection_reason';


	/* ------------------------------------------------------------------
	 * PUBLIC ACTIONS
	 * ------------------------------------------------------------------ */

	/**
	 * Approve a pending or held report. Makes the pin visible on the public
	 * map.
	 *
	 * @param int    $id       Report ID.
	 * @param string $note     Optional admin note (stored in audit log).
	 * @return true|WP_Error
	 */
	public static function approve( $id, $note = '' ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$row = self::fetch_or_error( (int) $id );
		if ( is_wp_error( $row ) ) {
			return $row;
		}

		// Legal from: pending, hold.
		if ( ! in_array( $row->status, array( HNC_Alcohol_Submit::STATUS_PENDING, HNC_Alcohol_Submit::STATUS_HOLD ), true ) ) {
			return new WP_Error(
				self::ERR_BAD_STATUS,
				sprintf(
					/* translators: %s: current status */
					__( 'Cannot approve a report currently in status: %s', 'helpnagaland-core' ),
					$row->status
				)
			);
		}

		/*
		 * Defense-in-depth grid re-snap on approve. Coordinates should
		 * already have been snapped at submit time, but if a row has
		 * been touched by SQL, by a partial import, or by a future
		 * moderation flow that exposes raw coordinates, we want the
		 * published pin to be grid-snapped unconditionally.
		 */
		$extras = array( 'rejection_reason' => null );
		if ( class_exists( 'HNC_Geo' ) && isset( $row->lat, $row->lng ) ) {
			$snapped = HNC_Geo::snap_to_grid( (float) $row->lat, (float) $row->lng );
			if ( is_array( $snapped )
				&& isset( $snapped['lat'], $snapped['lng'] )
				&& ( (float) $snapped['lat'] !== (float) $row->lat
					|| (float) $snapped['lng'] !== (float) $row->lng ) ) {
				$extras['lat'] = (float) $snapped['lat'];
				$extras['lng'] = (float) $snapped['lng'];
			}
		}

		$ok = self::write_status(
			(int) $id,
			HNC_Alcohol_Submit::STATUS_APPROVED,
			$extras
		);
		if ( ! $ok ) {
			return new WP_Error( self::ERR_UPDATE_FAILED, __( 'Database update failed.', 'helpnagaland-core' ) );
		}

		self::log_action(
			HNC_Logger::ACTION_APPROVE,
			(int) $id,
			array(
				'previous_status' => $row->status,
				'note'            => class_exists( 'HNC_Sanitizer' ) ? HNC_Sanitizer::admin_note( $note ) : (string) $note,
			)
		);
		return true;
	}

	/**
	 * Reject a report. Deletes the photo immediately. Stores the rejection
	 * reason (public-safe, 120 chars max). The row is kept for 7 days for
	 * audit review, then purged by retention cron.
	 *
	 * @param int    $id     Report ID.
	 * @param string $reason Short rejection reason.
	 * @return true|WP_Error
	 */
	public static function reject( $id, $reason ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$row = self::fetch_or_error( (int) $id );
		if ( is_wp_error( $row ) ) {
			return $row;
		}

		// Legal from: pending, hold, approved.
		if ( ! in_array( $row->status, array(
			HNC_Alcohol_Submit::STATUS_PENDING,
			HNC_Alcohol_Submit::STATUS_HOLD,
			HNC_Alcohol_Submit::STATUS_APPROVED,
		), true ) ) {
			return new WP_Error(
				self::ERR_BAD_STATUS,
				sprintf(
					/* translators: %s: current status */
					__( 'Cannot reject a report currently in status: %s', 'helpnagaland-core' ),
					$row->status
				)
			);
		}

		$clean_reason = class_exists( 'HNC_Sanitizer' )
			? HNC_Sanitizer::rejection_reason( $reason )
			: substr( trim( (string) $reason ), 0, 120 );
		if ( '' === $clean_reason ) {
			return new WP_Error(
				self::ERR_BAD_REASON,
				__( 'A short rejection reason is required.', 'helpnagaland-core' )
			);
		}

		// Delete the photo now, before writing the row, so that even if the
		// DB write fails the file is still gone. A leftover rejected row
		// without a photo is fine; a leftover photo on a rejected row is not.
		if ( ! empty( $row->photo_uuid ) && class_exists( 'HNC_Media' ) ) {
			HNC_Media::delete_by_uuid( 'alcohol', $row->photo_uuid );
		}

		$ok = self::write_status(
			(int) $id,
			HNC_Alcohol_Submit::STATUS_REJECTED,
			array(
				'rejection_reason' => $clean_reason,
				'photo_uuid'       => null,
				'photo_hash'       => null,
			)
		);
		if ( ! $ok ) {
			return new WP_Error( self::ERR_UPDATE_FAILED, __( 'Database update failed.', 'helpnagaland-core' ) );
		}

		self::log_action(
			HNC_Logger::ACTION_REJECT,
			(int) $id,
			array(
				'previous_status' => $row->status,
				'reason'          => $clean_reason,
				'photo_deleted'   => ! empty( $row->photo_uuid ),
			)
		);
		return true;
	}

	/**
	 * Put a report on hold. Used when the moderator wants a second opinion or
	 * needs more info before deciding. Does not delete the photo.
	 *
	 * @param int    $id   Report ID.
	 * @param string $note Optional admin note.
	 * @return true|WP_Error
	 */
	public static function hold( $id, $note = '' ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$row = self::fetch_or_error( (int) $id );
		if ( is_wp_error( $row ) ) {
			return $row;
		}

		if ( HNC_Alcohol_Submit::STATUS_PENDING !== $row->status ) {
			return new WP_Error(
				self::ERR_BAD_STATUS,
				sprintf(
					/* translators: %s: current status */
					__( 'Only pending reports can be put on hold. Current status: %s', 'helpnagaland-core' ),
					$row->status
				)
			);
		}

		$ok = self::write_status( (int) $id, HNC_Alcohol_Submit::STATUS_HOLD );
		if ( ! $ok ) {
			return new WP_Error( self::ERR_UPDATE_FAILED, __( 'Database update failed.', 'helpnagaland-core' ) );
		}

		self::log_action(
			HNC_Logger::ACTION_HOLD,
			(int) $id,
			array(
				'note' => class_exists( 'HNC_Sanitizer' ) ? HNC_Sanitizer::admin_note( $note ) : (string) $note,
			)
		);
		return true;
	}

	/**
	 * Move a held report back to pending, so it re-enters the queue.
	 *
	 * @param int $id Report ID.
	 * @return true|WP_Error
	 */
	public static function unhold( $id ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$row = self::fetch_or_error( (int) $id );
		if ( is_wp_error( $row ) ) {
			return $row;
		}

		if ( HNC_Alcohol_Submit::STATUS_HOLD !== $row->status ) {
			return new WP_Error(
				self::ERR_BAD_STATUS,
				sprintf(
					/* translators: %s: current status */
					__( 'Only held reports can be released. Current status: %s', 'helpnagaland-core' ),
					$row->status
				)
			);
		}

		$ok = self::write_status( (int) $id, HNC_Alcohol_Submit::STATUS_PENDING );
		if ( ! $ok ) {
			return new WP_Error( self::ERR_UPDATE_FAILED, __( 'Database update failed.', 'helpnagaland-core' ) );
		}

		self::log_action( HNC_Logger::ACTION_UNHOLD, (int) $id );
		return true;
	}

	/**
	 * Archive an approved report. This removes it from the public map but
	 * keeps the row for reference. Auto-archive also runs via retention
	 * cron at the configured age.
	 *
	 * @param int $id Report ID.
	 * @return true|WP_Error
	 */
	public static function archive( $id ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$row = self::fetch_or_error( (int) $id );
		if ( is_wp_error( $row ) ) {
			return $row;
		}

		if ( HNC_Alcohol_Submit::STATUS_APPROVED !== $row->status ) {
			return new WP_Error(
				self::ERR_BAD_STATUS,
				sprintf(
					/* translators: %s: current status */
					__( 'Only approved reports can be archived. Current status: %s', 'helpnagaland-core' ),
					$row->status
				)
			);
		}

		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'alcohol_reports';
		$ok    = $wpdb->update(
			$table,
			array(
				'status'       => HNC_Alcohol_Submit::STATUS_ARCHIVED,
				'archived_at'  => current_time( 'mysql' ),
				'moderated_at' => current_time( 'mysql' ),
				'moderator_id' => get_current_user_id() ? (int) get_current_user_id() : null,
			),
			array( 'id' => (int) $id ),
			array( '%s', '%s', '%s', '%d' ),
			array( '%d' )
		);
		if ( false === $ok ) {
			return new WP_Error( self::ERR_UPDATE_FAILED, __( 'Database update failed.', 'helpnagaland-core' ) );
		}

		self::log_action( HNC_Logger::ACTION_ARCHIVE, (int) $id );
		return true;
	}

	/**
	 * Mark a report as verified by operator (Aloto's own site visit).
	 * Sets the verified flag and boosts report_count to 3.
	 *
	 * This is only applied to reports the operator themselves submitted via
	 * the normal submission flow (same live GPS and camera rules). The
	 * operator then clicks verify on their own pin from the moderation queue.
	 *
	 * @param int $id Report ID.
	 * @return true|WP_Error
	 */
	public static function verify_operator( $id ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$row = self::fetch_or_error( (int) $id );
		if ( is_wp_error( $row ) ) {
			return $row;
		}

		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'alcohol_reports';

		// The boost brings small pins up to the trust threshold of three
		// independent reports immediately. If the pin already has more reports
		// than that from merges, keep the higher value.
		$new_count = max( 3, (int) $row->report_count );

		$ok = $wpdb->update(
			$table,
			array(
				'verified_by_operator' => 1,
				'report_count'         => $new_count,
			),
			array( 'id' => (int) $id ),
			array( '%d', '%d' ),
			array( '%d' )
		);
		if ( false === $ok ) {
			return new WP_Error( self::ERR_UPDATE_FAILED, __( 'Database update failed.', 'helpnagaland-core' ) );
		}

		self::log_action(
			'verify_operator',
			(int) $id,
			array(
				'previous_count' => (int) $row->report_count,
				'new_count'      => $new_count,
			)
		);
		return true;
	}

	/**
	 * Manually merge one report into another. The source row is marked as
	 * merged and the target row's report_count is incremented.
	 *
	 * Constraints:
	 *   - Source and target must exist.
	 *   - They must be distinct.
	 *   - Both must be alcohol reports (guaranteed by the table).
	 *   - Source is not already merged.
	 *
	 * The source row is not deleted so audit trail is preserved.
	 *
	 * @param int $source_id Source report ID (goes away from public view).
	 * @param int $target_id Target report ID (survives, count++).
	 * @return true|WP_Error
	 */
	public static function merge( $source_id, $target_id ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$source_id = (int) $source_id;
		$target_id = (int) $target_id;

		if ( $source_id === $target_id || 0 === $source_id || 0 === $target_id ) {
			return new WP_Error( self::ERR_SAME_ID, __( 'Source and target must be different.', 'helpnagaland-core' ) );
		}

		$source = self::fetch_or_error( $source_id );
		if ( is_wp_error( $source ) ) {
			return $source;
		}
		$target = self::fetch_or_error( $target_id );
		if ( is_wp_error( $target ) ) {
			return $target;
		}

		if ( (int) $source->merged_into > 0 ) {
			return new WP_Error( self::ERR_BAD_TARGET, __( 'Source is already merged into another report.', 'helpnagaland-core' ) );
		}
		if ( (int) $target->merged_into > 0 ) {
			return new WP_Error( self::ERR_BAD_TARGET, __( 'Cannot merge into a report that has itself been merged.', 'helpnagaland-core' ) );
		}

		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'alcohol_reports';

		// Mark source as merged.
		$ok1 = $wpdb->update(
			$table,
			array(
				'merged_into'  => $target_id,
				'status'       => HNC_Alcohol_Submit::STATUS_ARCHIVED,
				'archived_at'  => current_time( 'mysql' ),
				'moderator_id' => get_current_user_id() ? (int) get_current_user_id() : null,
				'moderated_at' => current_time( 'mysql' ),
			),
			array( 'id' => $source_id ),
			array( '%d', '%s', '%s', '%d', '%s' ),
			array( '%d' )
		);
		if ( false === $ok1 ) {
			return new WP_Error( self::ERR_UPDATE_FAILED, __( 'Database update failed.', 'helpnagaland-core' ) );
		}

		// Bump target count by the source count (could be > 1 if source had
		// its own merge history or operator verification).
		$bump = max( 1, (int) $source->report_count );
		$ok2  = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET report_count = report_count + %d WHERE id = %d",
				$bump,
				$target_id
			)
		);
		if ( false === $ok2 ) {
			// Best-effort revert of ok1 since we cannot guarantee atomicity
			// without real transactions. The source rollback may itself fail
			// silently; that is acceptable since log captures the attempt.
			$wpdb->update(
				$table,
				array(
					'merged_into' => null,
					'status'      => $source->status,
					'archived_at' => $source->archived_at,
				),
				array( 'id' => $source_id ),
				array( '%d', '%s', '%s' ),
				array( '%d' )
			);
			return new WP_Error( self::ERR_UPDATE_FAILED, __( 'Could not update target count.', 'helpnagaland-core' ) );
		}

		self::log_action(
			HNC_Logger::ACTION_MERGE,
			$source_id,
			array(
				'merged_into' => $target_id,
				'count_added' => $bump,
			)
		);
		return true;
	}

	/**
	 * Unmerge a previously-merged source row. Restores it to the last known
	 * pre-merge status (best effort: set back to pending for re-review).
	 *
	 * @param int $source_id Source report ID.
	 * @return true|WP_Error
	 */
	public static function unmerge( $source_id ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$source_id = (int) $source_id;
		$source    = self::fetch_or_error( $source_id );
		if ( is_wp_error( $source ) ) {
			return $source;
		}

		if ( (int) $source->merged_into <= 0 ) {
			return new WP_Error( self::ERR_BAD_TARGET, __( 'This report is not merged.', 'helpnagaland-core' ) );
		}

		$target_id = (int) $source->merged_into;
		$bump_back = max( 1, (int) $source->report_count );

		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'alcohol_reports';

		$wpdb->update(
			$table,
			array(
				'merged_into' => null,
				'status'      => HNC_Alcohol_Submit::STATUS_PENDING,
				'archived_at' => null,
			),
			array( 'id' => $source_id ),
			array( '%d', '%s', '%s' ),
			array( '%d' )
		);

		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET report_count = GREATEST(1, report_count - %d) WHERE id = %d",
				$bump_back,
				$target_id
			)
		);

		self::log_action(
			HNC_Logger::ACTION_UNMERGE,
			$source_id,
			array( 'was_merged_into' => $target_id )
		);
		return true;
	}


	/* ------------------------------------------------------------------
	 * READS
	 * ------------------------------------------------------------------ */

	/**
	 * Return a paginated list of reports for the moderation queue.
	 *
	 * @param array $filters {
	 *     Optional filters.
	 *     @type string $status      'pending', 'hold', 'approved', 'rejected', 'archived', or 'all'.
	 *     @type string $district    Filter by district.
	 *     @type string $category    Filter by category key.
	 *     @type int    $per_page    Page size (max 100, default 20).
	 *     @type int    $page        1-based page number.
	 * }
	 * @return array|WP_Error { items: array, total: int, page: int, per_page: int }
	 */
	public static function get_queue( $filters = array() ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'alcohol_reports';

		$status     = isset( $filters['status'] ) ? (string) $filters['status'] : HNC_Alcohol_Submit::STATUS_PENDING;
		$district   = isset( $filters['district'] ) ? (string) $filters['district'] : '';
		$category   = isset( $filters['category'] ) ? (string) $filters['category'] : '';
		$per_page   = isset( $filters['per_page'] ) ? max( 1, min( 100, (int) $filters['per_page'] ) ) : 20;
		$page       = isset( $filters['page'] ) ? max( 1, (int) $filters['page'] ) : 1;
		$offset     = ( $page - 1 ) * $per_page;

		$where  = array();
		$params = array();

		if ( 'all' !== $status ) {
			$where[]  = 'status = %s';
			$params[] = $status;
		}
		if ( '' !== $district ) {
			$where[]  = 'district = %s';
			$params[] = $district;
		}
		if ( '' !== $category ) {
			$where[]  = 'category = %s';
			$params[] = $category;
		}

		$where_sql = empty( $where ) ? '' : ' WHERE ' . implode( ' AND ', $where );

		// Count total.
		$count_sql = "SELECT COUNT(*) FROM {$table}{$where_sql}";
		$total     = (int) ( empty( $params )
			? $wpdb->get_var( $count_sql )
			: $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) )
		);

		// Fetch page.
		$list_sql = "SELECT id, public_code, lat, lng, district, category, description, time_pattern,
			photo_uuid, status, verified_by_operator, merged_into, report_count,
			submitted_at, moderated_at, moderator_id, rejection_reason
			FROM {$table}{$where_sql}
			ORDER BY submitted_at DESC LIMIT %d OFFSET %d";

		$full_params = array_merge( $params, array( $per_page, $offset ) );
		$rows        = $wpdb->get_results( $wpdb->prepare( $list_sql, $full_params ) );

		return array(
			'rows'     => is_array( $rows ) ? $rows : array(),
			'total'    => $total,
			'page'     => $page,
			'per_page' => $per_page,
		);
	}

	/**
	 * Fetch a single report for moderator view.
	 *
	 * Returns the full row including photo_uuid and device_hash. Callers
	 * should NEVER echo these to anywhere but the admin interface.
	 *
	 * @param int $id Report ID.
	 * @return object|WP_Error
	 */
	public static function get_report( $id ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}
		return self::fetch_or_error( (int) $id );
	}

	/**
	 * Public status lookup by tracking code. Returns a narrow, public-safe
	 * view of the report, or null if the code is unknown or points to a
	 * status that should not be exposed publicly (archived).
	 *
	 * Unlike get_report, this method is safe to call without any capability
	 * because the output is explicitly scrubbed of PII, raw GPS, device
	 * hash, moderator notes, and photo UUIDs.
	 *
	 * @param string $code Canonical XXXX-XXXX code.
	 * @return array|null
	 */
	public static function get_public_status_by_code( $code ) {
		$code = class_exists( 'HNC_Codes' ) ? HNC_Codes::normalize( $code ) : '';
		if ( '' === $code ) {
			return null;
		}

		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'alcohol_reports';
		$row   = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT public_code, district, category, status, submitted_at, moderated_at, verified_by_operator, report_count, rejection_reason
				 FROM {$table}
				 WHERE public_code = %s
				 LIMIT 1",
				$code
			)
		);
		if ( ! $row ) {
			return null;
		}

		// Archived rows are not shown publicly.
		if ( 'archived' === (string) $row->status ) {
			return null;
		}

		$out = array(
			'code'                 => (string) $row->public_code,
			'status'               => (string) $row->status,
			'district'             => (string) $row->district,
			'category'             => (string) $row->category,
			'submitted_at'         => (string) $row->submitted_at,
			'moderated_at'         => (string) $row->moderated_at,
			'verified_by_operator' => (int) $row->verified_by_operator === 1,
			'report_count'         => (int) $row->report_count,
		);

		if ( 'rejected' === (string) $row->status ) {
			$out['rejection_reason'] = (string) $row->rejection_reason;
		}

		return $out;
	}


	/* ------------------------------------------------------------------
	 * INTERNAL HELPERS
	 * ------------------------------------------------------------------ */

	/**
	 * Capability gate. Returns WP_Error on denial.
	 *
	 * @return true|WP_Error
	 */
	private static function require_cap() {
		$cap = class_exists( 'HNC_Roles' ) ? HNC_Roles::CAP_MODERATE_ALCOHOL : 'hnc_moderate_alcohol';
		if ( ! function_exists( 'current_user_can' ) || ! current_user_can( $cap ) ) {
			return new WP_Error(
				self::ERR_UNAUTHORIZED,
				__( 'You do not have permission to moderate alcohol reports.', 'helpnagaland-core' )
			);
		}
		return true;
	}

	/**
	 * Fetch a report row by ID or return WP_Error.
	 *
	 * @param int $id Report ID.
	 * @return object|WP_Error
	 */
	private static function fetch_or_error( $id ) {
		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'alcohol_reports';
		$row   = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d LIMIT 1", (int) $id )
		);
		if ( ! $row ) {
			return new WP_Error(
				self::ERR_NOT_FOUND,
				__( 'Report not found.', 'helpnagaland-core' )
			);
		}
		return $row;
	}

	/**
	 * Write a status change with moderator stamp. Additional column updates
	 * can be passed as $extras. Returns true on success, false on failure.
	 *
	 * @param int    $id     Report ID.
	 * @param string $status New status value.
	 * @param array  $extras Extra column => value pairs.
	 * @return bool
	 */
	private static function write_status( $id, $status, $extras = array() ) {
		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'alcohol_reports';

		$data = array_merge(
			array(
				'status'       => $status,
				'moderated_at' => current_time( 'mysql' ),
				'moderator_id' => get_current_user_id() ? (int) get_current_user_id() : null,
			),
			is_array( $extras ) ? $extras : array()
		);

		// Build format array. Integers for moderator_id; floats for
		// geographic coordinates; strings for everything else.
		$formats = array();
		foreach ( $data as $col => $val ) {
			if ( 'moderator_id' === $col ) {
				$formats[] = '%d';
			} elseif ( 'lat' === $col || 'lng' === $col ) {
				$formats[] = '%f';
			} else {
				$formats[] = '%s';
			}
		}

		$ok = $wpdb->update( $table, $data, array( 'id' => (int) $id ), $formats, array( '%d' ) );
		return ( false !== $ok );
	}

	/**
	 * Log a moderation action with standard alcohol pipeline event.
	 *
	 * @param string $action Action key.
	 * @param int    $id     Report ID.
	 * @param array  $detail Extra detail.
	 * @return void
	 */
	private static function log_action( $action, $id, $detail = array() ) {
		if ( ! class_exists( 'HNC_Logger' ) ) {
			return;
		}
		HNC_Logger::log_alcohol( (string) $action, (int) $id, is_array( $detail ) ? $detail : array() );
	}
}
