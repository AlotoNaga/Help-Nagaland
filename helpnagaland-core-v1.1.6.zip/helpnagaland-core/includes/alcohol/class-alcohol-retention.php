<?php
/**
 * Alcohol pipeline: retention cron workers.
 *
 * Three background jobs run daily to keep the alcohol pipeline tidy and
 * to minimize data liability:
 *
 *   1. photo_cleanup()
 *        Hooks: hnc_alcohol_photo_cleanup (HNC_Cron::HOOK_ALCOHOL_PHOTO)
 *        Runs:  daily at 02:15 IST.
 *        Job:   For every approved or archived pin whose submitted_at is
 *               older than hnc_photo_retention_days (default 30), delete
 *               the stored photo file and NULL the photo_uuid/photo_hash
 *               columns. The pin itself stays visible on the map. This
 *               enforces the 30-day photo ceiling without removing pins.
 *
 *   2. archive_old_pins()
 *        Hooks: hnc_alcohol_archive_old_pins (HNC_Cron::HOOK_ALCOHOL_ARCHIVE)
 *        Runs:  daily at 02:30 IST.
 *        Job:   For approved pins older than hnc_alcohol_archive_months
 *               (default 12 months), move status to archived. Archived
 *               pins are no longer returned by the public map but remain
 *               in the database for reference and transparency.
 *
 *   3. purge_rejected()
 *        Hooks: hnc_alcohol_purge_rejected (HNC_Cron::HOOK_ALCOHOL_PURGE)
 *        Runs:  daily at 02:45 IST.
 *        Job:   For rejected rows older than hnc_alcohol_rejected_purge_days
 *               (default 7 days), DELETE the row entirely. The photo was
 *               already removed by the reject action, so this is just row
 *               cleanup.
 *
 * Every worker logs its result via HNC_Logger::log_system. The main plugin
 * wires the callbacks from init().
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Alcohol_Retention
 */
final class HNC_Alcohol_Retention {


	/* ------------------------------------------------------------------
	 * BOOTSTRAP
	 * ------------------------------------------------------------------ */

	/**
	 * Register cron callback hooks. Called from the main plugin file on
	 * plugins_loaded. The actual schedule rows are maintained by HNC_Cron.
	 *
	 * @return void
	 */
	public static function init() {
		if ( ! class_exists( 'HNC_Cron' ) ) {
			return;
		}
		add_action( HNC_Cron::HOOK_ALCOHOL_PHOTO, array( __CLASS__, 'photo_cleanup' ) );
		add_action( HNC_Cron::HOOK_ALCOHOL_ARCHIVE, array( __CLASS__, 'archive_old_pins' ) );
		add_action( HNC_Cron::HOOK_ALCOHOL_PURGE, array( __CLASS__, 'purge_rejected' ) );
	}


	/* ------------------------------------------------------------------
	 * WORKER 1: PHOTO CLEANUP
	 * ------------------------------------------------------------------ */

	/**
	 * Delete photos older than the retention window. The row is kept on the
	 * public map, but photo_uuid and photo_hash are cleared so nothing can
	 * serve the file even if it somehow survived on disk.
	 *
	 * @return array Counts { photos_deleted, rows_updated }.
	 */
	public static function photo_cleanup() {
		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'alcohol_reports';

		$days = (int) get_option( 'hnc_photo_retention_days', 30 );
		if ( $days < 1 ) {
			$days = 30;
		}
		$cutoff_ts  = time() - ( $days * DAY_IN_SECONDS );
		$cutoff_str = gmdate( 'Y-m-d H:i:s', $cutoff_ts );

		// Fetch all candidates. We need the photo_uuid to delete the file,
		// which dbDelta row updates cannot do.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, photo_uuid
				FROM {$table}
				WHERE photo_uuid IS NOT NULL
				  AND photo_uuid != ''
				  AND submitted_at < %s
				LIMIT 500",
				$cutoff_str
			)
		);

		if ( ! is_array( $rows ) ) {
			$rows = array();
		}

		$photos_deleted = 0;
		$rows_updated   = 0;

		foreach ( $rows as $r ) {
			if ( class_exists( 'HNC_Media' ) && ! empty( $r->photo_uuid ) ) {
				$deleted = HNC_Media::delete_by_uuid( 'alcohol', (string) $r->photo_uuid );
				if ( $deleted ) {
					$photos_deleted++;
				}
			}

			$ok = $wpdb->update(
				$table,
				array(
					'photo_uuid' => null,
					'photo_hash' => null,
				),
				array( 'id' => (int) $r->id ),
				array( '%s', '%s' ),
				array( '%d' )
			);
			if ( false !== $ok ) {
				$rows_updated++;
			}
		}

		self::log(
			HNC_Logger::ACTION_PHOTO_PURGE,
			array(
				'pipeline'       => 'alcohol',
				'cutoff_days'    => $days,
				'photos_deleted' => $photos_deleted,
				'rows_updated'   => $rows_updated,
				'candidates'     => count( $rows ),
			)
		);

		return array(
			'photos_deleted' => $photos_deleted,
			'rows_updated'   => $rows_updated,
		);
	}


	/* ------------------------------------------------------------------
	 * WORKER 2: ARCHIVE OLD APPROVED PINS
	 * ------------------------------------------------------------------ */

	/**
	 * Archive approved pins that are older than the configured archive
	 * window. The row remains, but status becomes archived so the public
	 * map no longer shows the pin.
	 *
	 * @return int Number of rows archived.
	 */
	public static function archive_old_pins() {
		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'alcohol_reports';

		$months = (int) get_option( 'hnc_alcohol_archive_months', 12 );
		if ( $months < 1 ) {
			$months = 12;
		}
		$cutoff_ts  = time() - ( $months * 30 * DAY_IN_SECONDS );
		$cutoff_str = gmdate( 'Y-m-d H:i:s', $cutoff_ts );
		$now        = current_time( 'mysql' );

		$updated = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table}
				SET status = %s,
				    archived_at = %s
				WHERE status = %s
				  AND submitted_at < %s",
				HNC_Alcohol_Submit::STATUS_ARCHIVED,
				$now,
				HNC_Alcohol_Submit::STATUS_APPROVED,
				$cutoff_str
			)
		);

		$count = ( false === $updated ) ? 0 : (int) $updated;

		self::log(
			HNC_Logger::ACTION_ARCHIVE,
			array(
				'pipeline'       => 'alcohol',
				'cutoff_months'  => $months,
				'rows_archived'  => $count,
			)
		);

		return $count;
	}


	/* ------------------------------------------------------------------
	 * WORKER 3: PURGE REJECTED
	 * ------------------------------------------------------------------ */

	/**
	 * Delete rejected rows older than the purge window. Photos have already
	 * been removed at rejection time, so this is a pure DB row delete.
	 *
	 * @return int Number of rows deleted.
	 */
	public static function purge_rejected() {
		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'alcohol_reports';

		$days = (int) get_option( 'hnc_alcohol_rejected_purge_days', 7 );
		if ( $days < 1 ) {
			$days = 7;
		}
		$cutoff_ts  = time() - ( $days * DAY_IN_SECONDS );
		$cutoff_str = gmdate( 'Y-m-d H:i:s', $cutoff_ts );

		// Also handle any straggler photos still on disk for rejected rows.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, photo_uuid
				FROM {$table}
				WHERE status = %s
				  AND moderated_at IS NOT NULL
				  AND moderated_at < %s
				LIMIT 500",
				HNC_Alcohol_Submit::STATUS_REJECTED,
				$cutoff_str
			)
		);

		if ( ! is_array( $rows ) ) {
			$rows = array();
		}

		$deleted = 0;
		foreach ( $rows as $r ) {
			// Defensive: if for any reason the photo was not cleaned at
			// reject time, remove it now.
			if ( ! empty( $r->photo_uuid ) && class_exists( 'HNC_Media' ) ) {
				HNC_Media::delete_by_uuid( 'alcohol', (string) $r->photo_uuid );
			}

			$ok = $wpdb->delete(
				$table,
				array( 'id' => (int) $r->id ),
				array( '%d' )
			);
			if ( false !== $ok ) {
				$deleted++;
			}
		}

		self::log(
			HNC_Logger::ACTION_REPORT_PURGE,
			array(
				'pipeline'      => 'alcohol',
				'cutoff_days'   => $days,
				'rows_deleted'  => $deleted,
				'candidates'    => count( $rows ),
			)
		);

		return $deleted;
	}


	/* ------------------------------------------------------------------
	 * INTERNAL
	 * ------------------------------------------------------------------ */

	/**
	 * Log with the system event type so retention jobs are easily filtered
	 * in the audit log.
	 *
	 * @param string $action Action constant.
	 * @param array  $detail Detail payload.
	 * @return void
	 */
	private static function log( $action, $detail ) {
		if ( ! class_exists( 'HNC_Logger' ) ) {
			return;
		}
		HNC_Logger::log_system( (string) $action, is_array( $detail ) ? $detail : array() );
	}
}
