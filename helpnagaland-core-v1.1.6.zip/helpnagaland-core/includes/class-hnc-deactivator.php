<?php
/**
 * Plugin deactivation handler.
 *
 * Deactivation is NOT the same as uninstall. When the admin clicks
 * "Deactivate" in the WP plugins screen, WordPress calls this handler.
 *
 * Important: deactivation must NEVER delete user data, database tables,
 * or uploaded media. The admin expects that deactivating a plugin is
 * reversible. Data destruction happens only on uninstall, and only if
 * the admin has explicitly opted in via the Danger Zone setting.
 *
 * Responsibilities of deactivate():
 *
 *   1. Unschedule all cron events registered by the plugin.
 *   2. Flush rewrite rules (cheap, avoids stale REST routes).
 *
 * Responsibilities deactivate() explicitly does NOT perform:
 *
 *   - Does NOT drop tables.
 *   - Does NOT remove roles or capabilities.
 *   - Does NOT delete uploaded photos or media.
 *   - Does NOT delete options.
 *   - Does NOT delete the encrypted phone vault.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Deactivator
 */
final class HNC_Deactivator {


	/**
	 * Full list of cron event hooks used across the plugin.
	 *
	 * Phase 1 does not schedule any events itself, but this list is
	 * the single source of truth that later phases will register against.
	 * Keeping deactivation aware of the full list means that if we ever
	 * ship a version that forgets to unschedule a hook, the next
	 * deactivation still cleans it up.
	 *
	 * @return string[]
	 */
	public static function scheduled_events() {
		return array(
			'hnc_retention_sweep_daily',
			'hnc_alcohol_photo_cleanup',
			'hnc_alcohol_archive_old_pins',
			'hnc_alcohol_purge_rejected',
			'hnc_drug_media_cleanup',
			'hnc_drug_archive_old',
			'hnc_drug_purge_rejected',
			'hnc_phone_vault_cleanup',
			'hnc_device_fingerprint_cleanup',
			'hnc_ip_salt_rotate_daily',
			'hnc_transparency_auto_publish_monthly',
			'hnc_audit_log_archive_yearly',
		);
	}


	/**
	 * Main deactivation entry point. Called from register_deactivation_hook.
	 *
	 * @return void
	 */
	public static function deactivate() {

		// 1. Unschedule all plugin cron events.
		self::clear_all_cron_events();

		// 2. Flush rewrite rules so stale REST routes are dropped from the rewrite cache.
		flush_rewrite_rules();

		// 3. Record deactivation time for audit / support purposes.
		update_option( 'hnc_deactivated_at', current_time( 'mysql' ) );

		/*
		 * DO NOT DO ANY OF THE FOLLOWING HERE:
		 *
		 *   - delete_option( 'anything' )
		 *   - HNC_Schema::drop_all()
		 *   - wp_delete_file(...) on uploads
		 *   - HNC_Roles::remove_all()
		 *
		 * All destructive operations live in uninstall.php and run only when
		 * the admin has explicitly confirmed via the Danger Zone setting.
		 */
	}


	/**
	 * Unschedule every cron event registered by the plugin.
	 * Idempotent: safe to call when events are not scheduled.
	 *
	 * @return void
	 */
	private static function clear_all_cron_events() {
		foreach ( self::scheduled_events() as $hook ) {
			// wp_next_scheduled returns false if not scheduled.
			$timestamp = wp_next_scheduled( $hook );
			while ( false !== $timestamp ) {
				wp_unschedule_event( $timestamp, $hook );
				$timestamp = wp_next_scheduled( $hook );
			}
			// Belt and braces: wp_clear_scheduled_hook removes all occurrences.
			wp_clear_scheduled_hook( $hook );
		}
	}
}
