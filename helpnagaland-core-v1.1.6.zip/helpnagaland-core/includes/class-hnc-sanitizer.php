<?php
/**
 * Input sanitization.
 *
 * Every piece of text submitted by a citizen passes through this class before
 * it reaches the database. Sanitization is stricter than typical WordPress
 * practice because we enforce two platform rules at this layer:
 *
 *   1. No individual names. Submissions describe locations and patterns,
 *      not people. We strip common name and honorific patterns. This is
 *      imperfect by nature. Moderation is the last line of defense.
 *
 *   2. No contact details embedded in prose. Phone numbers and email
 *      addresses are stripped from description and pattern fields so a
 *      reporter cannot inadvertently leak a third party contact detail.
 *
 * The class also handles length limits, HTML stripping, whitespace
 * normalization, and null byte removal.
 *
 * Important: sanitization here does NOT replace validation. Validation
 * happens in the submission handlers (phase 3+). Sanitization only cleans
 * input; validation decides whether to accept it.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Sanitizer
 */
final class HNC_Sanitizer {


	/* ------------------------------------------------------------------
	 * PRIMARY SANITIZERS (BY FIELD)
	 * ------------------------------------------------------------------ */

	/**
	 * Sanitize an alcohol report description field.
	 * Strips HTML, names, phone numbers, emails. Trims to 300 chars.
	 *
	 * @param string $text Raw input.
	 * @return string
	 */
	public static function alcohol_description( $text ) {
		return self::sanitize_free_text( $text, 300 );
	}

	/**
	 * Sanitize a drug report pattern field.
	 * Strips HTML, names, phone numbers, emails. Trims to 500 chars.
	 *
	 * @param string $text Raw input.
	 * @return string
	 */
	public static function drug_pattern( $text ) {
		return self::sanitize_free_text( $text, 500 );
	}

	/**
	 * Sanitize a drug report area description.
	 * Strips HTML, names, phone numbers, emails. Trims to 200 chars.
	 * Additionally strips anything that looks like a house number at the start.
	 *
	 * @param string $text Raw input.
	 * @return string
	 */
	public static function area_description( $text ) {
		$clean = self::sanitize_free_text( $text, 200 );
		// Strip leading house number patterns like "HN 12" or "#45".
		$clean = preg_replace( '/^\s*(HN[.\s]*|H\.?\s*No\.?\s*|#)\d+[A-Za-z\-\/]*[,\s]*/i', '', $clean );
		return trim( (string) $clean );
	}

	/**
	 * Sanitize vehicle info. Allowed: make, colour, partial plate. Length 100.
	 * Additionally: rejects anything that looks like a full Indian licence plate
	 * (NL01AB1234 pattern) and keeps only a partial.
	 *
	 * @param string $text Raw input.
	 * @return string
	 */
	public static function vehicle_info( $text ) {
		$clean = self::sanitize_free_text( $text, 100 );
		// Mask full Indian plate like "NL01AB1234" down to "NL01AB****".
		$clean = preg_replace(
			'/\b([A-Z]{2}\s?\d{1,2}\s?[A-Z]{1,3})\s?(\d{4})\b/i',
			'$1****',
			$clean
		);
		return trim( (string) $clean );
	}

	/**
	 * Sanitize a rejection reason (admin-entered).
	 * Less aggressive: admins can refer to categories and policy numbers.
	 * Strips HTML and limits length.
	 *
	 * @param string $text Raw input.
	 * @return string
	 */
	public static function rejection_reason( $text ) {
		$clean = self::strip_html( $text );
		$clean = self::normalize_whitespace( $clean );
		$clean = self::remove_control_chars( $clean );
		return self::truncate( $clean, 120 );
	}

	/**
	 * Sanitize an admin note on a transparency snapshot.
	 * Allows multiple paragraphs, but strips HTML and normalizes whitespace.
	 * Admin content, so NOT run through name stripper.
	 *
	 * @param string $text Raw input.
	 * @return string
	 */
	public static function admin_note( $text ) {
		$clean = self::strip_html( $text );
		$clean = self::remove_control_chars( $clean );
		// Normalize line endings; keep paragraph breaks.
		$clean = str_replace( array( "\r\n", "\r" ), "\n", (string) $clean );
		$clean = preg_replace( "/\n{3,}/", "\n\n", $clean );
		return self::truncate( trim( $clean ), 1500 );
	}

	/**
	 * Sanitize a phone number. Strips everything except digits, returns a
	 * properly formatted E.164 number with the leading plus sign so it can be
	 * displayed or passed to tel: links without further processing.
	 *
	 * Policy:
	 *   - 10 digits: treated as an Indian mobile. First digit MUST be
	 *     6, 7, 8 or 9 (valid DoT mobile prefixes). Landline-only
	 *     fixed-line numbers are rejected. India country code 91 is
	 *     prepended automatically.
	 *   - 11 digits starting with "0" + 10 mobile digits: the leading
	 *     "0" is a trunk prefix used by some domestic carriers. It is
	 *     stripped and the remaining 10 digits are validated.
	 *   - 12 digits starting with "91": Indian number with country code
	 *     written without the +. Same 6-9 first-mobile-digit rule.
	 *   - 11 to 15 digits starting with any other country code: accepted
	 *     as-is (the platform supports cross-border reporters in rare
	 *     cases; moderation catches abuse).
	 *
	 * @param string $raw Raw input.
	 * @return string E.164 number like "+919876543210", or '' if invalid.
	 */
	public static function phone_number( $raw ) {
		$digits = preg_replace( '/\D+/', '', (string) $raw );
		if ( '' === $digits ) {
			return '';
		}
		// Strip Indian trunk "0" prefix on 11-digit inputs.
		if ( 11 === strlen( $digits ) && '0' === $digits[0] ) {
			$digits = substr( $digits, 1 );
		}
		// Strip country code prefix "91" on 12-digit Indian inputs so we
		// can validate the mobile prefix uniformly below.
		$is_indian_with_cc = ( 12 === strlen( $digits ) && 0 === strpos( $digits, '91' ) );
		if ( $is_indian_with_cc ) {
			$digits_without_cc = substr( $digits, 2 );
			if ( 10 === strlen( $digits_without_cc ) && preg_match( '/^[6-9]/', $digits_without_cc ) ) {
				return '+' . $digits;
			}
			// 12 digits starting with 91 but invalid mobile prefix: reject.
			return '';
		}
		// 10 digits: must be a valid Indian mobile prefix.
		if ( 10 === strlen( $digits ) ) {
			if ( ! preg_match( '/^[6-9]/', $digits ) ) {
				return '';
			}
			return '+91' . $digits;
		}
		// Anything else must be between 11 and 15 digits to be plausible.
		if ( strlen( $digits ) < 11 || strlen( $digits ) > 15 ) {
			return '';
		}
		return '+' . $digits;
	}

	/**
	 * Sanitize a category key. Must match [a-z_]+ and be in the allowed list
	 * for its pipeline. The pipeline is passed explicitly.
	 *
	 * @param string $raw      Raw input.
	 * @param string $pipeline 'alcohol' or 'drug'.
	 * @return string Valid category key, or empty string if invalid.
	 */
	public static function category_key( $raw, $pipeline ) {
		$raw = strtolower( trim( (string) $raw ) );
		if ( ! preg_match( '/^[a-z_]+$/', $raw ) ) {
			return '';
		}

		$option_key = ( 'drug' === $pipeline ) ? 'hnc_drug_categories' : 'hnc_alcohol_categories';
		$categories = json_decode( (string) get_option( $option_key, '[]' ), true );

		if ( is_array( $categories ) && array_key_exists( $raw, $categories ) ) {
			return $raw;
		}
		return '';
	}

	/**
	 * Sanitize a district name against the configured list.
	 *
	 * @param string $raw Raw input.
	 * @return string Valid district name, or empty string.
	 */
	public static function district( $raw ) {
		$raw = trim( (string) $raw );
		if ( '' === $raw ) {
			return '';
		}

		$districts = json_decode( (string) get_option( 'hnc_districts', '[]' ), true );
		if ( ! is_array( $districts ) ) {
			return '';
		}

		// Case insensitive match.
		foreach ( $districts as $d ) {
			if ( strcasecmp( $d, $raw ) === 0 ) {
				return $d; // Return canonical casing.
			}
		}
		return '';
	}

	/**
	 * Sanitize a time pattern key against the configured list.
	 *
	 * @param string $raw Raw input.
	 * @return string Valid key, or empty string.
	 */
	public static function time_pattern( $raw ) {
		$raw = strtolower( trim( (string) $raw ) );
		$raw = str_replace( ' ', '_', $raw );
		if ( '' === $raw ) {
			return '';
		}
		$patterns = json_decode( (string) get_option( 'hnc_time_patterns', '[]' ), true );
		if ( is_array( $patterns ) && array_key_exists( $raw, $patterns ) ) {
			return $raw;
		}
		return '';
	}

	/**
	 * Validate that a submission mode is one we support.
	 *
	 * @param string $raw Raw input.
	 * @return string 'anonymous' or 'phone', or empty string on invalid.
	 */
	public static function submission_mode( $raw ) {
		$raw = strtolower( trim( (string) $raw ) );
		return in_array( $raw, array( 'anonymous', 'phone' ), true ) ? $raw : '';
	}


	/* ------------------------------------------------------------------
	 * GENERIC TEXT SANITIZER
	 * ------------------------------------------------------------------
	 *
	 * Used by description-like fields. The full pipeline:
	 *
	 *   1. Strip all HTML tags and decode entities.
	 *   2. Remove control characters and null bytes.
	 *   3. Normalize whitespace to single spaces.
	 *   4. Strip email addresses.
	 *   5. Strip phone numbers.
	 *   6. Strip honorifics (Mr., Mrs., Dr., Shri, Smt., etc.).
	 *   7. Strip obvious name patterns.
	 *   8. Truncate to max length.
	 */

	/**
	 * Main pipeline for citizen-entered free text.
	 *
	 * @param string $text Raw input.
	 * @param int    $max  Maximum length in characters.
	 * @return string
	 */
	public static function sanitize_free_text( $text, $max ) {
		$s = (string) $text;
		$s = self::strip_html( $s );
		$s = self::remove_control_chars( $s );
		$s = self::normalize_whitespace( $s );
		$s = self::strip_emails( $s );
		$s = self::strip_phone_numbers( $s );
		$s = self::strip_honorifics_and_names( $s );
		$s = self::normalize_whitespace( $s );
		$s = trim( $s );
		return self::truncate( $s, $max );
	}


	/* ------------------------------------------------------------------
	 * PIPELINE STAGES
	 * ------------------------------------------------------------------ */

	/**
	 * Strip all HTML tags and decode entities.
	 *
	 * @param string $s Input.
	 * @return string
	 */
	public static function strip_html( $s ) {
		$s = (string) $s;
		// Remove tags.
		if ( function_exists( 'wp_strip_all_tags' ) ) {
			$s = wp_strip_all_tags( $s, true );
		} else {
			$s = strip_tags( $s );
		}
		// Decode HTML entities so "&amp;" does not survive as text.
		$s = html_entity_decode( $s, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		return $s;
	}

	/**
	 * Remove control characters except tab and newline. Also removes null bytes.
	 *
	 * @param string $s Input.
	 * @return string
	 */
	public static function remove_control_chars( $s ) {
		return preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', (string) $s );
	}

	/**
	 * Collapse whitespace runs to a single space.
	 *
	 * @param string $s Input.
	 * @return string
	 */
	public static function normalize_whitespace( $s ) {
		return preg_replace( '/\s+/u', ' ', (string) $s );
	}

	/**
	 * Strip email addresses.
	 *
	 * @param string $s Input.
	 * @return string
	 */
	public static function strip_emails( $s ) {
		return preg_replace( '/[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}/i', '[email removed]', (string) $s );
	}

	/**
	 * Strip phone number patterns.
	 * Matches sequences of 10 to 15 digits possibly with +, spaces, or dashes.
	 *
	 * @param string $s Input.
	 * @return string
	 */
	public static function strip_phone_numbers( $s ) {
		// Match patterns like +91 98765 43210, 9876543210, (98765) 43210, etc.
		$patterns = array(
			'/\+?\d{1,3}[\s\-]?\(?\d{2,4}\)?[\s\-]?\d{3,4}[\s\-]?\d{3,4}/u',
			'/\b\d{10,15}\b/u',
		);
		foreach ( $patterns as $p ) {
			$s = preg_replace( $p, '[phone removed]', (string) $s );
		}
		return (string) $s;
	}

	/**
	 * Strip honorifics and common name patterns.
	 *
	 * This is a best-effort heuristic. It cannot catch every name, because
	 * names overlap with ordinary words in Naga languages and in English.
	 * Moderation remains the final filter.
	 *
	 * Strategy:
	 *   - Remove explicit honorifics (Mr., Mrs., Shri, etc.)
	 *   - Remove "Mr X", "Mrs Y" style phrases
	 *   - Remove generic "so-and-so" markers
	 *   - Flag 2+ consecutive capitalized words at the start of sentences
	 *     as potential names (replace with [name removed])
	 *
	 * @param string $s Input.
	 * @return string
	 */
	public static function strip_honorifics_and_names( $s ) {
		$s = (string) $s;

		// Honorific tokens to strip when followed by a name-like word.
		$honorifics = array(
			'Mr\.?', 'Mrs\.?', 'Ms\.?', 'Dr\.?', 'Prof\.?', 'Sir', 'Madam', 'Ma\'?am',
			'Shri', 'Smt\.?', 'Sri', 'Kumari', 'Kumar',
			'Mister', 'Miss', 'Missus', 'Pastor', 'Rev\.?', 'Reverend',
			'Hon\.?ble', 'Honourable', 'Hon\.?',
		);
		$honor_re   = '/\b(' . implode( '|', $honorifics ) . ')\s+[A-Z][A-Za-z\'\-]{1,}(?:\s+[A-Z][A-Za-z\'\-]{1,})?/u';
		$s          = preg_replace( $honor_re, '[name removed]', $s );

		// Also remove bare honorifics.
		$bare_honor_re = '/\b(' . implode( '|', $honorifics ) . ')\b/u';
		$s             = preg_replace( $bare_honor_re, '', $s );

		// Generic "so-and-so" markers.
		$s = preg_replace( '/\b(so[\s\-]?and[\s\-]?so|such[\s\-]?and[\s\-]?such)\b/i', '[name removed]', (string) $s );

		// "named X" or "called X" patterns.
		$s = preg_replace( '/\b(named|called)\s+[A-Z][A-Za-z\'\-]{1,}(\s+[A-Z][A-Za-z\'\-]{1,})?/u', '$1 [name removed]', (string) $s );

		// "X ka beta" or similar Hindi/Naga constructions with a leading capitalized word.
		// Too risky to match these without false positives; rely on moderation.

		return (string) $s;
	}


	/* ------------------------------------------------------------------
	 * STRING HELPERS
	 * ------------------------------------------------------------------ */

	/**
	 * Truncate a UTF-8 string to a max character count.
	 *
	 * @param string $s   Input.
	 * @param int    $max Max character count.
	 * @return string
	 */
	public static function truncate( $s, $max ) {
		$s   = (string) $s;
		$len = function_exists( 'mb_strlen' ) ? mb_strlen( $s, 'UTF-8' ) : strlen( $s );
		if ( $len <= $max ) {
			return $s;
		}
		if ( function_exists( 'mb_substr' ) ) {
			return mb_substr( $s, 0, $max, 'UTF-8' );
		}
		return substr( $s, 0, $max );
	}
}
