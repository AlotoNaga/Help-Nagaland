<?php
/**
 * Drug pipeline: retention cron workers.
 *
 * Three daily workers keep drug data minimized:
 *
 *   1. media_cleanup()
 *        Hook:  hnc_drug_media_cleanup (HNC_Cron::HOOK_DRUG_MEDIA)
 *        Runs:  daily at 03:00 IST.
 *        Job:   Delete drug media files (photos, videos) whose rows are
 *               older than hnc_drug_media_retention_days (default 90).
 *               Row stays; media columns are nulled. The caseload record
 *               persists for moderator reference.
 *
 *   2. archive_old()
 *        Hook:  hnc_drug_archive_old (HNC_Cron::HOOK_DRUG_ARCHIVE)
 *        Runs:  daily at 03:15 IST.
 *        Job:   Archive approved or resolved drug reports older than
 *               hnc_drug_archive_months (default 24). Pending, hold, and
 *               rejected reports are not touched by this worker.
 *
 *   3. purge_rejected()
 *        Hook:  hnc_drug_purge_rejected (HNC_Cron::HOOK_DRUG_PURGE)
 *        Runs:  daily at 03:30 IST.
 *        Job:   Delete rejected rows older than
 *               hnc_drug_rejected_purge_hours (default 24). Also sweeps
 *               orphaned phone vault entries linked to deleted rows, if
 *               HNC_Phone_Vault is deployed.
 *
 * Drug retention is stricter than alcohol. Rejected rows are purged in
 * hours, not days, because drug reports contain more sensitive text.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Drug_Retention
 */
final class HNC_Drug_Retention {


	/* ------------------------------------------------------------------
	 * BOOTSTRAP
	 * ------------------------------------------------------------------ */

	/**
	 * Register cron callbacks. Called from the main plugin on plugins_loaded.
	 * The schedules themselves live in HNC_Cron::schedule_table().
	 *
	 * @return void
	 */
	public static function init() {
		if ( ! class_exists( 'HNC_Cron' ) ) {
			return;
		}
		add_action( HNC_Cron::HOOK_DRUG_MEDIA, array( __CLASS__, 'media_cleanup' ) );
		add_action( HNC_Cron::HOOK_DRUG_ARCHIVE, array( __CLASS__, 'archive_old' ) );
		add_action( HNC_Cron::HOOK_DRUG_PURGE, array( __CLASS__, 'purge_rejected' ) );
	}


	/* ------------------------------------------------------------------
	 * WORKER 1: MEDIA CLEANUP
	 * ------------------------------------------------------------------ */

	/**
	 * Delete drug media files older than the retention window. The row is
	 * kept in the database with media columns nulled.
	 *
	 * @return array { files_deleted, rows_updated }.
	 */
	public static function media_cleanup() {
		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'drug_reports';

		$days = (int) get_option( 'hnc_drug_media_retention_days', 90 );
		if ( $days < 1 ) {
			$days = 90;
		}
		$cutoff_ts  = time() - ( $days * DAY_IN_SECONDS );
		$cutoff_str = gmdate( 'Y-m-d H:i:s', $cutoff_ts );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, media_uuid
				FROM {$table}
				WHERE media_uuid IS NOT NULL
				  AND media_uuid != ''
				  AND submitted_at < %s
				LIMIT 500",
				$cutoff_str
			)
		);

		if ( ! is_array( $rows ) ) {
			$rows = array();
		}

		$files_deleted = 0;
		$rows_updated  = 0;

		foreach ( $rows as $r ) {
			if ( class_exists( 'HNC_Media' ) && ! empty( $r->media_uuid ) ) {
				$deleted = HNC_Media::delete_by_uuid( 'drug', (string) $r->media_uuid );
				if ( $deleted ) {
					$files_deleted++;
				}
			}

			$ok = $wpdb->update(
				$table,
				array(
					'media_uuid' => null,
					'media_type' => null,
					'media_hash' => null,
				),
				array( 'id' => (int) $r->id ),
				array( '%s', '%s', '%s' ),
				array( '%d' )
			);
			if ( false !== $ok ) {
				$rows_updated++;
			}
		}

		self::log(
			HNC_Logger::ACTION_PHOTO_PURGE,
			array(
				'pipeline'      => 'drug',
				'cutoff_days'   => $days,
				'files_deleted' => $files_deleted,
				'rows_updated'  => $rows_updated,
				'candidates'    => count( $rows ),
			)
		);

		return array(
			'files_deleted' => $files_deleted,
			'rows_updated'  => $rows_updated,
		);
	}


	/* ------------------------------------------------------------------
	 * WORKER 2: ARCHIVE OLD APPROVED / RESOLVED
	 * ------------------------------------------------------------------ */

	/**
	 * Move old approved or resolved drug reports to archived.
	 *
	 * @return int Number of rows archived.
	 */
	public static function archive_old() {
		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'drug_reports';

		$months = (int) get_option( 'hnc_drug_archive_months', 24 );
		if ( $months < 1 ) {
			$months = 24;
		}
		$cutoff_ts  = time() - ( $months * 30 * DAY_IN_SECONDS );
		$cutoff_str = gmdate( 'Y-m-d H:i:s', $cutoff_ts );
		$now        = current_time( 'mysql' );

		$updated = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table}
				SET status = %s,
				    archived_at = %s
				WHERE status IN (%s, %s)
				  AND submitted_at < %s",
				HNC_Drug_Submit::STATUS_ARCHIVED,
				$now,
				HNC_Drug_Submit::STATUS_APPROVED,
				HNC_Drug_Submit::STATUS_RESOLVED,
				$cutoff_str
			)
		);

		$count = ( false === $updated ) ? 0 : (int) $updated;

		self::log(
			HNC_Logger::ACTION_ARCHIVE,
			array(
				'pipeline'      => 'drug',
				'cutoff_months' => $months,
				'rows_archived' => $count,
			)
		);

		return $count;
	}


	/* ------------------------------------------------------------------
	 * WORKER 3: PURGE REJECTED
	 * ------------------------------------------------------------------ */

	/**
	 * Delete rejected rows older than the purge window. Drug rejected
	 * purge is in HOURS (default 24) not days, for data minimization.
	 * Also deletes any orphaned phone vault entries the row had pointed to.
	 *
	 * @return int Number of rows deleted.
	 */
	public static function purge_rejected() {
		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'drug_reports';

		/*
		 * Option stores the purge window in HOURS (not days) because the
		 * drug pipeline's minimisation requirement is stricter than
		 * alcohol. A freshly installed plugin gets 24. Values below 1
		 * are clamped to the default to prevent "rejected rows never
		 * purged" config errors. Values above 720 (30 days) are also
		 * clamped — if you need data kept longer than 30 days, rethink
		 * the retention model, don't stretch this option.
		 */
		$hours = (int) get_option( 'hnc_drug_rejected_purge_hours', 24 );
		if ( $hours < 1 ) {
			$hours = 24;
		}
		if ( $hours > 720 ) {
			$hours = 720;
		}
		$cutoff_ts  = time() - ( $hours * HOUR_IN_SECONDS );
		$cutoff_str = gmdate( 'Y-m-d H:i:s', $cutoff_ts );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, media_uuid, phone_vault_id
				FROM {$table}
				WHERE status = %s
				  AND moderated_at IS NOT NULL
				  AND moderated_at < %s
				LIMIT 500",
				HNC_Drug_Submit::STATUS_REJECTED,
				$cutoff_str
			)
		);

		if ( ! is_array( $rows ) ) {
			$rows = array();
		}

		$deleted = 0;
		foreach ( $rows as $r ) {
			// Defensive media cleanup in case reject-time deletion missed it.
			if ( ! empty( $r->media_uuid ) && class_exists( 'HNC_Media' ) ) {
				HNC_Media::delete_by_uuid( 'drug', (string) $r->media_uuid );
			}

			// Clean up orphaned phone vault entry.
			if ( ! empty( $r->phone_vault_id )
				&& class_exists( 'HNC_Phone_Vault' )
				&& is_callable( array( 'HNC_Phone_Vault', 'delete' ) ) ) {
				HNC_Phone_Vault::delete( (int) $r->phone_vault_id );
			}

			$ok = $wpdb->delete(
				$table,
				array( 'id' => (int) $r->id ),
				array( '%d' )
			);
			if ( false !== $ok ) {
				$deleted++;
			}
		}

		self::log(
			HNC_Logger::ACTION_REPORT_PURGE,
			array(
				'pipeline'     => 'drug',
				'cutoff_hours' => $hours,
				'rows_deleted' => $deleted,
				'candidates'   => count( $rows ),
			)
		);

		return $deleted;
	}


	/* ------------------------------------------------------------------
	 * INTERNAL
	 * ------------------------------------------------------------------ */

	/**
	 * Log via HNC_Logger::log_system so cron jobs are easy to filter.
	 *
	 * @param string $action Action key.
	 * @param array  $detail Payload.
	 * @return void
	 */
	private static function log( $action, $detail ) {
		if ( ! class_exists( 'HNC_Logger' ) ) {
			return;
		}
		HNC_Logger::log_system( (string) $action, is_array( $detail ) ? $detail : array() );
	}
}
