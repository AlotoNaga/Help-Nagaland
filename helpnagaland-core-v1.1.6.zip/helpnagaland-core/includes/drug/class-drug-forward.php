<?php
/**
 * Drug pipeline: forward a report to a partner organization.
 *
 * Forwarding is how Nagaland Me hands an approved drug report to a vetted
 * partner for action. Partners include civil society groups, recovery
 * organizations, or law enforcement liaisons that have been onboarded
 * under the partner program (Phase 10, deferred).
 *
 * What forward does now (Phase 4):
 *
 *   - Require hnc_forward_drug capability.
 *   - Require the report to be in approved status.
 *   - Accept a partner identifier (numeric partner_id once Phase 10 is in
 *     place, or an opaque slug in the meantime).
 *   - Accept an optional free-text note.
 *   - Write an audit log entry with event=drug, action=forward, detail
 *     containing the partner identifier and note. The audit log is the
 *     authoritative record of who was informed when.
 *   - Do NOT change report status. A forwarded report stays approved so
 *     the same report can be forwarded to multiple partners if the case
 *     involves multiple specialties (for example a health partner AND a
 *     legal partner).
 *
 * Phase 10 will extend this class to:
 *
 *   - Check the partner record exists in the hnc_partners table.
 *   - Send an email or in-app notification to the partner.
 *   - Grant the partner view access to the specific report through the
 *     partner dashboard.
 *
 * None of that is needed yet, because the partner directory does not
 * exist. The class is built now so Phase 7's admin UI can have a
 * "Forward" button that writes a durable record.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Drug_Forward
 */
final class HNC_Drug_Forward {


	const ERR_UNAUTHORIZED     = 'hnc_unauthorized';
	const ERR_NOT_FOUND        = 'hnc_report_not_found';
	const ERR_BAD_STATUS       = 'hnc_bad_status_for_forward';
	const ERR_BAD_PARTNER      = 'hnc_bad_partner_identifier';
	const ERR_ALREADY_FORWARDED = 'hnc_already_forwarded_same_partner';


	/**
	 * Forward a drug report to a partner.
	 *
	 * @param int    $report_id          Drug report ID. Must be approved.
	 * @param string $partner_identifier Partner ID or slug (1 to 60 chars).
	 * @param string $note               Optional note (max 1500 chars, audit log only).
	 * @return true|WP_Error
	 */
	public static function forward( $report_id, $partner_identifier, $note = '' ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$report_id = (int) $report_id;
		if ( $report_id <= 0 ) {
			return new WP_Error( self::ERR_NOT_FOUND, __( 'Invalid report ID.', 'helpnagaland-core' ) );
		}

		$partner_identifier = self::sanitize_partner_identifier( $partner_identifier );
		if ( '' === $partner_identifier ) {
			return new WP_Error( self::ERR_BAD_PARTNER, __( 'Partner identifier is required.', 'helpnagaland-core' ) );
		}

		$row = self::fetch_row( $report_id );
		if ( null === $row ) {
			return new WP_Error( self::ERR_NOT_FOUND, __( 'Drug report not found.', 'helpnagaland-core' ) );
		}

		if ( HNC_Drug_Submit::STATUS_APPROVED !== $row->status ) {
			return new WP_Error(
				self::ERR_BAD_STATUS,
				sprintf(
					/* translators: %s: current status */
					__( 'Only approved drug reports can be forwarded. Current status: %s', 'helpnagaland-core' ),
					$row->status
				)
			);
		}

		// Prevent duplicate forwards to the same partner within a short window.
		if ( self::was_forwarded_recently( $report_id, $partner_identifier ) ) {
			return new WP_Error(
				self::ERR_ALREADY_FORWARDED,
				__( 'This report has already been forwarded to this partner in the last 24 hours.', 'helpnagaland-core' )
			);
		}

		$note_clean = class_exists( 'HNC_Sanitizer' )
			? HNC_Sanitizer::admin_note( $note )
			: substr( (string) $note, 0, 1500 );

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_drug(
				HNC_Logger::ACTION_FORWARD,
				$report_id,
				array(
					'partner'    => $partner_identifier,
					'note'       => $note_clean,
					'forwarded_by' => function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0,
				)
			);
		}

		/**
		 * Fires after a drug report is forwarded to a partner. Phase 10
		 * will hook this to send emails and grant partner access.
		 *
		 * @param int    $report_id          Drug report ID.
		 * @param string $partner_identifier Partner ID or slug.
		 * @param string $note               Clean note.
		 */
		do_action( 'hnc_drug_forwarded', $report_id, $partner_identifier, $note_clean );

		return true;
	}


	/* ------------------------------------------------------------------
	 * QUERIES
	 * ------------------------------------------------------------------ */

	/**
	 * Return the list of forward events for a given drug report, most
	 * recent first. Reads from the audit log.
	 *
	 * Output rows have:
	 *   - forwarded_at (ISO string)
	 *   - partner (string)
	 *   - note (string)
	 *   - forwarded_by (int user ID)
	 *
	 * @param int $report_id Drug report ID.
	 * @return array
	 */
	public static function get_history( $report_id ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return array();
		}

		global $wpdb;
		$audit_table = $wpdb->prefix . HNC_TABLE_PREFIX . 'audit_log';

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT created_at, detail, actor_id
				 FROM {$audit_table}
				 WHERE event_type = %s
				   AND action = %s
				   AND report_id = %d
				 ORDER BY created_at DESC
				 LIMIT 100",
				class_exists( 'HNC_Logger' ) ? HNC_Logger::EVENT_DRUG : 'drug',
				class_exists( 'HNC_Logger' ) ? HNC_Logger::ACTION_FORWARD : 'forward',
				(int) $report_id
			)
		);

		if ( ! is_array( $rows ) ) {
			return array();
		}

		$out = array();
		foreach ( $rows as $r ) {
			$detail = array();
			if ( ! empty( $r->detail ) ) {
				$decoded = json_decode( (string) $r->detail, true );
				if ( is_array( $decoded ) && isset( $decoded['detail'] ) && is_array( $decoded['detail'] ) ) {
					$detail = $decoded['detail'];
				} elseif ( is_array( $decoded ) ) {
					$detail = $decoded;
				}
			}
			$out[] = array(
				'forwarded_at' => (string) $r->created_at,
				'partner'      => isset( $detail['partner'] ) ? (string) $detail['partner'] : '',
				'note'         => isset( $detail['note'] ) ? (string) $detail['note'] : '',
				'forwarded_by' => isset( $detail['forwarded_by'] ) ? (int) $detail['forwarded_by'] : (int) $r->actor_id,
			);
		}
		return $out;
	}


	/* ------------------------------------------------------------------
	 * INTERNAL HELPERS
	 * ------------------------------------------------------------------ */

	/**
	 * Capability gate: hnc_forward_drug.
	 *
	 * @return true|WP_Error
	 */
	private static function require_cap() {
		$cap = class_exists( 'HNC_Roles' ) ? HNC_Roles::CAP_FORWARD_DRUG : 'hnc_forward_drug';
		if ( ! function_exists( 'current_user_can' ) || ! current_user_can( $cap ) ) {
			return new WP_Error(
				self::ERR_UNAUTHORIZED,
				__( 'You do not have permission to forward drug reports.', 'helpnagaland-core' )
			);
		}
		return true;
	}

	/**
	 * Normalize a partner identifier. Accepts either a numeric ID or a
	 * slug (lowercase alphanumeric plus dash/underscore, 1 to 60 chars).
	 *
	 * @param string $raw Raw input.
	 * @return string Canonical identifier or empty string.
	 */
	private static function sanitize_partner_identifier( $raw ) {
		$raw = trim( (string) $raw );
		if ( '' === $raw ) {
			return '';
		}
		// Numeric: keep as decimal string.
		if ( preg_match( '/^\d+$/', $raw ) ) {
			return $raw;
		}
		// Slug: lowercased, alphanumeric plus - and _, up to 60 chars.
		$slug = strtolower( $raw );
		$slug = preg_replace( '/[^a-z0-9_\-]+/', '', (string) $slug );
		$slug = substr( (string) $slug, 0, 60 );
		return ( '' === $slug ) ? '' : $slug;
	}

	/**
	 * Fetch a drug report row (status is what we care about).
	 *
	 * @param int $report_id Report ID.
	 * @return object|null
	 */
	private static function fetch_row( $report_id ) {
		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'drug_reports';
		$row   = $wpdb->get_row(
			$wpdb->prepare( "SELECT id, status FROM {$table} WHERE id = %d LIMIT 1", (int) $report_id )
		);
		return $row ? $row : null;
	}

	/**
	 * Check whether this report was forwarded to this partner in the last
	 * 24 hours. Uses the audit log as the source of truth.
	 *
	 * @param int    $report_id          Report ID.
	 * @param string $partner_identifier Canonical partner identifier.
	 * @return bool
	 */
	private static function was_forwarded_recently( $report_id, $partner_identifier ) {
		global $wpdb;
		$audit_table = $wpdb->prefix . HNC_TABLE_PREFIX . 'audit_log';
		$cutoff      = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT detail FROM {$audit_table}
				 WHERE event_type = %s
				   AND action = %s
				   AND report_id = %d
				   AND created_at > %s
				 LIMIT 50",
				class_exists( 'HNC_Logger' ) ? HNC_Logger::EVENT_DRUG : 'drug',
				class_exists( 'HNC_Logger' ) ? HNC_Logger::ACTION_FORWARD : 'forward',
				(int) $report_id,
				$cutoff
			)
		);
		if ( ! is_array( $rows ) ) {
			return false;
		}
		foreach ( $rows as $r ) {
			if ( empty( $r->detail ) ) {
				continue;
			}
			$decoded = json_decode( (string) $r->detail, true );
			if ( ! is_array( $decoded ) ) {
				continue;
			}
			$detail = isset( $decoded['detail'] ) && is_array( $decoded['detail'] ) ? $decoded['detail'] : $decoded;
			if ( isset( $detail['partner'] ) && (string) $detail['partner'] === (string) $partner_identifier ) {
				return true;
			}
		}
		return false;
	}
}
