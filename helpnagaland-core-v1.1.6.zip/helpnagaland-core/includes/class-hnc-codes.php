<?php
/**
 * Tracking code generator.
 *
 * Every submission (alcohol or drug) receives a short, human-readable
 * tracking code in the format XXXX-XXXX. The reporter can enter this
 * code on the status page to check the state of their report:
 *
 *   pending     -> under review
 *   approved    -> visible on the public map (alcohol) or in the archive (drug)
 *   rejected    -> not accepted; photo and details already deleted
 *   hold        -> held for further investigation
 *   resolved    -> drug only: action was taken by a partner
 *   archived    -> old report moved to cold storage
 *
 * Design:
 *
 *   - Codes are 8 characters split as XXXX-XXXX for readability.
 *   - The alphabet excludes confusing characters: 0, O, 1, I, L, and Q.
 *     This leaves 30 characters. Total code space is 30^8 = ~6.56e11.
 *   - On generation, we check uniqueness across both the alcohol and
 *     the drug tables (they share a public-code namespace so a reporter
 *     cannot guess whether their code is alcohol or drug by format).
 *   - Collisions are vanishingly rare but handled: up to 5 retries.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Codes
 */
final class HNC_Codes {


	/**
	 * Allowed characters. Excludes 0/O and 1/I/L so codes can be read aloud
	 * without ambiguity. Q is excluded because it is often confused with O.
	 */
	const ALPHABET = 'ABCDEFGHJKMNPRSTUVWXYZ23456789';

	/**
	 * Length of each half.
	 */
	const HALF_LEN = 4;

	/**
	 * Max attempts to generate a unique code before giving up.
	 */
	const MAX_ATTEMPTS = 5;


	/**
	 * Generate a new unique tracking code.
	 *
	 * @return string Code in XXXX-XXXX format, or empty string on failure.
	 */
	public static function generate() {
		for ( $i = 0; $i < self::MAX_ATTEMPTS; $i++ ) {
			$code = self::make_code();
			if ( self::is_unique( $code ) ) {
				return $code;
			}
		}
		// In practice we should never reach here given the code space. If
		// we do, the caller must handle an empty string gracefully.
		return '';
	}

	/**
	 * Validate the format of a user-submitted tracking code.
	 * Returns the canonical (uppercased, dashed) form, or empty string if invalid.
	 *
	 * @param string $raw User input.
	 * @return string Canonical code or empty string.
	 */
	public static function normalize( $raw ) {
		$s = strtoupper( (string) $raw );
		// Strip everything that is not in the alphabet or dash.
		$s = preg_replace( '/[^A-Z0-9\-]/', '', (string) $s );
		// Remove dashes to check length.
		$bare = str_replace( '-', '', (string) $s );
		if ( strlen( (string) $bare ) !== self::HALF_LEN * 2 ) {
			return '';
		}
		// Ensure every char is in the allowed alphabet.
		$len = strlen( (string) $bare );
		for ( $i = 0; $i < $len; $i++ ) {
			if ( strpos( self::ALPHABET, $bare[ $i ] ) === false ) {
				return '';
			}
		}
		// Format as XXXX-XXXX.
		return substr( (string) $bare, 0, self::HALF_LEN ) . '-' . substr( (string) $bare, self::HALF_LEN );
	}

	/**
	 * Look up a code across both pipelines. Returns an array with keys:
	 *   - pipeline: 'alcohol' | 'drug' | ''
	 *   - row:      The database row as an object, or null if not found.
	 *
	 * This is the primary helper for the public status endpoint. A reporter
	 * enters their code and we tell them the current state of the report
	 * without revealing which pipeline it came from. Pipeline is returned
	 * to the caller to decide what public-safe information to include.
	 *
	 * @param string $code Normalized code.
	 * @return array{pipeline:string,row:?object}
	 */
	public static function lookup( $code ) {
		$code = self::normalize( $code );
		if ( '' === $code ) {
			return array(
				'pipeline' => '',
				'row'      => null,
			);
		}

		if ( ! class_exists( 'HNC_Schema' ) ) {
			return array(
				'pipeline' => '',
				'row'      => null,
			);
		}

		global $wpdb;

		// Check alcohol first.
		$alcohol_table = HNC_Schema::table_alcohol_reports();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$sql = "SELECT id, public_code, status, submitted_at, moderated_at, rejection_reason FROM {$alcohol_table} WHERE public_code = %s LIMIT 1";
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( $sql, $code ) );
		if ( $row ) {
			return array(
				'pipeline' => 'alcohol',
				'row'      => $row,
			);
		}

		// Then drug.
		$drug_table = HNC_Schema::table_drug_reports();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$sql = "SELECT id, public_code, status, submitted_at, moderated_at, resolved_at FROM {$drug_table} WHERE public_code = %s LIMIT 1";
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( $sql, $code ) );
		if ( $row ) {
			return array(
				'pipeline' => 'drug',
				'row'      => $row,
			);
		}

		return array(
			'pipeline' => '',
			'row'      => null,
		);
	}


	/* ------------------------------------------------------------------
	 * INTERNAL
	 * ------------------------------------------------------------------ */

	/**
	 * Generate a fresh code without uniqueness check.
	 *
	 * @return string
	 */
	private static function make_code() {
		$half_a = self::random_chars( self::HALF_LEN );
		$half_b = self::random_chars( self::HALF_LEN );
		return $half_a . '-' . $half_b;
	}

	/**
	 * Pick N random characters from the alphabet using a cryptographically
	 * secure source.
	 *
	 * @param int $n Number of characters.
	 * @return string
	 */
	private static function random_chars( $n ) {
		$alphabet = self::ALPHABET;
		$max      = strlen( $alphabet ) - 1;
		$out      = '';
		for ( $i = 0; $i < $n; $i++ ) {
			try {
				$idx = random_int( 0, $max );
			} catch ( Throwable $t ) {
				// Fallback if random_int fails for any reason.
				// wp_rand is not cryptographic but better than nothing.
				$idx = function_exists( 'wp_rand' ) ? wp_rand( 0, $max ) : mt_rand( 0, $max );
			}
			$out .= $alphabet[ $idx ];
		}
		return $out;
	}

	/**
	 * True if the given code does not exist in either pipeline table.
	 *
	 * @param string $code Formatted code.
	 * @return bool
	 */
	private static function is_unique( $code ) {
		if ( ! class_exists( 'HNC_Schema' ) ) {
			return true; // cannot check; assume unique.
		}

		global $wpdb;

		$alcohol_table = HNC_Schema::table_alcohol_reports();
		$drug_table    = HNC_Schema::table_drug_reports();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$a = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$alcohol_table} WHERE public_code = %s", $code ) );
		if ( (int) $a > 0 ) {
			return false;
		}
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$d = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$drug_table} WHERE public_code = %s", $code ) );
		if ( (int) $d > 0 ) {
			return false;
		}

		return true;
	}
}
