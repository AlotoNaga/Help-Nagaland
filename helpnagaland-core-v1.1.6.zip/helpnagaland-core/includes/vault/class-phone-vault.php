<?php
/**
 * Phone Vault: encrypted phone storage.
 *
 * Provides the ONLY sanctioned way to store or reveal phone numbers in the
 * system. Uses AES-256-GCM via HNC_Encryption. The symmetric key lives in
 * the PHP session for at most N minutes after the moderator unlocks the
 * vault with the passphrase, then is zeroed. The key is never written to
 * disk or the database.
 *
 * DESIGN CONSEQUENCE: phones can only be stored when the vault is unlocked.
 * At submission time, if no moderator has an active unlocked session, a
 * phone provided by the reporter is NOT persisted. The submission flow
 * already handles this: the response reports `phone_saved: false` and the
 * reporter is told the phone was not saved. This is the deliberate tradeoff
 * for making sure phones never exist in plaintext on disk and never exist
 * encrypted under a key that an attacker with a DB dump could obtain.
 *
 * The counter-argument to this design (losing some legitimate phones when
 * no moderator is online) was weighed against the alternative (storing a
 * phone in a recoverable form anywhere on the server) and rejected. The
 * spec is unambiguous: a stolen DB dump must NOT expose phone numbers.
 *
 * Rules this class enforces:
 *
 *   - store() requires the vault to be unlocked.
 *   - reveal() requires the vault to be unlocked AND CAP_REVEAL_PHONE AND
 *     a second explicit confirmation flag ($second_consent === true).
 *   - Every reveal writes an audit log entry with the vault_id and the
 *     WP user ID of the moderator.
 *   - Phones are always stored with a scheduled_delete_at timestamp.
 *     Default retention is 180 days from creation, shortened to 90 days
 *     after resolution via mark_for_delete_after_resolved().
 *   - delete() is a soft delete (sets deleted_at). purge_deleted() is the
 *     hard delete run by cron.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Phone_Vault
 */
final class HNC_Phone_Vault {


	/* ------------------------------------------------------------------
	 * ERROR CODES
	 * ------------------------------------------------------------------ */

	const ERR_VAULT_LOCKED     = 'hnc_vault_locked';
	const ERR_UNAUTHORIZED     = 'hnc_unauthorized';
	const ERR_NOT_FOUND        = 'hnc_vault_entry_not_found';
	const ERR_BAD_INPUT        = 'hnc_bad_input';
	const ERR_NO_CONSENT       = 'hnc_second_consent_required';
	const ERR_CRYPTO_FAILED    = 'hnc_crypto_failure';
	const ERR_DB               = 'hnc_db_error';
	const ERR_ALREADY_DELETED  = 'hnc_vault_entry_already_deleted';


	/* ------------------------------------------------------------------
	 * STORE
	 * ------------------------------------------------------------------ */

	/**
	 * Encrypt and store a phone number. Requires the vault to be unlocked
	 * in the current PHP session.
	 *
	 * @param string $phone        E.164 phone number (e.g. "+919876543210").
	 * @param string $report_type  'alcohol' or 'drug'. Informs retention and audit.
	 * @param int    $report_id    The pipeline-specific report ID this phone is linked to.
	 *                             Pass 0 if not yet known (callers should back-fill).
	 * @return int|null Vault row ID on success, null on any failure.
	 */
	public static function store( $phone, $report_type = '', $report_id = 0 ) {
		if ( ! class_exists( 'HNC_Encryption' ) || ! HNC_Encryption::is_unlocked() ) {
			self::log_system_fail( 'store_attempt_while_locked', array( 'report_type' => $report_type, 'report_id' => $report_id ) );
			return null;
		}

		$phone = self::clean_phone( $phone );
		if ( '' === $phone ) {
			return null;
		}

		$valid_types = array( 'alcohol', 'drug' );
		$report_type = in_array( $report_type, $valid_types, true ) ? $report_type : 'drug';
		$report_id   = max( 0, (int) $report_id );

		$enc = HNC_Encryption::encrypt( $phone );
		if ( ! is_array( $enc ) || empty( $enc['ciphertext'] ) || empty( $enc['nonce'] ) || empty( $enc['tag'] ) ) {
			self::log_system_fail( 'encrypt_failed', array( 'report_type' => $report_type, 'report_id' => $report_id ) );
			return null;
		}

		$retention_days = (int) get_option( 'hnc_phone_retention_days_max', 180 );
		if ( $retention_days < 1 ) {
			$retention_days = 180;
		}
		$scheduled_delete = gmdate( 'Y-m-d H:i:s', time() + ( $retention_days * DAY_IN_SECONDS ) );

		global $wpdb;
		$table = self::table();
		$ok    = $wpdb->insert(
			$table,
			array(
				'report_type'          => $report_type,
				'report_id'            => $report_id,
				'encrypted_phone'      => $enc['ciphertext'],
				'nonce'                => $enc['nonce'],
				'tag'                  => $enc['tag'],
				'consent_forward'      => 0,
				'consent_partner'      => null,
				'created_at'           => current_time( 'mysql' ),
				'scheduled_delete_at'  => $scheduled_delete,
				'deleted_at'           => null,
			),
			array( '%s', '%d', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s' )
		);

		if ( ! $ok ) {
			self::log_system_fail( 'insert_failed', array( 'db_error' => $wpdb->last_error ) );
			return null;
		}

		$vault_id = (int) $wpdb->insert_id;

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_vault(
				HNC_Logger::ACTION_VAULT_STORE,
				$vault_id,
				array(
					'report_type' => $report_type,
					'report_id'   => $report_id,
				)
			);
		}

		return $vault_id;
	}


	/* ------------------------------------------------------------------
	 * REVEAL
	 * ------------------------------------------------------------------ */

	/**
	 * Decrypt and return a phone number. Enforces the full consent gate:
	 *   - Vault must be unlocked.
	 *   - Caller must hold CAP_REVEAL_PHONE.
	 *   - Caller must pass $second_consent === true.
	 *
	 * Every reveal is audit-logged with the vault_id and moderator ID.
	 *
	 * @param int  $vault_id       Row ID in hnc_phone_vault.
	 * @param bool $second_consent Must be literally true. A falsy value returns an error.
	 * @return string|WP_Error Phone number, or WP_Error explaining refusal.
	 */
	public static function reveal( $vault_id, $second_consent = false ) {
		$cap = class_exists( 'HNC_Roles' ) ? HNC_Roles::CAP_REVEAL_PHONE : 'hnc_reveal_phone';
		if ( ! function_exists( 'current_user_can' ) || ! current_user_can( $cap ) ) {
			self::log_reveal_fail( $vault_id, 'forbidden' );
			return new WP_Error(
				self::ERR_UNAUTHORIZED,
				__( 'You do not have permission to reveal phone numbers.', 'helpnagaland-core' )
			);
		}

		if ( true !== $second_consent ) {
			self::log_reveal_fail( $vault_id, 'missing_second_consent' );
			return new WP_Error(
				self::ERR_NO_CONSENT,
				__( 'Confirm you have a legitimate reason before revealing this phone number.', 'helpnagaland-core' )
			);
		}

		if ( ! class_exists( 'HNC_Encryption' ) || ! HNC_Encryption::is_unlocked() ) {
			self::log_reveal_fail( $vault_id, 'vault_locked' );
			return new WP_Error(
				self::ERR_VAULT_LOCKED,
				__( 'The phone vault is locked. Unlock it with the passphrase first.', 'helpnagaland-core' )
			);
		}

		$row = self::fetch_row( (int) $vault_id );
		if ( null === $row ) {
			self::log_reveal_fail( $vault_id, 'not_found' );
			return new WP_Error( self::ERR_NOT_FOUND, __( 'Phone vault entry not found.', 'helpnagaland-core' ) );
		}

		if ( null !== $row->deleted_at ) {
			self::log_reveal_fail( $vault_id, 'already_deleted' );
			return new WP_Error( self::ERR_ALREADY_DELETED, __( 'This phone vault entry has been deleted.', 'helpnagaland-core' ) );
		}

		$plaintext = HNC_Encryption::decrypt(
			(string) $row->encrypted_phone,
			(string) $row->nonce,
			(string) $row->tag
		);

		if ( null === $plaintext || '' === $plaintext ) {
			self::log_reveal_fail( $vault_id, 'decrypt_failed' );
			return new WP_Error( self::ERR_CRYPTO_FAILED, __( 'Could not decrypt the phone number.', 'helpnagaland-core' ) );
		}

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_vault(
				HNC_Logger::ACTION_PHONE_REVEAL,
				(int) $vault_id,
				array(
					'report_type' => (string) $row->report_type,
					'report_id'   => (int) $row->report_id,
					'moderator'   => function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0,
				)
			);
		}

		return (string) $plaintext;
	}


	/* ------------------------------------------------------------------
	 * PARTNER CONSENT
	 * ------------------------------------------------------------------ */

	/**
	 * Mark a vault entry as consented for forward to a specific partner.
	 * This is the "second consent" for partner forwarding: the reporter
	 * agreed at submit time to be contacted, AND a moderator has captured
	 * the reporter's subsequent OK for that phone to be shared with a
	 * specific partner. The UI should only call this after the moderator
	 * has actually spoken to the reporter.
	 *
	 * @param int    $vault_id           Vault row ID.
	 * @param string $partner_identifier Slug or numeric partner ID (<=60 chars).
	 * @return true|WP_Error
	 */
	public static function set_partner_consent( $vault_id, $partner_identifier ) {
		$cap = class_exists( 'HNC_Roles' ) ? HNC_Roles::CAP_MANAGE_VAULT : 'hnc_manage_vault';
		if ( ! function_exists( 'current_user_can' ) || ! current_user_can( $cap ) ) {
			return new WP_Error( self::ERR_UNAUTHORIZED, __( 'You cannot update vault consents.', 'helpnagaland-core' ) );
		}

		$partner_identifier = trim( (string) $partner_identifier );
		$partner_identifier = substr( preg_replace( '/[^a-z0-9_\-]/', '', strtolower( $partner_identifier ) ), 0, 60 );
		if ( '' === $partner_identifier ) {
			return new WP_Error( self::ERR_BAD_INPUT, __( 'Partner identifier is required.', 'helpnagaland-core' ) );
		}

		$row = self::fetch_row( (int) $vault_id );
		if ( null === $row ) {
			return new WP_Error( self::ERR_NOT_FOUND, __( 'Phone vault entry not found.', 'helpnagaland-core' ) );
		}

		global $wpdb;
		$table = self::table();
		$ok    = $wpdb->update(
			$table,
			array(
				'consent_forward' => 1,
				'consent_partner' => $partner_identifier,
			),
			array( 'id' => (int) $vault_id ),
			array( '%d', '%s' ),
			array( '%d' )
		);
		if ( false === $ok ) {
			return new WP_Error( self::ERR_DB, __( 'Could not update the vault entry.', 'helpnagaland-core' ) );
		}

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_vault(
				'vault_consent_partner',
				(int) $vault_id,
				array( 'partner' => $partner_identifier )
			);
		}
		return true;
	}


	/* ------------------------------------------------------------------
	 * DELETE / PURGE
	 * ------------------------------------------------------------------ */

	/**
	 * Soft delete a vault entry. Callable from moderation and cron. Does not
	 * require the vault to be unlocked since soft-delete only sets a flag.
	 * Hard deletion happens on a schedule through purge_deleted().
	 *
	 * @param int $vault_id Row ID.
	 * @return true|WP_Error
	 */
	public static function delete( $vault_id ) {
		$vault_id = (int) $vault_id;
		if ( $vault_id <= 0 ) {
			return new WP_Error( self::ERR_BAD_INPUT, __( 'Invalid vault entry.', 'helpnagaland-core' ) );
		}

		global $wpdb;
		$table = self::table();

		$ok = $wpdb->update(
			$table,
			array( 'deleted_at' => current_time( 'mysql' ) ),
			array( 'id' => $vault_id ),
			array( '%s' ),
			array( '%d' )
		);

		if ( false === $ok ) {
			return new WP_Error( self::ERR_DB, __( 'Could not mark the entry for deletion.', 'helpnagaland-core' ) );
		}

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_vault( HNC_Logger::ACTION_PHONE_DELETE, $vault_id );
		}
		return true;
	}

	/**
	 * Hard-delete soft-deleted rows older than the configured grace. Also
	 * hard-deletes entries whose scheduled_delete_at is in the past, even
	 * if not soft-deleted. Used by the daily vault cron.
	 *
	 * @return int Rows removed.
	 */
	public static function purge_deleted() {
		global $wpdb;
		$table = self::table();

		$grace_hours = (int) get_option( 'hnc_vault_purge_grace_hours', 24 );
		if ( $grace_hours < 1 ) {
			$grace_hours = 24;
		}

		// Step 1: purge rows that were soft-deleted more than grace hours ago.
		$grace_cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $grace_hours * HOUR_IN_SECONDS ) );
		$deleted_1    = (int) $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$table} WHERE deleted_at IS NOT NULL AND deleted_at < %s",
				$grace_cutoff
			)
		);

		// Step 2: purge rows whose scheduled_delete_at has passed, regardless
		// of soft-delete state.
		$now_mysql = current_time( 'mysql' );
		$deleted_2 = (int) $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$table} WHERE scheduled_delete_at < %s",
				$now_mysql
			)
		);

		$total = $deleted_1 + $deleted_2;

		if ( $total > 0 && class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_system(
				'vault_purge',
				array(
					'soft_deleted_pruned' => $deleted_1,
					'retention_expired'   => $deleted_2,
					'total'               => $total,
				)
			);
		}

		return $total;
	}

	/**
	 * Shorten the scheduled_delete_at for a vault entry when its linked
	 * report resolves. If the current schedule is further out than
	 * hnc_phone_retention_days_after_resolved from now, pull it in.
	 *
	 * @param int $vault_id Row ID.
	 * @return bool
	 */
	public static function mark_for_delete_after_resolved( $vault_id ) {
		$vault_id = (int) $vault_id;
		if ( $vault_id <= 0 ) {
			return false;
		}

		$days = (int) get_option( 'hnc_phone_retention_days_after_resolved', 90 );
		if ( $days < 1 ) {
			$days = 90;
		}
		$new_schedule = gmdate( 'Y-m-d H:i:s', time() + ( $days * DAY_IN_SECONDS ) );

		global $wpdb;
		$table = self::table();

		$row = self::fetch_row( $vault_id );
		if ( null === $row ) {
			return false;
		}
		if ( strtotime( (string) $row->scheduled_delete_at ) <= strtotime( $new_schedule ) ) {
			// Already scheduled sooner; do nothing.
			return true;
		}

		$ok = $wpdb->update(
			$table,
			array( 'scheduled_delete_at' => $new_schedule ),
			array( 'id' => $vault_id ),
			array( '%s' ),
			array( '%d' )
		);
		return false !== $ok;
	}


	/* ------------------------------------------------------------------
	 * METADATA
	 * ------------------------------------------------------------------ */

	/**
	 * Return non-sensitive metadata about a vault entry. Phone itself is
	 * NEVER included.
	 *
	 * @param int $vault_id Row ID.
	 * @return array|null
	 */
	public static function metadata( $vault_id ) {
		$cap = class_exists( 'HNC_Roles' ) ? HNC_Roles::CAP_MANAGE_VAULT : 'hnc_manage_vault';
		if ( ! function_exists( 'current_user_can' ) || ! current_user_can( $cap ) ) {
			return null;
		}

		$row = self::fetch_row( (int) $vault_id );
		if ( null === $row ) {
			return null;
		}
		return array(
			'id'                  => (int) $row->id,
			'report_type'         => (string) $row->report_type,
			'report_id'           => (int) $row->report_id,
			'consent_forward'     => ( 1 === (int) $row->consent_forward ),
			'consent_partner'     => (string) $row->consent_partner,
			'created_at'          => (string) $row->created_at,
			'scheduled_delete_at' => (string) $row->scheduled_delete_at,
			'deleted_at'          => null === $row->deleted_at ? null : (string) $row->deleted_at,
		);
	}


	/* ------------------------------------------------------------------
	 * INTERNAL HELPERS
	 * ------------------------------------------------------------------ */

	/**
	 * Return current vault counts broken down by pipeline.
	 *
	 * Only "live" rows are counted — soft-deleted rows (those with a
	 * non-null deleted_at) are excluded so the numbers match what a
	 * moderator would actually see in the UI.
	 *
	 * @return array{total:int,alcohol:int,drug:int}
	 */
	public static function counts() {
		global $wpdb;
		$table = self::table();

		$rows = $wpdb->get_results(
			"SELECT report_type, COUNT(*) AS cnt
			 FROM {$table}
			 WHERE deleted_at IS NULL
			 GROUP BY report_type",
			ARRAY_A
		);

		$out = array( 'total' => 0, 'alcohol' => 0, 'drug' => 0 );
		if ( is_array( $rows ) ) {
			foreach ( $rows as $r ) {
				$type = isset( $r['report_type'] ) ? (string) $r['report_type'] : '';
				$cnt  = isset( $r['cnt'] ) ? (int) $r['cnt'] : 0;
				$out['total'] += $cnt;
				if ( 'alcohol' === $type ) {
					$out['alcohol'] = $cnt;
				} elseif ( 'drug' === $type ) {
					$out['drug'] = $cnt;
				}
			}
		}
		return $out;
	}

	/**
	 * Table name helper.
	 *
	 * @return string
	 */
	private static function table() {
		global $wpdb;
		return $wpdb->prefix . HNC_TABLE_PREFIX . 'phone_vault';
	}

	/**
	 * Fetch a vault row by ID.
	 *
	 * @param int $vault_id Row ID.
	 * @return object|null
	 */
	private static function fetch_row( $vault_id ) {
		global $wpdb;
		$table = self::table();
		$row   = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d LIMIT 1", (int) $vault_id )
		);
		return $row ? $row : null;
	}

	/**
	 * Validate and normalize the phone string.
	 *
	 * @param string $phone Raw phone.
	 * @return string Normalized or '' if invalid.
	 */
	private static function clean_phone( $phone ) {
		if ( class_exists( 'HNC_Sanitizer' ) ) {
			return HNC_Sanitizer::phone_number( $phone );
		}
		$digits = preg_replace( '/\D+/', '', (string) $phone );
		if ( strlen( $digits ) < 10 || strlen( $digits ) > 15 ) {
			return '';
		}
		if ( strlen( $digits ) === 10 ) {
			$digits = '91' . $digits;
		}
		return '+' . $digits;
	}

	/**
	 * Log a failed reveal attempt. Always fires regardless of reason.
	 *
	 * @param int    $vault_id Vault row ID.
	 * @param string $reason   Short reason code.
	 * @return void
	 */
	private static function log_reveal_fail( $vault_id, $reason ) {
		if ( ! class_exists( 'HNC_Logger' ) ) {
			return;
		}
		HNC_Logger::log_vault(
			HNC_Logger::ACTION_VAULT_FAIL,
			(int) $vault_id,
			array( 'reason' => (string) $reason )
		);
	}

	/**
	 * Log a system-level failure in the vault (store/encrypt/db).
	 *
	 * @param string $reason Reason code.
	 * @param array  $meta   Extra.
	 * @return void
	 */
	private static function log_system_fail( $reason, $meta = array() ) {
		if ( ! class_exists( 'HNC_Logger' ) ) {
			return;
		}
		$payload = array_merge( array( 'reason' => (string) $reason ), is_array( $meta ) ? $meta : array() );
		HNC_Logger::log_system( 'vault_error', $payload );
	}
}
