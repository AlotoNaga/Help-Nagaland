<?php
/**
 * Vault Cron: daily sweep of the phone vault.
 *
 * One worker runs daily (hooked to HNC_Cron::HOOK_PHONE_CLEANUP at 03:45
 * IST). It removes:
 *
 *   - Soft-deleted rows whose deleted_at is older than the grace window.
 *   - Rows whose scheduled_delete_at has passed.
 *   - Orphan rows whose linked report no longer exists (the report was
 *     hard-deleted by its own retention sweep).
 *
 * Orphan detection is defensive. Normally the drug retention and alcohol
 * retention sweeps call HNC_Phone_Vault::delete() before hard-deleting a
 * row, but if something went wrong (process killed mid-sweep, DB error)
 * we catch stragglers here.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Vault_Cron
 */
final class HNC_Vault_Cron {


	/* ------------------------------------------------------------------
	 * BOOTSTRAP
	 * ------------------------------------------------------------------ */

	/**
	 * Register the daily cron callback.
	 *
	 * @return void
	 */
	public static function init() {
		if ( ! class_exists( 'HNC_Cron' ) ) {
			return;
		}
		add_action( HNC_Cron::HOOK_PHONE_CLEANUP, array( __CLASS__, 'daily_sweep' ) );
	}


	/* ------------------------------------------------------------------
	 * SWEEP
	 * ------------------------------------------------------------------ */

	/**
	 * Run the daily sweep. Always returns a summary even on partial failures.
	 *
	 * @return array { purged, orphans_deleted }.
	 */
	public static function daily_sweep() {
		$purged          = 0;
		$orphans_deleted = 0;

		if ( class_exists( 'HNC_Phone_Vault' ) ) {
			$purged = (int) HNC_Phone_Vault::purge_deleted();
		}

		$orphans_deleted = self::delete_orphans();

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_system(
				'vault_daily_sweep',
				array(
					'purged'          => $purged,
					'orphans_deleted' => $orphans_deleted,
				)
			);
		}

		return array(
			'purged'          => $purged,
			'orphans_deleted' => $orphans_deleted,
		);
	}


	/* ------------------------------------------------------------------
	 * ORPHAN DETECTION
	 * ------------------------------------------------------------------ */

	/**
	 * Mark as deleted any vault row whose linked report no longer exists
	 * in its pipeline table. Does NOT hard-delete; that happens on the
	 * next run of purge_deleted() after the grace window passes.
	 *
	 * @return int Count of rows soft-deleted.
	 */
	private static function delete_orphans() {
		global $wpdb;
		$vault_table   = $wpdb->prefix . HNC_TABLE_PREFIX . 'phone_vault';
		$alcohol_table = $wpdb->prefix . HNC_TABLE_PREFIX . 'alcohol_reports';
		$drug_table    = $wpdb->prefix . HNC_TABLE_PREFIX . 'drug_reports';

		/*
		 * Loop-until-drained. The earlier version had a hard LIMIT 500
		 * per cron run with no continuation, so if >1000 orphans ever
		 * accumulated the backlog was never reduced. We now cap total
		 * work per run at MAX_ORPHANS_PER_RUN rows (protects against a
		 * pathological case where deletes fail silently and we loop
		 * forever), but iterate in batches of 500 until either drained
		 * or the cap is hit. Next cron tick picks up any remainder.
		 */
		$batch_size = 500;
		$cap        = (int) apply_filters( 'hnc_vault_orphan_cap_per_run', 5000 );

		$count = 0;

		foreach ( array(
			array( 'type' => 'alcohol', 'report_table' => $alcohol_table ),
			array( 'type' => 'drug',    'report_table' => $drug_table ),
		) as $sweep ) {
			while ( $count < $cap ) {
				$orphans = $wpdb->get_col(
					$wpdb->prepare(
						"SELECT v.id
						 FROM {$vault_table} v
						 LEFT JOIN {$sweep['report_table']} r ON r.id = v.report_id
						 WHERE v.report_type = %s
						   AND v.deleted_at IS NULL
						   AND v.report_id > 0
						   AND r.id IS NULL
						 LIMIT %d",
						$sweep['type'],
						$batch_size
					)
				);
				if ( ! is_array( $orphans ) || empty( $orphans ) ) {
					break;
				}
				foreach ( $orphans as $vid ) {
					if ( $count >= $cap ) {
						break 2;
					}
					if ( class_exists( 'HNC_Phone_Vault' ) ) {
						HNC_Phone_Vault::delete( (int) $vid );
						$count++;
					}
				}
				// If the batch was smaller than the limit, we are drained.
				if ( count( $orphans ) < $batch_size ) {
					break;
				}
			}
		}

		return $count;
	}
}
