<?php
/**
 * Partner Model: CRUD + lookup for vetted partner organizations.
 *
 * A partner is a civil society group, recovery nonprofit, legal liaison,
 * or health organization that Nagaland Me has onboarded to receive
 * forwarded drug reports. Each partner has:
 *
 *   - A WordPress user account with the hnc_partner role (created first).
 *   - A row in the hnc_partners table linking that user to a slug and
 *     display name.
 *   - An active flag that can be toggled from the admin UI. Inactive
 *     partners stop receiving forwards immediately.
 *
 * The slug is the identifier used in the HNC_Drug_Forward flow. When a
 * moderator forwards a report to "nsacs_kohima", we look up the partner
 * row with that slug, grab its partner_id, and file a row in
 * hnc_partner_forwards so the partner can see the case in their
 * dashboard.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Partner_Model
 */
final class HNC_Partner_Model {


	/* ------------------------------------------------------------------
	 * ERROR CODES
	 * ------------------------------------------------------------------ */

	const ERR_UNAUTHORIZED   = 'hnc_unauthorized';
	const ERR_NOT_FOUND      = 'hnc_partner_not_found';
	const ERR_BAD_INPUT      = 'hnc_partner_bad_input';
	const ERR_SLUG_TAKEN     = 'hnc_partner_slug_taken';
	const ERR_USER_TAKEN     = 'hnc_partner_user_taken';
	const ERR_BAD_USER       = 'hnc_partner_bad_wp_user';
	const ERR_DB             = 'hnc_partner_db_error';


	/* ------------------------------------------------------------------
	 * CREATE
	 * ------------------------------------------------------------------ */

	/**
	 * Create a partner record and link it to an existing WordPress user.
	 *
	 * The WP user must already exist and be assigned the hnc_partner role.
	 * Creating the WP user is a separate concern; the admin UI handles
	 * user creation through the standard Users workflow so we do not
	 * accidentally reimplement WordPress's user management here.
	 *
	 * @param array $input { slug, name, wp_user_id, contact_email, gpg_fingerprint, active }
	 * @return int|WP_Error Partner row ID on success.
	 */
	public static function create( $input ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$input = is_array( $input ) ? $input : array();

		$slug = self::normalize_slug( isset( $input['slug'] ) ? $input['slug'] : '' );
		if ( '' === $slug ) {
			return new WP_Error( self::ERR_BAD_INPUT, __( 'Partner slug is required.', 'helpnagaland-core' ) );
		}

		$name = trim( (string) ( $input['name'] ?? '' ) );
		if ( '' === $name || strlen( $name ) > 120 ) {
			return new WP_Error( self::ERR_BAD_INPUT, __( 'Partner name is required and must be under 120 characters.', 'helpnagaland-core' ) );
		}

		$wp_user_id = (int) ( $input['wp_user_id'] ?? 0 );
		if ( $wp_user_id <= 0 ) {
			return new WP_Error( self::ERR_BAD_USER, __( 'A WordPress user ID is required.', 'helpnagaland-core' ) );
		}

		$user = function_exists( 'get_userdata' ) ? get_userdata( $wp_user_id ) : null;
		if ( ! $user ) {
			return new WP_Error( self::ERR_BAD_USER, __( 'WordPress user not found.', 'helpnagaland-core' ) );
		}

		// Enforce uniqueness before insert (table has UNIQUE constraints too).
		if ( null !== self::get_by_slug( $slug ) ) {
			return new WP_Error( self::ERR_SLUG_TAKEN, __( 'A partner with this slug already exists.', 'helpnagaland-core' ) );
		}
		if ( null !== self::get_by_wp_user( $wp_user_id ) ) {
			return new WP_Error( self::ERR_USER_TAKEN, __( 'This WordPress user is already linked to a partner.', 'helpnagaland-core' ) );
		}

		$contact_email   = trim( (string) ( $input['contact_email'] ?? '' ) );
		if ( '' !== $contact_email && ! is_email( $contact_email ) ) {
			return new WP_Error( self::ERR_BAD_INPUT, __( 'Contact email is not valid.', 'helpnagaland-core' ) );
		}

		$gpg_fp = self::normalize_gpg( isset( $input['gpg_fingerprint'] ) ? $input['gpg_fingerprint'] : '' );
		$active = ! empty( $input['active'] ) ? 1 : 1; // default active=1

		global $wpdb;
		$table = HNC_Schema::table_partners();

		$ok = $wpdb->insert(
			$table,
			array(
				'slug'                    => $slug,
				'name'                    => $name,
				'wp_user_id'              => $wp_user_id,
				'contact_email'           => '' === $contact_email ? null : $contact_email,
				'contact_gpg_fingerprint' => '' === $gpg_fp ? null : $gpg_fp,
				'onboarded_at'            => current_time( 'mysql' ),
				'active'                  => $active,
			),
			array( '%s', '%s', '%d', '%s', '%s', '%s', '%d' )
		);
		if ( ! $ok ) {
			return new WP_Error(
				self::ERR_DB,
				__( 'Could not create the partner record.', 'helpnagaland-core' ),
				array( 'db_error' => $wpdb->last_error )
			);
		}

		$partner_id = (int) $wpdb->insert_id;

		// Grant the hnc_partner role if not already present.
		if ( $user && is_object( $user ) && isset( $user->roles ) && ! in_array( 'hnc_partner', (array) $user->roles, true ) ) {
			if ( method_exists( $user, 'add_role' ) ) {
				$user->add_role( 'hnc_partner' );
			}
		}

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_system(
				'partner_create',
				array(
					'partner_id' => $partner_id,
					'slug'       => $slug,
					'name'       => $name,
					'wp_user_id' => $wp_user_id,
				)
			);
		}

		return $partner_id;
	}


	/* ------------------------------------------------------------------
	 * UPDATE / DEACTIVATE
	 * ------------------------------------------------------------------ */

	/**
	 * Set the active flag. Inactive partners stop receiving forwards and
	 * cannot access the partner dashboard. The row itself is preserved
	 * for audit continuity.
	 *
	 * @param int  $partner_id Row ID.
	 * @param bool $active     Target state.
	 * @return true|WP_Error
	 */
	public static function set_active( $partner_id, $active ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$partner_id = (int) $partner_id;
		$active_int = ! empty( $active ) ? 1 : 0;

		$row = self::get( $partner_id );
		if ( null === $row ) {
			return new WP_Error( self::ERR_NOT_FOUND, __( 'Partner not found.', 'helpnagaland-core' ) );
		}

		global $wpdb;
		$ok = $wpdb->update(
			HNC_Schema::table_partners(),
			array( 'active' => $active_int ),
			array( 'id' => $partner_id ),
			array( '%d' ),
			array( '%d' )
		);
		if ( false === $ok ) {
			return new WP_Error( self::ERR_DB, __( 'Database update failed.', 'helpnagaland-core' ) );
		}

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_system(
				'partner_set_active',
				array( 'partner_id' => $partner_id, 'active' => $active_int )
			);
		}

		return true;
	}

	/**
	 * Update cosmetic fields (name, contact email, gpg fingerprint).
	 * Slug and wp_user_id are immutable once set.
	 *
	 * @param int   $partner_id Partner ID.
	 * @param array $fields     Fields to update.
	 * @return true|WP_Error
	 */
	public static function update( $partner_id, $fields ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$partner_id = (int) $partner_id;
		$row        = self::get( $partner_id );
		if ( null === $row ) {
			return new WP_Error( self::ERR_NOT_FOUND, __( 'Partner not found.', 'helpnagaland-core' ) );
		}

		$allowed = array();
		$formats = array();

		if ( array_key_exists( 'name', $fields ) ) {
			$name = trim( (string) $fields['name'] );
			if ( '' === $name || strlen( $name ) > 120 ) {
				return new WP_Error( self::ERR_BAD_INPUT, __( 'Invalid name.', 'helpnagaland-core' ) );
			}
			$allowed['name'] = $name;
			$formats[]       = '%s';
		}

		if ( array_key_exists( 'contact_email', $fields ) ) {
			$email = trim( (string) $fields['contact_email'] );
			if ( '' !== $email && ! is_email( $email ) ) {
				return new WP_Error( self::ERR_BAD_INPUT, __( 'Invalid email.', 'helpnagaland-core' ) );
			}
			$allowed['contact_email'] = '' === $email ? null : $email;
			$formats[]                 = '%s';
		}

		if ( array_key_exists( 'gpg_fingerprint', $fields ) ) {
			$fp = self::normalize_gpg( (string) $fields['gpg_fingerprint'] );
			$allowed['contact_gpg_fingerprint'] = '' === $fp ? null : $fp;
			$formats[]                          = '%s';
		}

		if ( empty( $allowed ) ) {
			return true; // Nothing to do; not an error.
		}

		global $wpdb;
		$ok = $wpdb->update(
			HNC_Schema::table_partners(),
			$allowed,
			array( 'id' => $partner_id ),
			$formats,
			array( '%d' )
		);
		if ( false === $ok ) {
			return new WP_Error( self::ERR_DB, __( 'Database update failed.', 'helpnagaland-core' ) );
		}

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_system(
				'partner_update',
				array( 'partner_id' => $partner_id, 'fields' => array_keys( $allowed ) )
			);
		}

		return true;
	}


	/* ------------------------------------------------------------------
	 * READ
	 * ------------------------------------------------------------------ */

	/**
	 * Fetch a partner by row ID.
	 *
	 * @param int $id Row ID.
	 * @return object|null
	 */
	public static function get( $id ) {
		global $wpdb;
		$table = HNC_Schema::table_partners();
		$row   = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d LIMIT 1", (int) $id )
		);
		return $row ? $row : null;
	}

	/**
	 * Fetch a partner by canonical slug.
	 *
	 * @param string $slug Slug.
	 * @return object|null
	 */
	public static function get_by_slug( $slug ) {
		$slug = self::normalize_slug( $slug );
		if ( '' === $slug ) {
			return null;
		}
		global $wpdb;
		$table = HNC_Schema::table_partners();
		$row   = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE slug = %s LIMIT 1", $slug )
		);
		return $row ? $row : null;
	}

	/**
	 * Fetch a partner by WordPress user ID.
	 *
	 * @param int $wp_user_id WP user ID.
	 * @return object|null
	 */
	public static function get_by_wp_user( $wp_user_id ) {
		$wp_user_id = (int) $wp_user_id;
		if ( $wp_user_id <= 0 ) {
			return null;
		}
		global $wpdb;
		$table = HNC_Schema::table_partners();
		$row   = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE wp_user_id = %d LIMIT 1", $wp_user_id )
		);
		return $row ? $row : null;
	}

	/**
	 * List partners. If $only_active is true, returns just active ones.
	 *
	 * @param bool $only_active Filter flag.
	 * @return array
	 */
	public static function list_all( $only_active = false ) {
		global $wpdb;
		$table = HNC_Schema::table_partners();
		if ( $only_active ) {
			$rows = $wpdb->get_results( "SELECT * FROM {$table} WHERE active = 1 ORDER BY name ASC" );
		} else {
			$rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY active DESC, name ASC" );
		}
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Look up a partner by either slug or numeric ID (what
	 * HNC_Drug_Forward accepts). Used by the forward integration.
	 *
	 * @param string $identifier Slug or numeric ID as string.
	 * @return object|null
	 */
	public static function resolve( $identifier ) {
		$identifier = trim( (string) $identifier );
		if ( '' === $identifier ) {
			return null;
		}
		if ( preg_match( '/^\d+$/', $identifier ) ) {
			$row = self::get( (int) $identifier );
			return $row;
		}
		return self::get_by_slug( $identifier );
	}


	/* ------------------------------------------------------------------
	 * LOGIN TIMESTAMP
	 * ------------------------------------------------------------------ */

	/**
	 * Update the last_login timestamp when a partner signs in. Called
	 * from the wp_login action hook.
	 *
	 * @param int $wp_user_id WordPress user ID.
	 * @return void
	 */
	public static function touch_last_login( $wp_user_id ) {
		$row = self::get_by_wp_user( $wp_user_id );
		if ( null === $row ) {
			return;
		}
		global $wpdb;
		$wpdb->update(
			HNC_Schema::table_partners(),
			array( 'last_login' => current_time( 'mysql' ) ),
			array( 'id' => (int) $row->id ),
			array( '%s' ),
			array( '%d' )
		);
	}


	/* ------------------------------------------------------------------
	 * INTERNAL HELPERS
	 * ------------------------------------------------------------------ */

	/**
	 * Normalize a partner slug: lowercase, [a-z0-9_-], 1 to 60 chars.
	 *
	 * @param string $raw Raw input.
	 * @return string
	 */
	public static function normalize_slug( $raw ) {
		$s = strtolower( trim( (string) $raw ) );
		$s = preg_replace( '/[^a-z0-9_\-]+/', '', $s );
		$s = substr( (string) $s, 0, 60 );
		return (string) $s;
	}

	/**
	 * Normalize a GPG fingerprint: uppercase hex, optional spaces removed,
	 * exactly 40 chars or empty.
	 *
	 * @param string $raw Raw input.
	 * @return string
	 */
	private static function normalize_gpg( $raw ) {
		$s = preg_replace( '/\s+/', '', strtoupper( (string) $raw ) );
		if ( ! preg_match( '/^[0-9A-F]{40}$/', (string) $s ) ) {
			return '';
		}
		return (string) $s;
	}

	/**
	 * Capability gate for partner management. Uses the existing
	 * hnc_manage_partners capability defined in Phase 1.
	 *
	 * @return true|WP_Error
	 */
	private static function require_cap() {
		$cap = class_exists( 'HNC_Roles' ) ? HNC_Roles::CAP_MANAGE_PARTNERS : 'hnc_manage_partners';
		if ( ! function_exists( 'current_user_can' ) || ! current_user_can( $cap ) ) {
			return new WP_Error(
				self::ERR_UNAUTHORIZED,
				__( 'You do not have permission to manage partners.', 'helpnagaland-core' )
			);
		}
		return true;
	}
}
