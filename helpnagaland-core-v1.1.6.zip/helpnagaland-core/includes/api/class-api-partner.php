<?php
/**
 * Partner REST API: endpoints partners use to view and act on their
 * forwarded cases.
 *
 * All endpoints here:
 *   - Require a logged-in user with the hnc_partner_access capability.
 *   - Scope EVERY query to the partner row owned by that user. A partner
 *     CANNOT see or mutate another partner's cases.
 *   - Require the standard WordPress REST nonce.
 *
 * Endpoints:
 *   GET    /partner/forwards                 list my forwarded cases
 *   GET    /partner/forwards/{id}            full detail of one case
 *   POST   /partner/forwards/{id}/acknowledge
 *   POST   /partner/forwards/{id}/acted
 *   POST   /partner/forwards/{id}/closed
 *   GET    /partner/me                       my partner profile (active status, name)
 *
 * These are under the same hnc/v1 namespace as every other endpoint.
 * They sit next to /admin/... and are intentionally narrower: a partner
 * cannot call any /admin endpoint regardless of their hnc_partner_access
 * capability.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Api_Partner
 */
final class HNC_Api_Partner {


	/* ------------------------------------------------------------------
	 * BOOTSTRAP
	 * ------------------------------------------------------------------ */

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );
	}

	/**
	 * Register the six partner endpoints.
	 *
	 * @return void
	 */
	public static function register_rest_routes() {
		$cap = 'hnc_partner_access';
		$permission = HNC_Api_Nonce::cap( $cap );

		register_rest_route(
			HNC_API_NAMESPACE,
			'/partner/me',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_me' ),
				'permission_callback' => $permission,
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/partner/forwards',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_list_forwards' ),
				'permission_callback' => $permission,
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/partner/forwards/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_get_forward' ),
				'permission_callback' => $permission,
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/partner/forwards/(?P<id>\d+)/acknowledge',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_acknowledge' ),
				'permission_callback' => $permission,
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/partner/forwards/(?P<id>\d+)/acted',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_mark_acted' ),
				'permission_callback' => $permission,
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/partner/forwards/(?P<id>\d+)/closed',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_mark_closed' ),
				'permission_callback' => $permission,
			)
		);
	}


	/* ------------------------------------------------------------------
	 * REST CALLBACKS
	 * ------------------------------------------------------------------ */

	/**
	 * GET /partner/me
	 * Returns the current partner's profile row (id, slug, name, active).
	 *
	 * @return WP_REST_Response
	 */
	public static function rest_me() {
		$uid = function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0;
		$p   = HNC_Partner_Model::get_by_wp_user( $uid );
		if ( null === $p ) {
			return self::err_404( 'You are not an onboarded partner.' );
		}
		return self::ok(
			array(
				'id'             => (int) $p->id,
				'slug'           => (string) $p->slug,
				'name'           => (string) $p->name,
				'active'         => (int) $p->active === 1,
				'onboarded_at'   => (string) $p->onboarded_at,
				'last_login'     => $p->last_login ? (string) $p->last_login : null,
			)
		);
	}

	/**
	 * GET /partner/forwards?state=unseen&page=1&per_page=20
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function rest_list_forwards( $request ) {
		$rl = HNC_Api_Ratelimit::partner_user( 'partner_list', 30, 60 );
		if ( null !== $rl ) {
			return self::err( $rl );
		}

		$uid = function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0;
		$filters = array(
			'state'    => (string) $request->get_param( 'state' ),
			'page'     => (int) $request->get_param( 'page' ),
			'per_page' => (int) $request->get_param( 'per_page' ),
		);
		$result = HNC_Partner_Forward_Log::list_for_partner( $uid, $filters );
		if ( is_wp_error( $result ) ) {
			return self::err( $result );
		}
		return self::ok( $result );
	}

	/**
	 * GET /partner/forwards/{id}
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function rest_get_forward( $request ) {
		$uid = function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0;
		$fid = (int) $request->get_param( 'id' );
		$r   = HNC_Partner_Forward_Log::get_for_partner( $uid, $fid );
		if ( is_wp_error( $r ) ) {
			return self::err( $r );
		}
		return self::ok( $r );
	}

	/**
	 * POST /partner/forwards/{id}/acknowledge (body: note).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function rest_acknowledge( $request ) {
		$rl = HNC_Api_Ratelimit::partner_user( 'partner_write', 30, 60 );
		if ( null !== $rl ) {
			return self::err( $rl );
		}
		$uid  = function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0;
		$fid  = (int) $request->get_param( 'id' );
		$note = (string) $request->get_param( 'note' );
		$r    = HNC_Partner_Forward_Log::acknowledge( $uid, $fid, $note );
		return self::result_response( $r, array( 'id' => $fid, 'state' => 'acknowledged' ) );
	}

	/**
	 * POST /partner/forwards/{id}/acted.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function rest_mark_acted( $request ) {
		$rl = HNC_Api_Ratelimit::partner_user( 'partner_write', 30, 60 );
		if ( null !== $rl ) {
			return self::err( $rl );
		}
		$uid  = function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0;
		$fid  = (int) $request->get_param( 'id' );
		$note = (string) $request->get_param( 'note' );
		$r    = HNC_Partner_Forward_Log::mark_acted( $uid, $fid, $note );
		return self::result_response( $r, array( 'id' => $fid, 'state' => 'acted' ) );
	}

	/**
	 * POST /partner/forwards/{id}/closed.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function rest_mark_closed( $request ) {
		$rl = HNC_Api_Ratelimit::partner_user( 'partner_write', 30, 60 );
		if ( null !== $rl ) {
			return self::err( $rl );
		}
		$uid  = function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0;
		$fid  = (int) $request->get_param( 'id' );
		$note = (string) $request->get_param( 'note' );
		$r    = HNC_Partner_Forward_Log::mark_closed( $uid, $fid, $note );
		return self::result_response( $r, array( 'id' => $fid, 'state' => 'closed' ) );
	}


	/* ------------------------------------------------------------------
	 * RESPONSE HELPERS
	 * ------------------------------------------------------------------ */

	/**
	 * Success response with uniform envelope.
	 *
	 * @param mixed $data Data payload.
	 * @return WP_REST_Response
	 */
	private static function ok( $data ) {
		return new WP_REST_Response( array( 'success' => true, 'data' => $data ), 200 );
	}

	/**
	 * Translate a WP_Error into a REST response with proper HTTP status.
	 *
	 * @param WP_Error $err Error.
	 * @return WP_REST_Response
	 */
	private static function err( $err ) {
		$data = $err instanceof WP_Error ? $err->get_error_data() : null;
		$http = is_array( $data ) && isset( $data['status'] ) ? (int) $data['status'] : 400;
		$code = $err instanceof WP_Error ? $err->get_error_code() : 'hnc_error';

		$map = array(
			'hnc_unauthorized'        => 403,
			'hnc_partner_not_active'  => 403,
			'hnc_forward_not_found'   => 404,
			'hnc_forward_bad_state'   => 409,
			'hnc_rate_limit'          => 429,
		);
		if ( isset( $map[ $code ] ) ) {
			$http = $map[ $code ];
		}

		return new WP_REST_Response(
			array(
				'success' => false,
				'code'    => $code,
				'message' => $err instanceof WP_Error ? $err->get_error_message() : (string) $err,
			),
			$http
		);
	}

	/**
	 * 404 shortcut.
	 *
	 * @param string $msg Message.
	 * @return WP_REST_Response
	 */
	private static function err_404( $msg ) {
		return new WP_REST_Response(
			array( 'success' => false, 'code' => 'hnc_not_found', 'message' => (string) $msg ),
			404
		);
	}

	/**
	 * Normalize a domain method return (true | WP_Error) into a REST
	 * response with a success payload.
	 *
	 * @param mixed $result          Domain result.
	 * @param array $success_payload Payload for success.
	 * @return WP_REST_Response
	 */
	private static function result_response( $result, $success_payload ) {
		if ( is_wp_error( $result ) ) {
			return self::err( $result );
		}
		return self::ok( $success_payload );
	}
}
