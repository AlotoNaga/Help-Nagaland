<?php
/**
 * API Nonce: centralised nonce verification for admin endpoints.
 *
 * WordPress REST authentication for logged-in users is cookie-based. That
 * cookie auth is only accepted when the request includes a matching REST
 * nonce in the X-WP-Nonce header. Without it, WordPress ignores the cookie
 * and treats the request as unauthenticated, which then fails the
 * capability check on every admin endpoint.
 *
 * This class exposes a single method that every admin endpoint's
 * permission_callback uses as its first check:
 *
 *     if ( ( $err = HNC_Api_Nonce::verify( $request ) ) ) { return $err; }
 *
 * It returns null on success or a WP_Error on failure. We treat a missing
 * or invalid nonce as 401, which is the correct code for "you did not
 * prove you are who you say you are".
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Api_Nonce
 */
final class HNC_Api_Nonce {


	const ERR_MISSING = 'hnc_missing_nonce';
	const ERR_INVALID = 'hnc_invalid_nonce';


	/**
	 * Verify the X-WP-Nonce header. Returns null on success or a
	 * WP_Error on failure. Callers chain into the capability check
	 * after this passes.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_Error|null
	 */
	public static function verify( $request ) {
		if ( ! $request instanceof WP_REST_Request ) {
			return new WP_Error( self::ERR_MISSING, __( 'No request context available.', 'helpnagaland-core' ) );
		}

		$nonce = (string) $request->get_header( 'x_wp_nonce' );
		if ( '' === $nonce ) {
			$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		}
		if ( '' === $nonce ) {
			$nonce = isset( $_SERVER['HTTP_X_WP_NONCE'] )
				? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_WP_NONCE'] ) )
				: '';
		}

		if ( '' === $nonce ) {
			return new WP_Error(
				self::ERR_MISSING,
				__( 'Missing security token. Refresh the page and try again.', 'helpnagaland-core' ),
				array( 'status' => 401 )
			);
		}

		if ( ! function_exists( 'wp_verify_nonce' ) ) {
			return new WP_Error(
				self::ERR_INVALID,
				__( 'Nonce verification unavailable.', 'helpnagaland-core' ),
				array( 'status' => 500 )
			);
		}

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			if ( class_exists( 'HNC_Logger' ) ) {
				HNC_Logger::log_security(
					HNC_Logger::ACTION_SIGNATURE_FAIL,
					array(
						'reason'   => 'invalid_rest_nonce',
						'endpoint' => $request->get_route(),
					)
				);
			}
			return new WP_Error(
				self::ERR_INVALID,
				__( 'Your session has expired. Refresh the page and try again.', 'helpnagaland-core' ),
				array( 'status' => 401 )
			);
		}

		return null;
	}


	/**
	 * Shortcut that combines nonce verification with a capability check.
	 * Used as the `permission_callback` on most admin endpoints so each
	 * callback stays a one-liner.
	 *
	 *     'permission_callback' => HNC_Api_Nonce::cap( 'hnc_moderate_alcohol' ),
	 *
	 * Returns a closure that WordPress invokes with the request. Returns
	 * true on success, WP_Error on failure. WordPress translates WP_Error
	 * to a proper HTTP status automatically.
	 *
	 * @param string $capability WP capability required.
	 * @return callable
	 */
	public static function cap( $capability ) {
		return function ( $request ) use ( $capability ) {
			$nonce_err = HNC_Api_Nonce::verify( $request );
			if ( null !== $nonce_err ) {
				return $nonce_err;
			}
			if ( ! function_exists( 'current_user_can' ) || ! current_user_can( $capability ) ) {
				return new WP_Error(
					'hnc_forbidden',
					__( 'You do not have permission to perform this action.', 'helpnagaland-core' ),
					array( 'status' => 403 )
				);
			}
			return true;
		};
	}


	/**
	 * Variant that accepts multiple capabilities, granting access if
	 * the user has ANY of them. Useful for endpoints that should be
	 * callable by either moderator role or administrator.
	 *
	 * @param array $capabilities List of capability strings.
	 * @return callable
	 */
	public static function cap_any( array $capabilities ) {
		return function ( $request ) use ( $capabilities ) {
			$nonce_err = HNC_Api_Nonce::verify( $request );
			if ( null !== $nonce_err ) {
				return $nonce_err;
			}
			if ( ! function_exists( 'current_user_can' ) ) {
				return new WP_Error( 'hnc_forbidden', '', array( 'status' => 403 ) );
			}
			foreach ( $capabilities as $cap ) {
				if ( current_user_can( $cap ) ) {
					return true;
				}
			}
			return new WP_Error(
				'hnc_forbidden',
				__( 'You do not have permission to perform this action.', 'helpnagaland-core' ),
				array( 'status' => 403 )
			);
		};
	}
}
