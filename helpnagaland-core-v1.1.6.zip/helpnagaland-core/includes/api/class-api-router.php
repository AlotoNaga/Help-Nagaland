<?php
/**
 * API Router: bootstraps the entire REST API layer on plugins_loaded.
 *
 * This is a lightweight orchestrator. Each of the three concrete REST
 * classes (HNC_Api_Public, HNC_Api_Admin, HNC_Api_Nonce helpers) has
 * its own init(). The router simply calls them in the right order and
 * exposes a single init() that the main plugin file wires into
 * plugins_loaded.
 *
 * Keeping this class in place means the Phase 6 bootstrap block in
 * helpnagaland-core.php is one line:
 *
 *     HNC_Api_Router::init();
 *
 * instead of three separate class calls. It also gives us a natural
 * place to add cross-cutting concerns later (global CORS, response
 * envelope filters, deprecation warnings) without touching every
 * individual endpoint class.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Api_Router
 */
final class HNC_Api_Router {


	/**
	 * Initialise the REST API layer.
	 *
	 * @return void
	 */
	public static function init() {
		if ( class_exists( 'HNC_Api_Public' ) ) {
			HNC_Api_Public::init();
		}
		if ( class_exists( 'HNC_Api_Admin' ) ) {
			HNC_Api_Admin::init();
		}

		// Lightweight hardening: make sure the HNC namespace is
		// discoverable in the REST index without leaking internal route
		// details beyond what register_rest_route already exposes.
		add_filter( 'rest_endpoints', array( __CLASS__, 'filter_rest_endpoints' ), 10, 1 );
	}

	/**
	 * Optional hook to strip sensitive metadata from the exposed REST
	 * index. For Phase 6 we leave the index intact; this filter is a
	 * placeholder that later phases can extend.
	 *
	 * @param array $endpoints Registered endpoints keyed by route.
	 * @return array
	 */
	public static function filter_rest_endpoints( $endpoints ) {
		return $endpoints;
	}

	/**
	 * Return the list of registered route prefixes under the HNC
	 * namespace. Useful for admin diagnostics pages.
	 *
	 * @return array List of route path strings.
	 */
	public static function list_registered_routes() {
		if ( ! function_exists( 'rest_get_server' ) ) {
			return array();
		}
		$server = rest_get_server();
		if ( ! $server || ! is_callable( array( $server, 'get_routes' ) ) ) {
			return array();
		}

		$namespace = '/' . HNC_API_NAMESPACE . '/';
		$out       = array();

		foreach ( $server->get_routes() as $route => $handlers ) {
			if ( 0 === strpos( $route, $namespace ) ) {
				$out[] = $route;
			}
		}

		sort( $out );
		return $out;
	}
}
