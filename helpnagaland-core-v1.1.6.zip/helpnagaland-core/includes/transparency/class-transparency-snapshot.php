<?php
/**
 * Transparency Snapshot: monthly aggregation.
 *
 * Produces a single row in hnc_transparency_snapshots that captures the
 * counts for one (year, month) period across both pipelines. Snapshots are
 * the authoritative numbers used on the public transparency page and in
 * any external reporting. They are built by the monthly cron and may also
 * be rebuilt on demand by a moderator.
 *
 * What is counted (all based on submitted_at falling inside the period):
 *
 *   Alcohol:
 *     - alcohol_received:        all rows submitted in period.
 *     - alcohol_approved:        rows with status = approved or archived
 *                                that passed through approved.
 *     - alcohol_rejected:        rows with status = rejected.
 *     - alcohol_acted_by_police: reserved for future integration (staying
 *                                at 0 in v1 since we have no signal source).
 *
 *   Drug:
 *     - drug_received:  rows submitted in period.
 *     - drug_approved:  rows that reached approved, resolved, or archived
 *                       via approved.
 *     - drug_forwarded: distinct report_ids that have at least one forward
 *                       event in the audit log during or after the period.
 *     - drug_acted:     rows whose status is resolved.
 *
 * The snapshot row carries published_at which is set by Publish. A
 * snapshot is not visible on the public transparency page until its
 * published_at is non-null.
 *
 * Spec rule R08 binds Nagaland Me to publish transparency every month
 * regardless of whether the numbers are flattering. This class computes
 * the numbers without regard for publication status.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Transparency_Snapshot
 */
final class HNC_Transparency_Snapshot {


	const ERR_UNAUTHORIZED = 'hnc_unauthorized';
	const ERR_BAD_PERIOD   = 'hnc_bad_period';
	const ERR_DB           = 'hnc_db_error';


	/* ------------------------------------------------------------------
	 * BUILD
	 * ------------------------------------------------------------------ */

	/**
	 * Build or rebuild the snapshot row for a given year and month.
	 * Idempotent: re-running updates the counts but preserves published_at
	 * and admin_note if the row already existed.
	 *
	 * Requires CAP_PUBLISH_TRANSPARENCY unless $bypass_cap is true (cron).
	 *
	 * @param int  $year       Four-digit year (e.g. 2026).
	 * @param int  $month      1 to 12.
	 * @param bool $bypass_cap Skip permission check (cron only).
	 * @return int|WP_Error Row ID on success, WP_Error on failure.
	 */
	public static function build( $year, $month, $bypass_cap = false ) {
		if ( ! $bypass_cap && ! self::can_publish() ) {
			return new WP_Error(
				self::ERR_UNAUTHORIZED,
				__( 'You do not have permission to build transparency snapshots.', 'helpnagaland-core' )
			);
		}

		$year  = (int) $year;
		$month = (int) $month;
		if ( $year < 2025 || $year > 2100 || $month < 1 || $month > 12 ) {
			return new WP_Error( self::ERR_BAD_PERIOD, __( 'Invalid year or month.', 'helpnagaland-core' ) );
		}

		$period = self::period_bounds( $year, $month );

		$counts = self::compute_counts( $period['start'], $period['end'] );

		global $wpdb;
		$table   = $wpdb->prefix . HNC_TABLE_PREFIX . 'transparency_snapshots';
		$existing = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE period_year = %d AND period_month = %d LIMIT 1",
				$year,
				$month
			)
		);

		if ( $existing ) {
			$ok = $wpdb->update(
				$table,
				$counts,
				array( 'id' => (int) $existing->id ),
				array( '%d', '%d', '%d', '%d', '%d', '%d', '%d', '%d' ),
				array( '%d' )
			);
			if ( false === $ok ) {
				return new WP_Error( self::ERR_DB, __( 'Could not update snapshot.', 'helpnagaland-core' ) );
			}
			$id = (int) $existing->id;
		} else {
			$row = array_merge(
				array(
					'period_year'  => $year,
					'period_month' => $month,
				),
				$counts
			);
			$ok  = $wpdb->insert(
				$table,
				$row,
				array( '%d', '%d', '%d', '%d', '%d', '%d', '%d', '%d', '%d', '%d' )
			);
			if ( ! $ok ) {
				return new WP_Error( self::ERR_DB, __( 'Could not insert snapshot.', 'helpnagaland-core' ) );
			}
			$id = (int) $wpdb->insert_id;
		}

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_system(
				'transparency_snapshot_built',
				array(
					'period_year'  => $year,
					'period_month' => $month,
					'counts'       => $counts,
					'snapshot_id'  => $id,
				)
			);
		}

		return $id;
	}


	/* ------------------------------------------------------------------
	 * READ: PUBLIC + ADMIN
	 * ------------------------------------------------------------------ */

	/**
	 * Return all published snapshots ordered most recent first. Safe for
	 * public consumption (no PII).
	 *
	 * @param int $limit Max rows (default 24, hard max 120).
	 * @return array Array of associative arrays.
	 */
	public static function get_published( $limit = 24 ) {
		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'transparency_snapshots';
		$limit = min( 120, max( 1, (int) $limit ) );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT period_year, period_month,
				        alcohol_received, alcohol_approved, alcohol_rejected, alcohol_acted_by_police,
				        drug_received, drug_approved, drug_forwarded, drug_acted,
				        published_at, admin_note
				 FROM {$table}
				 WHERE published_at IS NOT NULL
				 ORDER BY period_year DESC, period_month DESC
				 LIMIT %d",
				$limit
			)
		);
		if ( ! is_array( $rows ) ) {
			return array();
		}

		$out = array();
		foreach ( $rows as $r ) {
			$out[] = array(
				'year'     => (int) $r->period_year,
				'month'    => (int) $r->period_month,
				'alcohol' => array(
					'received'         => (int) $r->alcohol_received,
					'approved'         => (int) $r->alcohol_approved,
					'rejected'         => (int) $r->alcohol_rejected,
					'acted_by_police'  => (int) $r->alcohol_acted_by_police,
				),
				'drug' => array(
					'received'  => (int) $r->drug_received,
					'approved'  => (int) $r->drug_approved,
					'forwarded' => (int) $r->drug_forwarded,
					'acted'     => (int) $r->drug_acted,
				),
				'published_at' => (string) $r->published_at,
				'note'         => (string) $r->admin_note,
			);
		}
		return $out;
	}

	/**
	 * Return a single snapshot by period. Unpublished rows are returned
	 * only if the caller holds CAP_PUBLISH_TRANSPARENCY. Published rows
	 * are public.
	 *
	 * @param int $year  Year.
	 * @param int $month Month.
	 * @return array|null
	 */
	public static function get_by_period( $year, $month ) {
		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'transparency_snapshots';

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE period_year = %d AND period_month = %d LIMIT 1",
				(int) $year,
				(int) $month
			)
		);

		if ( ! $row ) {
			return null;
		}

		$published_at = isset( $row->published_at ) ? $row->published_at : null;
		$admin_note   = isset( $row->admin_note ) ? (string) $row->admin_note : '';

		if ( null === $published_at && ! self::can_publish() ) {
			return null;
		}

		return array(
			'id'          => (int) $row->id,
			'year'        => (int) $row->period_year,
			'month'       => (int) $row->period_month,
			'alcohol'     => array(
				'received'        => (int) $row->alcohol_received,
				'approved'        => (int) $row->alcohol_approved,
				'rejected'        => (int) $row->alcohol_rejected,
				'acted_by_police' => (int) $row->alcohol_acted_by_police,
			),
			'drug'        => array(
				'received'  => (int) $row->drug_received,
				'approved'  => (int) $row->drug_approved,
				'forwarded' => (int) $row->drug_forwarded,
				'acted'     => (int) $row->drug_acted,
			),
			'published_at' => null === $published_at ? null : (string) $published_at,
			'note'         => $admin_note,
		);
	}


	/* ------------------------------------------------------------------
	 * INTERNAL: COUNT COMPUTATION
	 * ------------------------------------------------------------------ */

	/**
	 * Compute all eight count fields for a period.
	 *
	 * @param string $start Start datetime (inclusive).
	 * @param string $end   End datetime (exclusive).
	 * @return array Eight keyed integers.
	 */
	private static function compute_counts( $start, $end ) {
		global $wpdb;
		$alcohol = $wpdb->prefix . HNC_TABLE_PREFIX . 'alcohol_reports';
		$drug    = $wpdb->prefix . HNC_TABLE_PREFIX . 'drug_reports';
		$audit   = $wpdb->prefix . HNC_TABLE_PREFIX . 'audit_log';

		// Alcohol counts.
		$alcohol_received = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$alcohol}
				 WHERE submitted_at >= %s AND submitted_at < %s",
				$start,
				$end
			)
		);
		/*
		 * Count everything that reached approved (or archived later) in
		 * the window. The earlier version required `moderated_at IS NOT
		 * NULL`, which silently dropped pins auto-approved by the merge
		 * flow (those never get an explicit moderation timestamp). This
		 * undercount violated R08: "publish monthly numbers regardless
		 * of embarrassment" — we were embarrassing ourselves by being
		 * wrong, not low.
		 */
		$alcohol_approved = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$alcohol}
				 WHERE submitted_at >= %s AND submitted_at < %s
				   AND status IN ('approved', 'archived')",
				$start,
				$end
			)
		);
		$alcohol_rejected = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$alcohol}
				 WHERE submitted_at >= %s AND submitted_at < %s
				   AND status = 'rejected'",
				$start,
				$end
			)
		);

		// Placeholder: no police integration in v1.
		$alcohol_acted_by_police = 0;

		// Drug counts.
		$drug_received = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$drug}
				 WHERE submitted_at >= %s AND submitted_at < %s",
				$start,
				$end
			)
		);
		$drug_approved = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$drug}
				 WHERE submitted_at >= %s AND submitted_at < %s
				   AND status IN ('approved', 'resolved', 'archived')",
				$start,
				$end
			)
		);
		$drug_acted = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$drug}
				 WHERE submitted_at >= %s AND submitted_at < %s
				   AND status = 'resolved'",
				$start,
				$end
			)
		);

		// Drug forwarded: distinct report_ids with at least one forward
		// audit entry where the report was submitted in the period.
		$drug_forwarded = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT report_id) FROM {$audit}
				 WHERE event_type = %s
				   AND action = %s
				   AND report_id IN (
				       SELECT id FROM {$drug}
				       WHERE submitted_at >= %s AND submitted_at < %s
				   )",
				class_exists( 'HNC_Logger' ) ? HNC_Logger::EVENT_DRUG : 'drug',
				class_exists( 'HNC_Logger' ) ? HNC_Logger::ACTION_FORWARD : 'forward',
				$start,
				$end
			)
		);

		return array(
			'alcohol_received'        => $alcohol_received,
			'alcohol_approved'        => $alcohol_approved,
			'alcohol_rejected'        => $alcohol_rejected,
			'alcohol_acted_by_police' => $alcohol_acted_by_police,
			'drug_received'           => $drug_received,
			'drug_approved'           => $drug_approved,
			'drug_forwarded'          => $drug_forwarded,
			'drug_acted'              => $drug_acted,
		);
	}


	/* ------------------------------------------------------------------
	 * INTERNAL HELPERS
	 * ------------------------------------------------------------------ */

	/**
	 * Compute start (inclusive) and end (exclusive) MySQL datetime strings
	 * for a given year and month. End is the first moment of the following
	 * month, which is the cleanest form for SQL range queries.
	 *
	 * @param int $year  Year.
	 * @param int $month 1 to 12.
	 * @return array{start:string,end:string}
	 */
	private static function period_bounds( $year, $month ) {
		$start = sprintf( '%04d-%02d-01 00:00:00', $year, $month );
		$next_month = $month + 1;
		$next_year  = $year;
		if ( $next_month > 12 ) {
			$next_month = 1;
			$next_year  = $year + 1;
		}
		$end = sprintf( '%04d-%02d-01 00:00:00', $next_year, $next_month );
		return array( 'start' => $start, 'end' => $end );
	}

	/**
	 * Capability check.
	 *
	 * @return bool
	 */
	private static function can_publish() {
		$cap = class_exists( 'HNC_Roles' ) ? HNC_Roles::CAP_PUBLISH_TRANSPARENCY : 'hnc_publish_transparency';
		return function_exists( 'current_user_can' ) && current_user_can( $cap );
	}
}
