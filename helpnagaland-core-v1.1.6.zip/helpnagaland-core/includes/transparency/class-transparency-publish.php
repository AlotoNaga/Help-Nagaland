<?php
/**
 * Transparency Publish: controls what snapshot rows are visible.
 *
 * Responsibilities:
 *
 *   - publish($year, $month, $note): mark a snapshot as public.
 *   - unpublish($year, $month): withdraw a snapshot (should be rare).
 *   - auto_publish_previous_month(): the monthly cron worker that builds
 *     and publishes last month's snapshot at 09:00 IST on the 1st of the
 *     current month.
 *   - REST endpoint GET /hnc/v1/transparency for the public.
 *
 * Spec rule R08 commits Nagaland Me to publishing every month, regardless
 * of whether the numbers are favorable. The auto publish worker fulfills
 * that commitment without operator intervention. An admin can still add
 * an admin_note manually after the fact via publish() again (which will
 * set/overwrite the note).
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Transparency_Publish
 */
final class HNC_Transparency_Publish {


	const ERR_UNAUTHORIZED = 'hnc_unauthorized';
	const ERR_NOT_FOUND    = 'hnc_snapshot_not_found';
	const ERR_DB           = 'hnc_db_error';


	/* ------------------------------------------------------------------
	 * BOOTSTRAP
	 * ------------------------------------------------------------------ */

	/**
	 * Register REST routes and monthly cron callback.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );

		if ( class_exists( 'HNC_Cron' ) ) {
			add_action( HNC_Cron::HOOK_TRANSPARENCY_PUBLISH, array( __CLASS__, 'auto_publish_previous_month' ) );
		}
	}

	/**
	 * Register the single public REST route. The admin-side publish/
	 * unpublish endpoints are exposed through the Phase 6 admin REST
	 * surface to avoid duplicating nonce handling here.
	 *
	 * @return void
	 */
	public static function register_rest_routes() {
		register_rest_route(
			HNC_API_NAMESPACE,
			'/transparency',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_public_list' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'limit' => array( 'type' => 'integer', 'required' => false ),
				),
			)
		);
	}


	/* ------------------------------------------------------------------
	 * REST CALLBACK
	 * ------------------------------------------------------------------ */

	/**
	 * GET /transparency: list all published snapshots, newest first.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function rest_public_list( $request ) {
		$limit = (int) $request->get_param( 'limit' );
		if ( $limit <= 0 ) {
			$limit = 24;
		}
		$data = class_exists( 'HNC_Transparency_Snapshot' )
			? HNC_Transparency_Snapshot::get_published( $limit )
			: array();

		$response = new WP_REST_Response(
			array(
				'success' => true,
				'count'   => count( $data ),
				'data'    => $data,
			),
			200
		);
		$response->header( 'Cache-Control', 'public, max-age=900' );
		return $response;
	}


	/* ------------------------------------------------------------------
	 * PUBLISH / UNPUBLISH
	 * ------------------------------------------------------------------ */

	/**
	 * Publish a snapshot. Sets published_at to now. If the snapshot does
	 * not yet exist for the period, it is built first. Admin note is
	 * optional.
	 *
	 * @param int    $year       Year.
	 * @param int    $month      Month 1-12.
	 * @param string $admin_note Optional note (max 2000 chars).
	 * @param bool   $bypass_cap Skip capability check.
	 * @return true|WP_Error
	 */
	public static function publish( $year, $month, $admin_note = '', $bypass_cap = false ) {
		if ( ! $bypass_cap && ! self::can_publish() ) {
			return new WP_Error(
				self::ERR_UNAUTHORIZED,
				__( 'You do not have permission to publish transparency snapshots.', 'helpnagaland-core' )
			);
		}

		// Ensure the snapshot exists and is current.
		if ( ! class_exists( 'HNC_Transparency_Snapshot' ) ) {
			return new WP_Error( self::ERR_DB, __( 'Transparency subsystem unavailable.', 'helpnagaland-core' ) );
		}
		$id = HNC_Transparency_Snapshot::build( $year, $month, true );
		if ( is_wp_error( $id ) ) {
			return $id;
		}

		$admin_note = (string) $admin_note;
		if ( strlen( $admin_note ) > 2000 ) {
			$admin_note = substr( $admin_note, 0, 2000 );
		}

		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'transparency_snapshots';
		$data  = array(
			'published_at' => current_time( 'mysql' ),
			'admin_note'   => $admin_note,
		);
		$ok = $wpdb->update(
			$table,
			$data,
			array( 'id' => (int) $id ),
			array( '%s', '%s' ),
			array( '%d' )
		);

		if ( false === $ok ) {
			return new WP_Error( self::ERR_DB, __( 'Could not publish snapshot.', 'helpnagaland-core' ) );
		}

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_system(
				'transparency_published',
				array(
					'snapshot_id' => (int) $id,
					'year'        => (int) $year,
					'month'       => (int) $month,
					'moderator'   => function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0,
				)
			);
		}

		return true;
	}

	/**
	 * Unpublish a snapshot. Rare, but possible (for example if a count
	 * turned out to be wrong and needs recomputation). Clears published_at.
	 *
	 * @param int  $year       Year.
	 * @param int  $month      Month 1-12.
	 * @param bool $bypass_cap Skip capability check.
	 * @return true|WP_Error
	 */
	public static function unpublish( $year, $month, $bypass_cap = false ) {
		if ( ! $bypass_cap && ! self::can_publish() ) {
			return new WP_Error(
				self::ERR_UNAUTHORIZED,
				__( 'You do not have permission to unpublish transparency snapshots.', 'helpnagaland-core' )
			);
		}

		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'transparency_snapshots';
		$row   = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE period_year = %d AND period_month = %d LIMIT 1",
				(int) $year,
				(int) $month
			)
		);
		if ( ! $row ) {
			return new WP_Error( self::ERR_NOT_FOUND, __( 'Snapshot not found.', 'helpnagaland-core' ) );
		}

		$ok = $wpdb->update(
			$table,
			array( 'published_at' => null ),
			array( 'id' => (int) $row->id ),
			array( '%s' ),
			array( '%d' )
		);
		if ( false === $ok ) {
			return new WP_Error( self::ERR_DB, __( 'Could not unpublish snapshot.', 'helpnagaland-core' ) );
		}

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_system(
				'transparency_unpublished',
				array(
					'snapshot_id' => (int) $row->id,
					'year'        => (int) $year,
					'month'       => (int) $month,
					'moderator'   => function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0,
				)
			);
		}

		return true;
	}


	/* ------------------------------------------------------------------
	 * MONTHLY CRON
	 * ------------------------------------------------------------------ */

	/**
	 * Build and publish the snapshot for LAST month. Runs on the 1st of
	 * the current month at 09:00 IST. If the snapshot is already published,
	 * does nothing.
	 *
	 * @return array { built, published, year, month }.
	 */
	public static function auto_publish_previous_month() {
		// Compute last month in IST (no DST in India).
		$ist_offset = 5 * HOUR_IN_SECONDS + 30 * MINUTE_IN_SECONDS;
		$now_ist    = time() + $ist_offset;
		$today_ist  = gmdate( 'Y-m-d', $now_ist );
		$ts         = strtotime( $today_ist . ' -1 month' );
		$year       = (int) gmdate( 'Y', $ts );
		$month      = (int) gmdate( 'n', $ts );

		$result = array(
			'built'     => false,
			'published' => false,
			'year'      => $year,
			'month'     => $month,
		);

		if ( ! class_exists( 'HNC_Transparency_Snapshot' ) ) {
			return $result;
		}

		// Build (idempotent). Bypass cap because cron runs as no user.
		$built = HNC_Transparency_Snapshot::build( $year, $month, true );
		if ( is_wp_error( $built ) ) {
			if ( class_exists( 'HNC_Logger' ) ) {
				HNC_Logger::log_system(
					'transparency_auto_build_failed',
					array(
						'year'  => $year,
						'month' => $month,
						'error' => $built->get_error_code(),
					)
				);
			}
			return $result;
		}
		$result['built'] = true;

		// Check whether it is already published. If so, do not re-publish
		// (that would reset published_at to now, which would be misleading).
		$existing = HNC_Transparency_Snapshot::get_by_period( $year, $month );
		if ( is_array( $existing ) && ! empty( $existing['published_at'] ) ) {
			return $result;
		}

		// Publish.
		$pub = self::publish( $year, $month, '', true );
		if ( true === $pub ) {
			$result['published'] = true;
			if ( class_exists( 'HNC_Logger' ) ) {
				HNC_Logger::log_system(
					'transparency_auto_published',
					array(
						'year'  => $year,
						'month' => $month,
					)
				);
			}
		}

		return $result;
	}


	/* ------------------------------------------------------------------
	 * INTERNAL
	 * ------------------------------------------------------------------ */

	/**
	 * Capability check.
	 *
	 * @return bool
	 */
	private static function can_publish() {
		$cap = class_exists( 'HNC_Roles' ) ? HNC_Roles::CAP_PUBLISH_TRANSPARENCY : 'hnc_publish_transparency';
		return function_exists( 'current_user_can' ) && current_user_can( $cap );
	}
}
