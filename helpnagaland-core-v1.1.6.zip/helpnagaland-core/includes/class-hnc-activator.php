<?php
/**
 * Plugin activation handler.
 *
 * Runs exactly once when the plugin is activated from the WP-Admin plugins
 * screen. Responsibilities:
 *
 *   1. Install database tables (via HNC_Schema).
 *   2. Seed default plugin options.
 *   3. Register roles and capabilities (via HNC_Roles).
 *   4. Create the protected uploads directory with .htaccess deny rules.
 *   5. Record activation timestamp.
 *
 * Activation MUST be idempotent. Running activate() twice in a row must not
 * produce errors or duplicate data. All operations below follow that rule:
 *   - dbDelta is idempotent by design.
 *   - add_option() does not overwrite existing values.
 *   - add_role() is a no-op if the role already exists.
 *   - Directory and file creation are guarded by existence checks.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Activator
 */
final class HNC_Activator {


	/**
	 * Main activation entry point. Called from register_activation_hook.
	 *
	 * @return void
	 */
	public static function activate() {

		// 1. Install or upgrade database tables.
		if ( class_exists( 'HNC_Schema' ) ) {
			HNC_Schema::install();
		}

		// 2. Seed default options (only if not already present).
		self::seed_default_options();

		// 3. Register roles and capabilities.
		if ( class_exists( 'HNC_Roles' ) ) {
			HNC_Roles::init();
		}

		// 4. Create protected uploads directory with deny rules.
		self::create_protected_uploads_dir();

		// 5. Stamp activation.
		update_option( 'hnc_activated_at', current_time( 'mysql' ) );
		update_option( 'hnc_version', HNC_VERSION );
		update_option( 'hnc_db_version', HNC_DB_VERSION );

		// 6. Flush rewrite rules in case future phases register CPTs or endpoints.
		flush_rewrite_rules();
	}


	/* ============================================================
	 * DEFAULT OPTIONS
	 * ============================================================ */

	/**
	 * Seed plugin configuration options. Uses add_option so existing values
	 * are preserved on reactivation.
	 *
	 * @return void
	 */
	private static function seed_default_options() {

		$defaults = array(

			/* Versioning */
			'hnc_version'                               => HNC_VERSION,
			'hnc_db_version'                            => HNC_DB_VERSION,

			/* Kill switch and maintenance */
			'hnc_killswitch_active'                     => 0,
			'hnc_maintenance_mode'                      => 0,
			'hnc_maintenance_message'                   => __(
				'Submissions are temporarily paused while we review a legal matter. Please check back soon.',
				'helpnagaland-core'
			),

			/* Rate limits */
			'hnc_rate_limit_per_device_24h'             => 5,
			'hnc_rate_limit_per_ip_hour'                => 20,
			'hnc_min_submit_seconds'                    => 8,

			/* Photo and retention windows */
			'hnc_photo_retention_days'                  => 30,
			'hnc_alcohol_archive_months'                => 12,
			'hnc_alcohol_rejected_purge_days'           => 7,
			'hnc_drug_archive_months'                   => 24,
			'hnc_drug_rejected_purge_hours'             => 24,
			'hnc_phone_retention_days_after_resolved'   => 90,
			'hnc_phone_retention_days_max'              => 180,
			'hnc_audit_retention_years'                 => 5,
			'hnc_device_retention_months'               => 12,
			'hnc_ip_retention_days'                     => 7,

			/* Security salts and keys */
			'hnc_ip_daily_salt'                         => wp_generate_password( 32, true, true ),
			'hnc_ip_salt_rotated_at'                    => current_time( 'mysql' ),
			'hnc_device_hash_salt'                      => wp_generate_password( 32, true, true ),

			/* Geography */
			'hnc_snap_grid_meters'                      => 50,
			'hnc_gps_tolerance_meters'                  => 100,
			'hnc_photo_freshness_max_seconds'           => 180,
			'hnc_nagaland_bounds'                       => wp_json_encode(
				array(
					'lat_min' => 25.20,
					'lat_max' => 27.05,
					'lng_min' => 93.30,
					'lng_max' => 95.85,
				)
			),
			'hnc_districts'                             => wp_json_encode( self::default_districts() ),

			/* Categories */
			'hnc_alcohol_categories'                    => wp_json_encode( self::default_alcohol_categories() ),
			'hnc_drug_categories'                       => wp_json_encode( self::default_drug_categories() ),
			'hnc_time_patterns'                         => wp_json_encode( self::default_time_patterns() ),

			/* Vault */
			'hnc_vault_session_minutes'                 => 15,
			'hnc_vault_passphrase_hash'                 => '',
			'hnc_vault_passphrase_set_at'               => '',

			/* Transparency */
			'hnc_transparency_auto_publish'             => 1,
			'hnc_transparency_publish_day_of_month'     => 5,

			/* Destructive action safety */
			'hnc_allow_data_deletion_on_uninstall'      => 0,

			/* Counters for quick dashboard stats (denormalized, refreshed on each write) */
			'hnc_stats_alcohol_pending'                 => 0,
			'hnc_stats_drug_pending'                    => 0,
			'hnc_stats_alcohol_approved_total'          => 0,
			'hnc_stats_drug_approved_total'             => 0,
		);

		foreach ( $defaults as $key => $value ) {
			// add_option returns false if the option already exists; we don't care.
			add_option( $key, $value );
		}
	}


	/* ============================================================
	 * DEFAULT CATEGORY LISTS
	 * ============================================================ */

	/**
	 * Default Nagaland districts (16 total as of the 2021 reorganization).
	 *
	 * @return string[]
	 */
	private static function default_districts() {
		return array(
			'Chümoukedima',
			'Dimapur',
			'Kiphire',
			'Kohima',
			'Longleng',
			'Mokokchung',
			'Mon',
			'Niuland',
			'Noklak',
			'Peren',
			'Phek',
			'Shamator',
			'Tseminyü',
			'Tuensang',
			'Wokha',
			'Zunheboto',
		);
	}

	/**
	 * Default alcohol report categories.
	 * Keys are stable category codes stored in the database. Labels are
	 * translatable strings.
	 *
	 * @return array<string,string>
	 */
	private static function default_alcohol_categories() {
		return array(
			'liquor_shop'   => __( 'Liquor shop', 'helpnagaland-core' ),
			'home_brewery'  => __( 'Home brewery', 'helpnagaland-core' ),
			'street_corner' => __( 'Street corner sale', 'helpnagaland-core' ),
			'bar_operating' => __( 'Bar operating during prohibition', 'helpnagaland-core' ),
			'other'         => __( 'Other', 'helpnagaland-core' ),
		);
	}

	/**
	 * Default drug report categories.
	 *
	 * @return array<string,string>
	 */
	private static function default_drug_categories() {
		return array(
			'street_sale'        => __( 'Street sale', 'helpnagaland-core' ),
			'home_sale'          => __( 'Home sale', 'helpnagaland-core' ),
			'distribution_point' => __( 'Distribution point', 'helpnagaland-core' ),
			'user_gathering'     => __( 'User gathering point', 'helpnagaland-core' ),
			'other'              => __( 'Other', 'helpnagaland-core' ),
		);
	}

	/**
	 * Default time pattern options used by both pipelines.
	 *
	 * @return array<string,string>
	 */
	private static function default_time_patterns() {
		return array(
			'morning'   => __( 'Morning', 'helpnagaland-core' ),
			'afternoon' => __( 'Afternoon', 'helpnagaland-core' ),
			'evening'   => __( 'Evening', 'helpnagaland-core' ),
			'night'     => __( 'Night', 'helpnagaland-core' ),
			'any_time'  => __( 'Any time', 'helpnagaland-core' ),
		);
	}


	/* ============================================================
	 * PROTECTED UPLOADS DIRECTORY
	 * ============================================================
	 *
	 * Creates wp-content/uploads/hnc-private/ and drops an .htaccess file
	 * that denies all direct web access. Photos and media live here. Access
	 * is granted only through authenticated REST endpoints that stream the
	 * file content with a permission check.
	 *
	 * This function is called on activation AND on plugins_loaded to handle
	 * the case where another plugin deleted the directory or the .htaccess
	 * file. In Phase 1 it runs only on activation; later phases may add
	 * scheduled verification.
	 */
	private static function create_protected_uploads_dir() {
		$upload_dir = wp_upload_dir();
		if ( ! empty( $upload_dir['error'] ) ) {
			// wp_upload_dir failed. Let WP handle the notice. No directory to create.
			return;
		}

		$base = trailingslashit( $upload_dir['basedir'] ) . HNC_UPLOADS_DIR;

		// Main directory.
		if ( ! is_dir( $base ) ) {
			wp_mkdir_p( $base );
		}

		// .htaccess denying all web access.
		$htaccess_path = trailingslashit( $base ) . '.htaccess';
		if ( ! file_exists( $htaccess_path ) ) {
			$htaccess  = "# Help Nagaland Core\n";
			$htaccess .= "# Protected uploads directory. Files here are served only\n";
			$htaccess .= "# via authenticated REST endpoints. Direct web access is denied.\n";
			$htaccess .= "\n";
			$htaccess .= "# Apache 2.2 and earlier\n";
			$htaccess .= "<IfModule !mod_authz_core.c>\n";
			$htaccess .= "    Order Allow,Deny\n";
			$htaccess .= "    Deny from all\n";
			$htaccess .= "</IfModule>\n";
			$htaccess .= "\n";
			$htaccess .= "# Apache 2.4 and later\n";
			$htaccess .= "<IfModule mod_authz_core.c>\n";
			$htaccess .= "    Require all denied\n";
			$htaccess .= "</IfModule>\n";
			@file_put_contents( $htaccess_path, $htaccess ); // phpcs:ignore
		}

		// web.config for IIS hosts.
		$webconfig_path = trailingslashit( $base ) . 'web.config';
		if ( ! file_exists( $webconfig_path ) ) {
			$webconfig  = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
			$webconfig .= "<configuration>\n";
			$webconfig .= "    <system.webServer>\n";
			$webconfig .= "        <authorization>\n";
			$webconfig .= "            <deny users=\"*\" />\n";
			$webconfig .= "        </authorization>\n";
			$webconfig .= "    </system.webServer>\n";
			$webconfig .= "</configuration>\n";
			@file_put_contents( $webconfig_path, $webconfig ); // phpcs:ignore
		}

		// index.html to prevent directory listing on misconfigured servers.
		$index_path = trailingslashit( $base ) . 'index.html';
		if ( ! file_exists( $index_path ) ) {
			@file_put_contents( $index_path, '<!-- Silence is golden. -->' ); // phpcs:ignore
		}

		// Subdirectories for each pipeline.
		$subdirs = array( 'alcohol', 'drug' );
		foreach ( $subdirs as $sub ) {
			$sub_path = trailingslashit( $base ) . $sub;
			if ( ! is_dir( $sub_path ) ) {
				wp_mkdir_p( $sub_path );
			}
			$sub_index = trailingslashit( $sub_path ) . 'index.html';
			if ( ! file_exists( $sub_index ) ) {
				@file_put_contents( $sub_index, '<!-- Silence is golden. -->' ); // phpcs:ignore
			}
		}
	}
}
