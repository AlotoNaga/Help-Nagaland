# Changelog

All notable changes to Help Nagaland Core are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.6] — Alcohol queue was invisible

### Fixed

- **Alcohol moderation queue rendered nothing even when reports
  existed.** `HNC_Alcohol_Moderation::get_queue()` was returning its
  result list under the key `items`, while `admin.js` (and the
  matching Drug queue) read it from `rows`. The count label above
  the queue correctly showed "1 report" because it read `total`,
  but the list itself was empty, so the admin saw "No reports match
  these filters" on a queue that was not in fact empty.

  One-line server fix: the list key is now `rows`, matching the
  drug pipeline convention. No migration needed.

## [1.1.5] — Phone Vault UX polish

### Added

- **`HNC_Phone_Vault::counts()`** — returns live row counts broken
  down by pipeline (`total`, `alcohol`, `drug`), excluding
  soft-deleted rows so the numbers reflect what a moderator would
  actually see.
- **`GET /hnc/v1/admin/vault/counts`** REST endpoint wrapping
  `counts()`. Gated on `hnc_manage_vault`, rate-limited 60/min.
- **Admin UI wiring:** the three Phone Vault stat cards ("Active
  entries", "Alcohol", "Drug") now populate from the new endpoint
  instead of staying stuck on `—`. The "Refresh" button refreshes
  both the status indicator and the counts.

### Fixed

- **Client-vs-server passphrase floor mismatch.** The admin page
  said *"New passphrase (12+ characters)"* and the JS check allowed
  12, but the REST endpoint has required 16 since v1.1.0. Anyone
  who typed 12–15 characters passed client validation and then got
  rejected by the server with a different message. Both the label
  and the JS check now read the floor from
  `hnc_vault_min_passphrase_length` (default 16, floor 12) via a
  `data-hnc-min-passphrase` attribute, so one number is shown in
  both places and both match the server.
- **"15 minutes idle" was hardcoded** in the vault page subtitle
  even though `hnc_vault_session_minutes` is filterable. The
  subtitle now reads the option value so a site owner who tunes
  the TTL sees the real number on the page.

## [1.1.4] — Moderator can see the photo / video

### Added

- **`GET /hnc/v1/admin/alcohol/photo/{id}`** — streams the live
  photo for an alcohol report to moderators who hold the
  `hnc_moderate_alcohol` capability. Uses the existing
  `HNC_Media::stream()` helper. Rate-limited (120/min per user) and
  audit-logged with the new `HNC_Logger::ACTION_MEDIA_VIEW`.
- **`GET /hnc/v1/admin/drug/media/{id}`** — same, for the optional
  photo or video attached to a drug report. Gated on
  `hnc_moderate_drug`. The Content-Type from the file is preserved
  so the client can tell whether to render `<img>` or `<video>`.
- **`HNC_Logger::ACTION_MEDIA_VIEW` constant** so every moderator
  look at submitted media is traceable.
- **Admin-modal rendering**: the alcohol queue and drug queue detail
  modals now include a "Live photo" / "Reporter media" section that
  loads the binary via `fetch()` with `X-WP-Nonce`, wraps the
  response in a blob URL, and renders it into an `<img>` or
  `<video>` element. The blob URL is revoked on modal close so
  Safari doesn't accumulate blob references during long moderation
  sessions.
- **Styling** `.hnc-media-frame`, `.hnc-media-preview`,
  `.hnc-media-missing` added to `admin.css`. Previews are capped at
  `max-height: 60vh` so the action buttons remain on screen even on
  small displays.

### Why

Before this release, the detail modals showed metadata, description
and merge controls but no photo or video. Moderators had no way to
verify a liquor-shop pin looked real or spot identifying detail
(faces, plates, names) that should force a rejection. Same
blind-spot on drug reports that carried optional media. This closes
that gap.

### Security / privacy

- Both endpoints refuse without the matching moderation capability
  (no fallthrough to admin role). Pre-existing `HNC_Api_Nonce::cap`
  wrapper is reused so the nonce + capability check is identical to
  every other admin endpoint.
- 404 is returned both for "no row" and "no media attached" and
  "media already purged under retention" — we never leak which of
  those three it was, so enumeration is pointless.
- Every view is written to the audit log with moderator ID,
  report ID, and kind (photo / video). Retention cron rotates the
  log yearly.
- Blob URLs are revoked on modal close.

## [1.1.3] — Alcohol form UX fixes

### Fixed

- **Camera stage stacked three elements and grew to ~3× viewport
  height on iOS Safari.** A CSS rule on `.hnc-camera-video`,
  `.hnc-camera-canvas` and `.hnc-camera-preview` declared
  `display: block` at the same specificity as the user-agent
  `[hidden] { display: none }` rule, which let all three render at
  once. A higher-specificity
  `.hnc-camera-stage [hidden] { display: none !important }` now
  forces the attribute to win.
- **After stopping the stream, iOS Safari kept rendering the last
  video frame.** The `stopStream()` helper now takes the `<video>`
  element and nulls its `srcObject` so the frozen frame is released.
- **After a successful submit the form looked like nothing had
  happened.** The success handler now:
  - Fully resets the camera widget (stops stream, clears preview,
    hides Retake/Capture, shows Open camera).
  - Resets the GPS status line and clears lat/lng/accuracy inputs.
  - Re-disables the submit button until a fresh report is composed.
  - Scrolls the tracking-code banner into view so the reporter can
    copy it without searching for it.

### Changed

- **Alcohol form description is now optional.** The server already
  treated it as optional (only `lat, lng, category, time_pattern`
  are server-required), but the HTML attribute and the client-side
  enablement guard were forcing it. Label now reads "Short
  description (optional)" and the placeholder/hint text match. Drug
  form's "Area description" and "Pattern" remain required — those
  are the entire content of a drug report and moderators need them.

### Technical

- New `state.resetCamera()` and `state.resetGps()` helpers exposed
  by `wireCamera()` and `wireGps()` respectively. The submit
  handler and the Retake button both go through these helpers so
  there is a single canonical reset path.
- `URL.revokeObjectURL()` is now called on the previous preview
  URL before replacing it, to avoid leaking object URLs on
  long sessions.

## [1.1.2] — Flip-camera option on alcohol form

### Added

- **"Flip camera" button** on the live-camera widget in the alcohol
  submission form. The platform still defaults to the back camera
  (`facingMode: 'environment'`) because most reporters photograph a
  location, not themselves. The new button lets a reporter switch to
  the front camera and back without closing and reopening the
  widget.
- The button is hidden automatically on devices with only one
  camera, detected via `navigator.mediaDevices.enumerateDevices()`.
- The state is preserved across captures: the user can flip, take a
  photo, click "Retake", open the camera again, and still have the
  flip option available.
- New i18n string: `flip_camera`.

### Technical

- `wireCamera()` in `alcohol-form.js` was refactored so stream open
  and stream re-open go through a single `openStream()` function.
  Flipping calls `stopStream()` first so the previous track releases
  cleanly on mobile Safari (which is strict about track lifecycle).

## [1.1.1] — Nagaland district detection upgrade

### Added

- **Polygon-based district detection.** `HNC_Geo::detect_district()` now
  tries point-in-polygon against a user-supplied
  `lib/nagaland-districts.geojson` file first, and only falls back to
  the nearest-centroid classifier if the polygon file is absent,
  malformed, or does not contain the point. The loader accepts both
  `Polygon` and `MultiPolygon` geometries, handles holes correctly,
  and reads the district name from any of `district`, `DISTRICT`,
  `shapeName` (geoBoundaries), `NAME_2` (GADM), `dtname`, `Dist_Name`.
  Parsed polygons are cached in a request-scoped static so multiple
  district lookups on one page pay the parse cost once.
- **New public method `HNC_Geo::detect_district_by_polygon( $lat, $lng )`**
  for callers that want to test whether polygon-based detection hit,
  without the centroid fallback.
- **New public method `HNC_Geo::detect_district_by_centroid( $lat, $lng )`**
  for callers that want centroid-only detection.
- **New public method `HNC_Geo::load_district_polygons()`** returning
  the normalised in-memory polygon list. Useful for WP-CLI diagnostics.
- **Filter `hnc_district_polygons_path`** to override the GeoJSON file
  location (e.g. to host it in a separate plugin or CDN-backed cache
  directory).
- **Filter `hnc_district_centroids`** so site owners can override
  specific centroid values without patching the plugin.
- **File-size guardrail on the polygon loader.** Files larger than
  10 MB are rejected to prevent OOM on pathological inputs.
- **`lib/nagaland-districts.README.md`** explaining the expected format,
  recommended sources (geoBoundaries CC-BY 4.0, DataMeet, GADM), their
  licensing terms, the validation checklist from spec section 16, and
  how to enable or disable polygon detection.
- **`lib/nagaland-districts.LICENSE.txt`** placeholder for operators to
  replace with their source's attribution text when they supply a real
  GeoJSON file.

### Changed

- **Refreshed the 16 district centroids** against the 2026
  `indian-states-cities-geolocation` reference data (MIT). Several
  centroids in v1.0.0 were off by 20+ km (Noklak, Shamator, Tseminyü,
  Chümoukedima), causing misassignment of submissions near those
  districts. Remaining centroids were already within ~5 km and
  received minor refinements.
- **`HNC_Geo::load_bounds()` falls back to built-in defaults** when
  the `hnc_nagaland_bounds` option is missing or malformed. Previously
  an admin who blanked the option would silently disable district
  detection across the whole plugin. A new public helper
  `HNC_Geo::default_bounds()` exposes the hardcoded defaults for
  diagnostic use.

### Notes for site owners

The centroid classifier alone is accurate enough to anchor a civic
platform's district attribution. The polygon path is strictly optional
and strictly additive — turning it on never makes detection worse, and
turning it off (by deleting the file) is safe at any time. See
`lib/nagaland-districts.README.md` for the step-by-step.

The spec's pre-launch checklist still requires validating district
detection against 20 sample points across all 16 districts regardless
of which classifier is active.

## [1.1.0] — Production hardening

Response to the production-readiness audit across all ten phases.

### Security

- **Self-hosted Leaflet.** Leaflet 1.9.4 and Leaflet.markercluster 1.5.3 are now shipped under `/lib/leaflet/` and `/lib/leaflet-markercluster/`. The previous build loaded these from `unpkg.com`, which is a supply-chain risk on pages that also request live GPS and live camera. The filters `hnc_public_leaflet_js_url`, `hnc_public_leaflet_css_url`, `hnc_public_leaflet_cluster_js_url`, and `_css_url` / `_css_default_url` remain available for admins who insist on a CDN.
- **Health endpoint is rate-limited.** `GET /hnc/v1/health` now runs through `HNC_Api_Ratelimit::public_ip('health', 120, 60)` so an anonymous caller cannot probe the kill-switch state indefinitely.
- **Rate-limit buckets are tier-namespaced.** `public_ip` / `admin_user` / partner / per-device buckets no longer share hash space; collisions across tiers are impossible. SHA-256 is used for the transient-name suffix in place of MD5.
- **Partner endpoints use a stricter tier.** `HNC_Api_Ratelimit::partner_user()` is a new method with a 30-req/min default (vs 120 for admin). All partner REST write endpoints (`acknowledge`, `mark_acted`, `mark_closed`) now rate-limit, not just the list endpoint.
- **Admin REST queue endpoints declare argument schemas.** `/admin/alcohol/queue` and `/admin/drug/queue` now validate `status` against an enum, `page`/`per_page` against integer ranges, and sanitize `district` / `category` / `sort` with matching callbacks.
- **X-Forwarded-For support is opt-in.** `HNC_Api_Ratelimit::client_ip()` now reads `X-Forwarded-For` when an admin filters `hnc_trust_forwarded_for` to true. Off by default because trusting that header without a real proxy in front would let clients spoof IPs.
- **Vault passphrase floor raised to 16.** `POST /vault/set-passphrase` now refuses passphrases shorter than 16 characters. Site owners can override via the `hnc_vault_min_passphrase_length` filter but cannot drop below 12.
- **PBKDF2 iterations bumped to 310,000** (OWASP 2023 recommendation for SHA-256) for new vaults. Existing vaults record their iteration count in `hnc_vault_meta.pbkdf2_iter` so upgrades do not break decryption of prior records. `PBKDF2_ITERATIONS_LEGACY` = 200000 is used for vaults that predate this field.
- **Admin modal body is cleared safely.** `admin.js`'s `ui.openModal()` now empties the modal body DOM before inserting new content, and a new `ui.openModalNode()` alternative accepts a trusted DOM Node for cases where raw server data would flow through.
- **Drug-submission rejection log forwards IP/UA context** the way alcohol-submit already does, so analysts can spot coordinated abuse across pipelines.
- **Alcohol approve re-snaps coordinates** to the 50-metre grid before publishing. Defense in depth — submit-time snap was already correct; approve-time snap handles the case where a row's coordinates were ever touched outside the submit flow.
- **Merge-count audit log records the canonical post-UPDATE value.** The pre-UPDATE read was stale under concurrent merges; the atomic `report_count = report_count + 1` UPDATE itself was already correct (InnoDB row-lock), but the log number had a drift.
- **CSV injection neutralised** in `HNC_Transparency_Export`. Every cell value that could start with `=`, `+`, `-`, `@`, tab, or CR is prefixed with a single quote before writing. Filename is sanitised to `[A-Za-z0-9._-]+`. OWASP / CWE-1236.

### Privacy

- **Fingerprint salt moved to `sessionStorage`.** The per-client salt used to de-duplicate submissions within a browser session is no longer persisted in `localStorage` — it resets on tab/browser close. Upgraded installs clean up the legacy `localStorage` key on first load.
- **Phone number sanitiser enforces the 6–9 mobile prefix for Indian numbers.** 10-digit and `91`-prefixed 12-digit inputs are now validated to start with a real mobile prefix (6, 7, 8 or 9). Garbage inputs like `0123456789` that would previously have been accepted as `+910123456789` are rejected. Trunk-prefix `0` on 11-digit inputs is also handled.

### Correctness

- **Transparency snapshot undercount fixed.** The `alcohol_approved` and `drug_approved` counts previously required `moderated_at IS NOT NULL`, which silently dropped pins auto-approved by the merge flow. R08 says numbers must not be edited after publish — we should not be publishing wrong numbers either. The `moderated_at` requirement is removed; the status filter alone is sufficient.
- **Drug rejected purge window is clamped to 1–720 hours** to prevent admin-side typo bugs where a large value stretches retention beyond 30 days.
- **Vault orphan cleanup loops until drained.** The old `LIMIT 500` with no continuation meant a backlog above 1000 orphans was never reduced. The new sweep iterates in 500-row batches up to the `hnc_vault_orphan_cap_per_run` cap (default 5000). JOINs now use `$wpdb->prepare` with the report type as a bound parameter.
- **Vault audit action `vault_store` is a real constant** (`HNC_Logger::ACTION_VAULT_STORE`). The previous ternary `ACTION_VAULT_UNLOCK === null ? 'vault_store' : 'vault_store'` was a copy-paste tautology.
- **IST cron math documented.** The `HNC_Cron::next_ist_run()` algorithm was already correct but relied on an unobvious "pseudo-timestamp in IST frame" trick. Added an explanatory comment so future maintainers don't attempt a "fix" that actually breaks it.

### Accessibility

- **Public form result containers announce updates** via `role="status"` + `aria-live="polite"` + `aria-atomic="true"` on the alcohol, drug, and status-check shortcodes. Screen readers now hear errors and success messages without manual focus management.
- **Leftover `console.warn`** in admin.js removed.

### New configuration surface

- Filter `hnc_trust_forwarded_for` (default false) — read client IP from `X-Forwarded-For` when behind a trusted proxy.
- Filter `hnc_vault_min_passphrase_length` (default 16) — lower bound on vault passphrase length.
- Filter `hnc_vault_pbkdf2_iterations` (default 310000) — iteration count for new vaults.
- Filter `hnc_vault_orphan_cap_per_run` (default 5000) — maximum orphan rows processed per cron run.
- Option `hnc_upload_max_bytes` (default 15728640) — maximum upload size for drug-form media; exposed to JS for client-side pre-upload rejection.
- Option `hnc_min_gps_accuracy_m` (default 60) — maximum GPS accuracy radius accepted by the alcohol form.
- i18n strings `file_too_large` and `gps_accuracy_low`.

### Bundled

- `lib/leaflet/leaflet.js`, `leaflet.css`, `images/*.png` — Leaflet 1.9.4 (BSD-2).
- `lib/leaflet-markercluster/leaflet.markercluster.js`, `MarkerCluster.css`, `MarkerCluster.Default.css` — Leaflet.markercluster 1.5.3 (MIT).
- LICENSE file in each lib directory.

## [1.0.0] - Phase 2 Utilities

### Added
- `HNC_Logger` class with immutable audit logging to `hnc_audit_log`. Exposes 11 event type constants and 29 action constants covering alcohol, drug, phone vault, partner, transparency, settings, role, killswitch, system, security, and auth event streams. Never throws on failure. Hashes all IP addresses with the daily rotating salt. Redacts sensitive option keys in setting-update logs. Provides `query()` and `count()` with filters for the admin audit screen.
- `HNC_Sanitizer` class with per-field sanitizers: `alcohol_description` (300 chars), `drug_pattern` (500 chars), `area_description` (200 chars, strips house numbers), `vehicle_info` (masks Indian license plates), `rejection_reason`, `admin_note` (preserves paragraph breaks), `phone_number` (E.164 with India default), `category_key` (pipeline-aware), `district`, `time_pattern`, `submission_mode`. Main `sanitize_free_text` pipeline strips HTML, control characters, emails, phone numbers, and common honorifics (Mr./Mrs./Dr./Shri/Smt./Pastor/Rev./etc.) plus name patterns.
- `HNC_Codes` class for tracking code generation. Format XXXX-XXXX. 30-character alphabet excludes confusing characters (0, O, 1, I, L, Q). Uses cryptographically secure `random_int` with `wp_rand`/`mt_rand` fallback. `lookup()` checks both alcohol and drug tables. Collision retry up to 5 attempts.
- `HNC_Encryption` class for the phone vault. AES-256-GCM via OpenSSL with 12-byte nonces and 16-byte auth tags. Passphrase stored as Argon2id hash (bcrypt fallback) in `hnc_vault_meta` option. Symmetric key derived via PBKDF2-SHA256 at 200,000 iterations using a separate random salt, held only in the PHP session for up to 15 configurable minutes. Hardened session cookie with `samesite=Strict`, `httponly`, secure when SSL. Session key zeroed on lock. Encryption key is never persisted to disk or database. Forgetting the passphrase permanently locks the vault, by design.
- `HNC_Geo` class with haversine distance calculation, Nagaland bounding-box check, district detection by nearest centroid (16 districts with approximate centroids), deterministic 50-meter grid snap, 100-meter GPS-to-pin tolerance check, and alcohol merge candidate lookup with bounding-box prefilter.
- `HNC_Device` class with two-stage device fingerprint hashing (client SHA-256 then server re-hash with secret salt), 24-hour rolling submission count, per-device rate limiting from `hnc_rate_limit_per_device_24h` option (default 5), per-IP hourly rate limiting via transients (default 20/hour), flag/unflag operations, and stale-row purge that preserves flagged devices.
- `HNC_Media` class handling uploaded photos and videos: size check (15 MiB max), real MIME detection via `finfo`, EXIF freshness check (rejects alcohol photos older than 180 seconds), EXIF stripping and re-encoding via Imagick or GD fallback, UUID v4 rename, chmod 0600, SHA-256 hash, path-traversal-safe storage under `hnc-private/alcohol/` and `hnc-private/drug/`. Separate entry points for alcohol (images only, freshness required) and drug (images + video, no freshness).
- `HNC_Cron` class registering 12 scheduled hooks at fixed IST times (00:05 IP salt rotation, 02:00 retention heartbeat, 02:15-03:30 staggered pipeline cleanups, 09:00 monthly transparency publish, yearly audit archive). Adds custom `hnc_monthly` (30 day) and `hnc_yearly` (365 day) schedules. Default workers for IP salt rotation, device cleanup, and retention heartbeat are wired in; pipeline-specific workers land in Phase 3-5.
- `HNC_Killswitch` class with state queries, activate/deactivate guarded by the `hnc_operate_killswitch` capability, REST response guard returning 503 with `Retry-After: 3600`, admin banner flag, and `hnc_killswitch_activated` / `hnc_killswitch_deactivated` WordPress actions for CDN and cache integrations. Audit log entries on every state change.

### Validated
- All nine Phase 2 files pass `php -l` syntax check.
- Full integration smoke test confirms: autoloader picks up all Phase 2 classes, sanitizer strips names/phones/emails/plates from adversarial input, generated tracking codes contain zero confusing characters across 50 samples, district detection correctly identifies Dimapur, Kohima, and Mon from their real GPS coordinates, grid snap is deterministic across nearby coordinates, GPS-to-pin tolerance correctly accepts within 100m and rejects beyond, passphrase setter refuses strings under 12 characters and refuses to overwrite without force flag, kill switch guard returns 503 with proper Retry-After header.

## [1.0.0] - Phase 1 Foundation

### Added
- Main plugin file `helpnagaland-core.php` with requirements check, PSR-style autoloader, activation and deactivation hooks, and plugins_loaded bootstrap.
- `HNC_Schema` class with all seven database table definitions: `hnc_alcohol_reports`, `hnc_drug_reports`, `hnc_phone_vault`, `hnc_audit_log`, `hnc_device_fingerprints`, `hnc_transparency_snapshots`, `hnc_partners`.
- `HNC_Activator` class that creates database tables, seeds default options, registers custom roles, creates the protected uploads directory with `.htaccess`, `web.config`, and `index.html` guards, and stamps activation timestamp.
- `HNC_Deactivator` class that unschedules all cron events and flushes rewrite rules without touching any data.
- `HNC_Roles` class defining twelve custom capabilities and two custom roles (`hnc_moderator`, `hnc_partner`) with idempotent role creation and self-healing capability assignment.
- `uninstall.php` with opt-in safety gate (`hnc_allow_data_deletion_on_uninstall` option) that performs full data destruction only when explicitly authorized.

### Infrastructure
- PHP requirements: 7.4+ with `openssl`, `json`, `mbstring`, plus either `gd` or `imagick`.
- WordPress requirements: 6.0+.
- All seven HNC tables use `utf8mb4` charset with the collation returned by `$wpdb->get_charset_collate()`.
- Autoloader maps `HNC_Alcohol_*`, `HNC_Drug_*`, `HNC_Phone_*`, `HNC_Vault_*`, `HNC_Transparency_*`, `HNC_Partner_*`, `HNC_Api_*`, `HNC_Admin_*`, `HNC_Public_*` class prefixes to their respective subdirectories.

### Not yet in this phase
- Submission handlers for both pipelines.
- REST API surface.
- Admin UI screens.
- Public frontend shortcodes.
- Moderation queues.
- Phone vault encryption helpers.
- Retention cron jobs.
- Transparency publication.
- Partner dashboard.

These are scheduled across Phases 2 through 10 per the project specification.
