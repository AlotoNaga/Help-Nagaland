# Nagaland district polygons

This directory is where the plugin looks for district polygon data used
by `HNC_Geo::detect_district()`.

## Behaviour without this file

The plugin classifies submissions using a nearest-centroid match against
the 16 Nagaland districts (see `HNC_Geo::district_centroids()`). This
works for most interior points but can misassign points near district
boundaries, especially in the irregular northeastern districts.

## Enabling polygon-based detection

Drop a GeoJSON file at:

    helpnagaland-core/lib/nagaland-districts.geojson

The plugin will automatically pick it up on the next request, perform
point-in-polygon matching, and fall back to the centroid classifier
only when a point does not land in any polygon.

No code change is required to turn this on. There is also no settings
page toggle — the presence of the file is the switch.

## Required file format

A standard GeoJSON `FeatureCollection` with one `Feature` per district.

```json
{
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "properties": { "district": "Dimapur" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [ [ [93.0, 25.9], [93.9, 25.9], [93.9, 26.0], [93.0, 26.0], [93.0, 25.9] ] ]
      }
    }
  ]
}
```

Accepted geometry types:

- `Polygon`
- `MultiPolygon`

Accepted property keys for the district name (the first one present in
each feature's `properties` object is used):

- `district`
- `DISTRICT`
- `shapeName` (used by geoBoundaries)
- `NAME_2` (used by GADM)
- `dtname`
- `Dist_Name`

All 16 current districts should be present, using the names listed in
`HNC_Geo::district_centroids()`: Chümoukedima, Dimapur, Kiphire,
Kohima, Longleng, Mokokchung, Mon, Niuland, Noklak, Peren, Phek,
Shamator, Tseminyü, Tuensang, Wokha, Zunheboto.

## File-size guardrails

- The loader rejects files larger than 10 MB. If your source file is
  bigger, run it through a simplifier such as `mapshaper` with a
  reasonable tolerance (`-simplify dp 15% keep-shapes`) before
  dropping it in. The plugin does not need sub-metre polygon fidelity
  for district assignment.
- The loaded structure is cached in a PHP static for the duration of
  each request, so the parse cost is paid once per page load.

## Recommended sources (with licensing notes)

All three of these produce admin-level polygons covering the current
16 Nagaland districts. Pick the one whose licence you are comfortable
attributing.

### geoBoundaries (recommended)
- URL: https://www.geoboundaries.org/
- Product: `gbOpen`, Country `IND`, ADM2 level
- Licence: **CC-BY 4.0**. Ship with attribution.
- To filter just Nagaland features: use `mapshaper` or `ogr2ogr` on the
  India ADM2 file, selecting features whose `shapeName` (ADM1 parent)
  or `shapeGroup` matches `Nagaland`.

### DataMeet India maps
- URL: https://github.com/datameet/maps
- Licence: **ODbL-style community licence**. Attribution required.
- Caveat: the Census 2011 dataset in this repo predates the 2021/2022
  creation of Tseminyü, Niuland, Chümoukedima, Noklak, and Shamator —
  you will need to merge or split features yourself.

### GADM
- URL: https://gadm.org/download_country.html
- Product: India, Level 2, GeoJSON.
- Licence: free for academic / personal; **commercial redistribution
  requires permission** from GADM. Read the GADM licence page before
  shipping.

## Attribution

Whichever source you use, put the attribution line somewhere public on
the site (the footer `hnc-footer-disclaimer` is a good place) and drop
a `nagaland-districts.LICENSE.txt` alongside your GeoJSON containing
the source's licence text.

Example attribution line:

> District boundaries © geoBoundaries (CC-BY 4.0) — geoboundaries.org

## Validation checklist

Before calling the pipeline production-ready (see pre-launch checklist
item "District detection verified"):

1. Run `HNC_Geo::load_district_polygons()` in a WP-CLI shell and
   verify it returns 16 entries.
2. Pick one real known address per district (police station, DC
   office, etc.), look up its GPS, and call
   `HNC_Geo::detect_district( $lat, $lng )`. Verify the correct
   district name is returned. Repeat across all 16 districts for a
   minimum of 20 total sample points per the spec's checklist.
3. Pick 2–3 points on district boundaries. Confirm the result is
   defensible (i.e. doesn't flip between runs or contradict the
   source-of-truth cadastral map).

## Removing the file

Delete `nagaland-districts.geojson` and the plugin reverts to the
centroid classifier automatically on the next request.
