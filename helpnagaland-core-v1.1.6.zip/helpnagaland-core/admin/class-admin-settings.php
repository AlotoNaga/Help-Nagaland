<?php
/**
 * Admin Settings screen.
 *
 * Exposes the knobs that operations might actually want to change:
 * retention windows, rate limits, and the min-submit-seconds anti-bot
 * threshold. Does NOT expose vault passphrase (that is one-way) or
 * core schema-level settings.
 *
 * Uses WordPress's register_setting() system for persistence so this
 * page stays a plain HTML form rather than yet another fetch flow.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Admin_Settings
 */
final class HNC_Admin_Settings {


	/** Option group slug for register_setting. */
	const OPTION_GROUP = 'hnc_settings_group';


	/**
	 * Register settings on admin_init. Called by menu bootstrap.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
	}

	/**
	 * Register every editable option so WordPress's options.php form
	 * handler knows what to accept.
	 *
	 * @return void
	 */
	public static function register_settings() {
		$settings = self::settings_definition();
		foreach ( $settings as $opt => $meta ) {
			register_setting(
				self::OPTION_GROUP,
				$opt,
				array(
					'type'              => isset( $meta['type'] ) ? $meta['type'] : 'string',
					'sanitize_callback' => isset( $meta['sanitize'] ) ? $meta['sanitize'] : null,
					'show_in_rest'      => false,
					'default'           => isset( $meta['default'] ) ? $meta['default'] : '',
				)
			);
		}
	}

	/**
	 * Render the settings page.
	 *
	 * @return void
	 */
	public static function render() {
		if ( ! current_user_can( 'hnc_manage_settings' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'helpnagaland-core' ) );
		}

		$settings = self::settings_definition();
		?>
		<div class="wrap hnc-wrap" data-hnc-screen="settings">
			<h1 class="hnc-title"><?php esc_html_e( 'Settings', 'helpnagaland-core' ); ?></h1>

			<form method="post" action="<?php echo esc_url( admin_url( 'options.php' ) ); ?>" class="hnc-settings-form">
				<?php settings_fields( self::OPTION_GROUP ); ?>

				<?php foreach ( self::settings_sections() as $section ) : ?>
					<div class="hnc-card">
						<h2><?php echo esc_html( $section['title'] ); ?></h2>
						<?php if ( ! empty( $section['description'] ) ) : ?>
							<p class="hnc-help-text"><?php echo esc_html( $section['description'] ); ?></p>
						<?php endif; ?>
						<table class="form-table" role="presentation">
							<tbody>
								<?php foreach ( $section['options'] as $opt ) :
									if ( ! isset( $settings[ $opt ] ) ) {
										continue;
									}
									$meta    = $settings[ $opt ];
									$value   = get_option( $opt, $meta['default'] );
									$type    = isset( $meta['type'] ) ? $meta['type'] : 'string';
									$hint    = isset( $meta['hint'] ) ? $meta['hint'] : '';
									?>
									<tr>
										<th scope="row">
											<label for="<?php echo esc_attr( $opt ); ?>"><?php echo esc_html( $meta['label'] ); ?></label>
										</th>
										<td>
											<?php if ( 'integer' === $type ) : ?>
												<input type="number" id="<?php echo esc_attr( $opt ); ?>" name="<?php echo esc_attr( $opt ); ?>" value="<?php echo esc_attr( (string) $value ); ?>" class="small-text" />
											<?php else : ?>
												<input type="text" id="<?php echo esc_attr( $opt ); ?>" name="<?php echo esc_attr( $opt ); ?>" value="<?php echo esc_attr( (string) $value ); ?>" class="regular-text" />
											<?php endif; ?>
											<?php if ( '' !== $hint ) : ?>
												<p class="description"><?php echo esc_html( $hint ); ?></p>
											<?php endif; ?>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				<?php endforeach; ?>

				<?php submit_button( __( 'Save settings', 'helpnagaland-core' ) ); ?>
			</form>

			<div class="hnc-card hnc-card-info">
				<h2><?php esc_html_e( 'Read-only values', 'helpnagaland-core' ); ?></h2>
				<p class="hnc-help-text">
					<?php esc_html_e( 'These values are derived from the plugin constants and cannot be changed here.', 'helpnagaland-core' ); ?>
				</p>
				<ul>
					<li><strong><?php esc_html_e( 'Plugin version:', 'helpnagaland-core' ); ?></strong> <?php echo esc_html( HNC_VERSION ); ?></li>
					<li><strong><?php esc_html_e( 'DB version:', 'helpnagaland-core' ); ?></strong> <?php echo esc_html( HNC_DB_VERSION ); ?></li>
					<li><strong><?php esc_html_e( 'REST namespace:', 'helpnagaland-core' ); ?></strong> <code><?php echo esc_html( HNC_API_NAMESPACE ); ?></code></li>
					<li><strong><?php esc_html_e( 'Uploads directory:', 'helpnagaland-core' ); ?></strong> <code><?php echo esc_html( HNC_UPLOADS_DIR ); ?></code></li>
				</ul>
			</div>
		</div>
		<?php
	}


	/* ------------------------------------------------------------------
	 * SETTINGS DEFINITION
	 * ------------------------------------------------------------------ */

	/**
	 * Centralised definition of every editable option, keyed by option
	 * name. One source of truth used by register_settings and render.
	 *
	 * @return array
	 */
	private static function settings_definition() {
		return array(
			// Rate limits
			'hnc_rate_limit_per_device_24h' => array(
				'label'    => __( 'Submissions per device per 24h', 'helpnagaland-core' ),
				'type'     => 'integer',
				'default'  => 5,
				'sanitize' => 'absint',
				'hint'     => __( 'Max public submissions a single device may make in 24 hours.', 'helpnagaland-core' ),
			),
			'hnc_rate_limit_per_ip_hour'    => array(
				'label'    => __( 'Requests per IP per hour', 'helpnagaland-core' ),
				'type'     => 'integer',
				'default'  => 20,
				'sanitize' => 'absint',
				'hint'     => __( 'Max public requests from a single IP in one hour.', 'helpnagaland-core' ),
			),
			'hnc_min_submit_seconds'        => array(
				'label'    => __( 'Minimum seconds on form', 'helpnagaland-core' ),
				'type'     => 'integer',
				'default'  => 8,
				'sanitize' => 'absint',
				'hint'     => __( 'A submission faster than this is treated as a bot and rejected.', 'helpnagaland-core' ),
			),

			// Retention
			'hnc_photo_retention_days'       => array(
				'label'    => __( 'Alcohol photo retention (days)', 'helpnagaland-core' ),
				'type'     => 'integer',
				'default'  => 30,
				'sanitize' => 'absint',
				'hint'     => __( 'Alcohol photos are deleted from disk after this many days. The pin itself remains on the map.', 'helpnagaland-core' ),
			),
			'hnc_alcohol_archive_months'     => array(
				'label'    => __( 'Alcohol archive (months)', 'helpnagaland-core' ),
				'type'     => 'integer',
				'default'  => 12,
				'sanitize' => 'absint',
				'hint'     => __( 'Approved alcohol pins older than this are auto-archived.', 'helpnagaland-core' ),
			),
			'hnc_alcohol_rejected_purge_days'=> array(
				'label'    => __( 'Alcohol rejected purge (days)', 'helpnagaland-core' ),
				'type'     => 'integer',
				'default'  => 7,
				'sanitize' => 'absint',
				'hint'     => __( 'Rejected alcohol rows are deleted after this many days.', 'helpnagaland-core' ),
			),
			'hnc_drug_media_retention_days'  => array(
				'label'    => __( 'Drug media retention (days)', 'helpnagaland-core' ),
				'type'     => 'integer',
				'default'  => 90,
				'sanitize' => 'absint',
				'hint'     => __( 'Drug media is deleted after this many days.', 'helpnagaland-core' ),
			),
			'hnc_drug_archive_months'        => array(
				'label'    => __( 'Drug archive (months)', 'helpnagaland-core' ),
				'type'     => 'integer',
				'default'  => 24,
				'sanitize' => 'absint',
				'hint'     => __( 'Approved/resolved drug reports older than this are auto-archived.', 'helpnagaland-core' ),
			),
			'hnc_drug_rejected_purge_hours'  => array(
				'label'    => __( 'Drug rejected purge (hours)', 'helpnagaland-core' ),
				'type'     => 'integer',
				'default'  => 24,
				'sanitize' => 'absint',
				'hint'     => __( 'Rejected drug rows are deleted after this many hours (note: hours, not days).', 'helpnagaland-core' ),
			),
			'hnc_vault_session_minutes'      => array(
				'label'    => __( 'Vault auto-lock (minutes)', 'helpnagaland-core' ),
				'type'     => 'integer',
				'default'  => 15,
				'sanitize' => 'absint',
				'hint'     => __( 'The session-held vault key is zeroed after this many idle minutes.', 'helpnagaland-core' ),
			),
			'hnc_vault_purge_grace_hours'    => array(
				'label'    => __( 'Vault purge grace (hours)', 'helpnagaland-core' ),
				'type'     => 'integer',
				'default'  => 24,
				'sanitize' => 'absint',
				'hint'     => __( 'Soft-deleted vault entries are hard-deleted after this many hours.', 'helpnagaland-core' ),
			),

			// Geo
			'hnc_snap_grid_meters'           => array(
				'label'    => __( 'Grid snap (meters)', 'helpnagaland-core' ),
				'type'     => 'integer',
				'default'  => 50,
				'sanitize' => 'absint',
				'hint'     => __( 'Public pin coordinates are snapped to this grid.', 'helpnagaland-core' ),
			),
			'hnc_gps_tolerance_meters'       => array(
				'label'    => __( 'Auto-merge tolerance (meters)', 'helpnagaland-core' ),
				'type'     => 'integer',
				'default'  => 100,
				'sanitize' => 'absint',
				'hint'     => __( 'New alcohol pins within this distance of an existing same-category pin auto-merge.', 'helpnagaland-core' ),
			),
			'hnc_photo_freshness_max_seconds' => array(
				'label'    => __( 'Photo freshness window (seconds)', 'helpnagaland-core' ),
				'type'     => 'integer',
				'default'  => 180,
				'sanitize' => 'absint',
				'hint'     => __( 'Alcohol photos must have EXIF timestamp no older than this.', 'helpnagaland-core' ),
			),
		);
	}

	/**
	 * Grouping for display only. Each section has a title, description,
	 * and list of option keys that belong to it.
	 *
	 * @return array
	 */
	private static function settings_sections() {
		return array(
			array(
				'title'       => __( 'Anti-abuse', 'helpnagaland-core' ),
				'description' => __( 'Rate limits and bot-filter thresholds applied to public submissions.', 'helpnagaland-core' ),
				'options'     => array(
					'hnc_rate_limit_per_device_24h',
					'hnc_rate_limit_per_ip_hour',
					'hnc_min_submit_seconds',
				),
			),
			array(
				'title'       => __( 'Retention', 'helpnagaland-core' ),
				'description' => __( 'How long data lives before cron removes it.', 'helpnagaland-core' ),
				'options'     => array(
					'hnc_photo_retention_days',
					'hnc_alcohol_archive_months',
					'hnc_alcohol_rejected_purge_days',
					'hnc_drug_media_retention_days',
					'hnc_drug_archive_months',
					'hnc_drug_rejected_purge_hours',
					'hnc_vault_session_minutes',
					'hnc_vault_purge_grace_hours',
				),
			),
			array(
				'title'       => __( 'Geo and media', 'helpnagaland-core' ),
				'description' => __( 'Location and photo handling tolerances.', 'helpnagaland-core' ),
				'options'     => array(
					'hnc_snap_grid_meters',
					'hnc_gps_tolerance_meters',
					'hnc_photo_freshness_max_seconds',
				),
			),
		);
	}
}
