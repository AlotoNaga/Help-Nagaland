/**
 * Clean Nagaland admin JavaScript.
 *
 * Dispatches to per-screen init functions based on data-hnc-screen on
 * the page root. Each screen consumes the Phase 6 REST endpoints via
 * a tiny API helper.
 *
 * Vanilla JS, no frameworks, no build step. Hostinger file manager
 * friendly: drop in and go.
 */
(function () {
	'use strict';

	if (!window.HNC_CONFIG) {
		// Bail silently — admin.js is only loaded on plugin admin pages
		// where the PHP side provides HNC_CONFIG. Log nothing in
		// production to avoid cluttering the devtools console.
		return;
	}

	const CFG = window.HNC_CONFIG;
	const I18N = CFG.i18n || {};

	/* ================================================================
	 * API HELPER
	 * ================================================================ */

	const api = {
		async request(method, path, body) {
			const url = CFG.rest_url.replace(/\/$/, '') + '/' + path.replace(/^\//, '');
			const opts = {
				method: method,
				headers: {
					'X-WP-Nonce': CFG.nonce,
					'Accept': 'application/json',
				},
				credentials: 'same-origin',
			};
			if (body !== undefined && body !== null) {
				opts.headers['Content-Type'] = 'application/json';
				opts.body = JSON.stringify(body);
			}
			const res = await fetch(url, opts);
			let json = null;
			try { json = await res.json(); } catch (e) { json = { success: false, code: 'hnc_bad_response', message: 'Invalid server response.' }; }
			json._http = res.status;
			return json;
		},
		get(path) { return this.request('GET', path); },
		post(path, body) { return this.request('POST', path, body || {}); },
		del(path) { return this.request('DELETE', path); },

		/**
		 * Fetch a binary REST response as a Blob. Authenticated via
		 * the same X-WP-Nonce + same-origin cookie as the JSON
		 * endpoints, but does NOT try to parse JSON. Resolves to the
		 * Blob on 2xx; rejects with the HTTP status on anything else.
		 */
		async blob(path) {
			const url = CFG.rest_url.replace(/\/$/, '') + '/' + path.replace(/^\//, '');
			const res = await fetch(url, {
				method: 'GET',
				headers: { 'X-WP-Nonce': CFG.nonce, 'Accept': '*/*' },
				credentials: 'same-origin',
			});
			if (!res.ok) {
				const err = new Error('HTTP ' + res.status);
				err.status = res.status;
				throw err;
			}
			return await res.blob();
		},
	};

	/* ================================================================
	 * UI HELPERS
	 * ================================================================ */

	const ui = {
		toast(message, kind) {
			const existing = document.querySelector('.hnc-toast');
			if (existing) existing.remove();
			const el = document.createElement('div');
			el.className = 'hnc-toast hnc-toast-' + (kind || 'info');
			el.textContent = message;
			document.body.appendChild(el);
			setTimeout(() => el.classList.add('hnc-toast-show'), 10);
			setTimeout(() => {
				el.classList.remove('hnc-toast-show');
				setTimeout(() => el.remove(), 300);
			}, 4500);
		},

		confirm(message) {
			return window.confirm(message);
		},

		prompt(message, defaultValue) {
			return window.prompt(message, defaultValue || '');
		},

		/**
		 * Open the shared modal. `html` MUST be a trusted string — any
		 * user-controllable text inside MUST have been passed through
		 * ui.esc() before concatenation. Callers that need to insert
		 * raw server data should use ui.openModalNode() instead.
		 */
		openModal(html) {
			const m = document.querySelector('[data-hnc-modal]');
			if (!m) return;
			const body = m.querySelector('[data-hnc-modal-body]');
			// Clear first so stale DOM/listeners don't linger.
			while (body.firstChild) body.removeChild(body.firstChild);
			body.insertAdjacentHTML('afterbegin', html);
			m.hidden = false;
			document.body.style.overflow = 'hidden';
		},

		/**
		 * Safer variant: pass a DOM Node (typically built with
		 * document.createElement + textContent). No string parsing,
		 * so HTML entities in user content are never interpreted.
		 */
		openModalNode(node) {
			const m = document.querySelector('[data-hnc-modal]');
			if (!m || !node) return;
			const body = m.querySelector('[data-hnc-modal-body]');
			while (body.firstChild) body.removeChild(body.firstChild);
			body.appendChild(node);
			m.hidden = false;
			document.body.style.overflow = 'hidden';
		},

		closeModal() {
			const m = document.querySelector('[data-hnc-modal]');
			if (!m) return;
			m.hidden = true;
			const body = m.querySelector('[data-hnc-modal-body]');
			// Revoke any blob URLs attached to media-preview containers
			// before destroying the DOM, so Safari doesn't leak them on
			// long moderation sessions.
			if (body) {
				body.querySelectorAll('[data-hnc-blob-url]').forEach((el) => {
					const u = el.getAttribute('data-hnc-blob-url');
					if (u) { try { URL.revokeObjectURL(u); } catch (e) { /* noop */ } }
				});
				while (body.firstChild) body.removeChild(body.firstChild);
			}
			document.body.style.overflow = '';
		},

		errorToast(resp) {
			let msg = I18N.action_failed || 'Action failed.';
			if (resp && resp.message) msg = resp.message;
			if (resp && resp.code === 'hnc_rate_limit') msg = I18N.rate_limited || msg;
			else if (resp && resp.code === 'hnc_forbidden') msg = I18N.forbidden || msg;
			else if (resp && (resp.code === 'hnc_invalid_nonce' || resp.code === 'hnc_missing_nonce')) msg = I18N.expired_session || msg;
			this.toast(msg, 'error');
		},

		successToast(message) {
			this.toast(message || I18N.action_succeeded || 'Done.', 'success');
		},

		esc(s) {
			if (s === null || s === undefined) return '';
			return String(s).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch]);
		},

		fmtDate(iso) {
			if (!iso) return '—';
			const d = new Date(iso.replace(' ', 'T') + 'Z');
			if (isNaN(d.getTime())) return iso;
			return d.toLocaleString();
		},

		badge(status) {
			const map = {
				pending: ['Pending', 'hnc-badge-amber'],
				approved: ['Approved', 'hnc-badge-green'],
				rejected: ['Rejected', 'hnc-badge-red'],
				hold: ['On hold', 'hnc-badge-gray'],
				resolved: ['Resolved', 'hnc-badge-blue'],
				archived: ['Archived', 'hnc-badge-gray'],
			};
			const m = map[status] || [status, 'hnc-badge-gray'];
			return '<span class="hnc-badge ' + m[1] + '">' + this.esc(m[0]) + '</span>';
		},

		capCan(cap) {
			return Array.isArray(CFG.caps) && CFG.caps.indexOf(cap) !== -1;
		},

		/**
		 * Fetch a binary media stream (photo or video) from the REST
		 * API and render it into the given container. Uses a blob URL
		 * so the WP-Nonce header is attached on fetch rather than
		 * trying to fit auth into an <img src>. The blob URL is
		 * stashed on the node via data-hnc-blob-url and revoked when
		 * the modal is closed.
		 *
		 * @param {HTMLElement} container Where to render the media.
		 * @param {string}      path     REST path (e.g. 'admin/alcohol/photo/42').
		 */
		renderMediaPreview(container, path) {
			if (!container) return;
			container.textContent = 'Loading…';
			api.blob(path).then((blob) => {
				const url = URL.createObjectURL(blob);
				const isVideo = blob.type && blob.type.indexOf('video/') === 0;
				while (container.firstChild) container.removeChild(container.firstChild);
				const el = document.createElement(isVideo ? 'video' : 'img');
				el.className = 'hnc-media-preview';
				el.src = url;
				el.setAttribute('data-hnc-blob-url', url);
				if (isVideo) {
					el.controls = true;
					el.playsInline = true;
					el.preload = 'metadata';
				} else {
					el.alt = 'Moderation preview';
					el.decoding = 'async';
					el.loading = 'lazy';
				}
				container.appendChild(el);
			}).catch((err) => {
				let msg = 'Media not available.';
				if (err && err.status === 404) {
					msg = 'Media not available. It may have been purged by the retention cron.';
				} else if (err && err.status === 403) {
					msg = 'You do not have permission to view this media.';
				} else if (err && err.status === 429) {
					msg = 'Too many media requests. Wait a moment and retry.';
				}
				container.textContent = msg;
				container.classList.add('hnc-media-missing');
			});
		},
	};

	/* ================================================================
	 * MODAL WIRING
	 * ================================================================ */

	document.addEventListener('click', function (e) {
		if (e.target.matches('[data-hnc-modal-close]')) {
			ui.closeModal();
		}
	});
	document.addEventListener('keyup', function (e) {
		if (e.key === 'Escape') ui.closeModal();
	});

	/* ================================================================
	 * DASHBOARD SCREEN
	 * ================================================================ */

	async function initDashboard(root) {
		// Load counts in parallel.
		async function loadStat(statKey, fetcher) {
			const box = root.querySelector('[data-hnc-stat="' + statKey + '"] [data-hnc-value]');
			if (!box) return;
			try {
				const n = await fetcher();
				box.textContent = n;
			} catch (e) {
				box.textContent = '?';
			}
		}

		if (ui.capCan('hnc_moderate_alcohol')) {
			loadStat('alcohol-pending', async () => {
				const r = await api.get('admin/alcohol/queue?status=pending&per_page=1');
				return (r && r.success && r.data && r.data.total) ? r.data.total : 0;
			});
		}
		if (ui.capCan('hnc_moderate_drug')) {
			loadStat('drug-pending', async () => {
				const r = await api.get('admin/drug/queue?status=pending&per_page=1');
				return (r && r.success && r.data && r.data.total) ? r.data.total : 0;
			});
		}
		loadStat('alcohol-approved', async () => {
			const r = await api.get('alcohol/pins');
			return (r && r.success && typeof r.count !== 'undefined') ? r.count : 0;
		});

		// Health panel.
		const healthBox = root.querySelector('[data-hnc-health]');
		if (healthBox) {
			try {
				const h = await api.get('health');
				healthBox.innerHTML = '<div class="hnc-kv"><span>' + ui.esc('Status') + '</span><strong>' + ui.esc(h.status || '?') + '</strong></div>'
					+ '<div class="hnc-kv"><span>' + ui.esc('Version') + '</span><strong>' + ui.esc(h.version || '?') + '</strong></div>'
					+ '<div class="hnc-kv"><span>' + ui.esc('Time') + '</span><strong>' + ui.esc(h.time || '?') + '</strong></div>';
			} catch (e) {
				healthBox.innerHTML = '<div class="hnc-empty">Unavailable.</div>';
			}
		}

		// Killswitch control.
		const ks = root.querySelector('[data-hnc-killswitch]');
		if (ks) {
			await refreshKillswitch(ks);
			ks.querySelector('[data-hnc-action="killswitch-activate"]')?.addEventListener('click', async () => {
				if (!ui.confirm(I18N.confirm_killswitch_on)) return;
				const reason = ui.prompt('Internal reason (for the audit log):', '');
				if (reason === null) return;
				const publicMsg = ui.prompt('Public message visitors will see (keep it calm and brief):', 'We are paused for a short maintenance window.');
				if (publicMsg === null) return;
				const r = await api.post('admin/killswitch/activate', { internal_reason: reason, public_message: publicMsg });
				if (r.success) { ui.successToast('Killswitch activated.'); await refreshKillswitch(ks); }
				else ui.errorToast(r);
			});
			ks.querySelector('[data-hnc-action="killswitch-deactivate"]')?.addEventListener('click', async () => {
				if (!ui.confirm(I18N.confirm_killswitch_off)) return;
				const notes = ui.prompt('Resolution notes:', '') || '';
				const r = await api.post('admin/killswitch/deactivate', { notes: notes });
				if (r.success) { ui.successToast('Killswitch deactivated.'); await refreshKillswitch(ks); }
				else ui.errorToast(r);
			});
		}

		// Recent audit activity.
		const audit = root.querySelector('[data-hnc-recent-activity]');
		if (audit && ui.capCan('hnc_view_audit')) {
			try {
				const r = await api.get('admin/audit?per_page=10&page=1');
				if (r.success && r.data && r.data.rows && r.data.rows.length) {
					audit.innerHTML = renderAuditRows(r.data.rows);
				} else {
					audit.innerHTML = '<div class="hnc-empty">No recent events.</div>';
				}
			} catch (e) {
				audit.innerHTML = '<div class="hnc-empty">Unavailable.</div>';
			}
		}
	}

	async function refreshKillswitch(root) {
		try {
			const r = await api.get('admin/killswitch/status');
			const state = root.querySelector('[data-hnc-killswitch-state]');
			const msg = root.querySelector('[data-hnc-killswitch-message]');
			if (r.success && r.data) {
				if (r.data.active) {
					state.textContent = 'ACTIVE';
					state.className = 'hnc-killswitch-state hnc-killswitch-active';
					msg.textContent = 'Public message: "' + (r.data.public_message || '') + '"';
				} else {
					state.textContent = 'INACTIVE';
					state.className = 'hnc-killswitch-state hnc-killswitch-inactive';
					msg.textContent = '';
				}
			}
		} catch (e) {
			// silent
		}
	}

	function renderAuditRows(rows) {
		let html = '<table class="hnc-audit-table"><thead><tr><th>Time</th><th>Event</th><th>Action</th><th>Report</th></tr></thead><tbody>';
		for (const r of rows) {
			html += '<tr>'
				+ '<td>' + ui.esc(ui.fmtDate(r.created_at)) + '</td>'
				+ '<td><code>' + ui.esc(r.event_type || '') + '</code></td>'
				+ '<td>' + ui.esc(r.action || '') + '</td>'
				+ '<td>' + (r.report_type ? ui.esc(r.report_type) + ' #' + ui.esc(r.report_id || '') : '—') + '</td>'
				+ '</tr>';
		}
		html += '</tbody></table>';
		return html;
	}

	/* ================================================================
	 * ALCOHOL QUEUE SCREEN
	 * ================================================================ */

	function initAlcohol(root) {
		let page = 1;

		const queueEl = root.querySelector('[data-hnc-queue]');
		const countEl = root.querySelector('[data-hnc-queue-count]');
		const pageLbl = root.querySelector('[data-hnc-page-label]');
		const prevBtn = root.querySelector('[data-hnc-action="page-prev"]');
		const nextBtn = root.querySelector('[data-hnc-action="page-next"]');

		function filters() {
			return {
				status:   root.querySelector('[data-hnc-filter="status"]').value,
				district: root.querySelector('[data-hnc-filter="district"]').value,
				category: root.querySelector('[data-hnc-filter="category"]').value,
				sort:     root.querySelector('[data-hnc-filter="sort"]').value,
			};
		}

		async function load() {
			queueEl.innerHTML = '<div class="hnc-empty">' + ui.esc(I18N.loading) + '</div>';
			const f = filters();
			const qs = 'status=' + encodeURIComponent(f.status)
				+ '&district=' + encodeURIComponent(f.district)
				+ '&category=' + encodeURIComponent(f.category)
				+ '&sort=' + encodeURIComponent(f.sort)
				+ '&page=' + page + '&per_page=20';
			const r = await api.get('admin/alcohol/queue?' + qs);
			if (!r.success) { ui.errorToast(r); queueEl.innerHTML = ''; return; }
			render(r.data);
		}

		function render(data) {
			const rows = (data && data.rows) || [];
			const total = (data && data.total) || 0;
			countEl.textContent = total + ' report' + (total === 1 ? '' : 's');
			pageLbl.textContent = 'Page ' + page;
			prevBtn.disabled = (page === 1);
			nextBtn.disabled = (page * 20 >= total);

			if (!rows.length) {
				queueEl.innerHTML = '<div class="hnc-empty">' + ui.esc(I18N.empty_queue) + '</div>';
				return;
			}

			let html = '';
			for (const r of rows) {
				const merged = r.merged_into ? ' <span class="hnc-pill hnc-pill-gray">merged</span>' : '';
				const verified = (parseInt(r.verified_by_operator, 10) === 1) ? ' <span class="hnc-pill hnc-pill-gold">operator-verified</span>' : '';
				html += '<div class="hnc-row" data-id="' + ui.esc(r.id) + '">'
					+   '<div class="hnc-row-head">'
					+     '<div class="hnc-row-code">' + ui.esc(r.public_code || ('#' + r.id)) + '</div>'
					+     ui.badge(r.status) + merged + verified
					+   '</div>'
					+   '<div class="hnc-row-meta">'
					+     '<span>' + ui.esc(r.district || '—') + '</span>'
					+     '<span>' + ui.esc(r.category || '—') + '</span>'
					+     '<span>' + ui.esc(r.time_pattern || '—') + '</span>'
					+     '<span>' + ui.esc(ui.fmtDate(r.submitted_at)) + '</span>'
					+     '<span>reports: ' + ui.esc(r.report_count || 1) + '</span>'
					+   '</div>'
					+   '<div class="hnc-row-desc">' + ui.esc(r.description || '(no description)') + '</div>'
					+   '<div class="hnc-row-actions">'
					+     '<button type="button" class="button" data-row-action="view" data-id="' + ui.esc(r.id) + '">View</button>'
					+     buttonIf(r.status !== 'approved', 'approve', 'button-primary', 'Approve', r.id)
					+     buttonIf(r.status !== 'rejected', 'reject', '', 'Reject', r.id)
					+     buttonIf(r.status === 'pending', 'hold', '', 'Hold', r.id)
					+     buttonIf(r.status === 'hold', 'unhold', '', 'Unhold', r.id)
					+     buttonIf(r.status !== 'archived', 'archive', '', 'Archive', r.id)
					+     buttonIf(r.status === 'approved' && parseInt(r.verified_by_operator, 10) !== 1, 'verify', '', 'Verify on site', r.id)
					+   '</div>'
					+ '</div>';
			}
			queueEl.innerHTML = html;
		}

		function buttonIf(cond, action, klass, label, id) {
			if (!cond) return '';
			return '<button type="button" class="button ' + (klass || '') + '" data-row-action="' + action + '" data-id="' + ui.esc(id) + '">' + ui.esc(label) + '</button>';
		}

		root.addEventListener('click', async function (e) {
			const btn = e.target.closest('[data-row-action]');
			if (!btn) return;
			const action = btn.getAttribute('data-row-action');
			const id = btn.getAttribute('data-id');
			if (action === 'view') { viewDetail(id); return; }
			if (action === 'approve') { if (!ui.confirm(I18N.confirm_approve)) return; await doAction('POST', 'admin/alcohol/approve/' + id, { note: '' }); await load(); return; }
			if (action === 'reject')  { const reason = ui.prompt('Rejection reason (reporter sees this):'); if (reason === null) return; await doAction('POST', 'admin/alcohol/reject/' + id, { reason }); await load(); return; }
			if (action === 'hold')    { if (!ui.confirm(I18N.confirm_hold)) return; await doAction('POST', 'admin/alcohol/hold/' + id, { note: '' }); await load(); return; }
			if (action === 'unhold')  { await doAction('POST', 'admin/alcohol/unhold/' + id); await load(); return; }
			if (action === 'archive') { if (!ui.confirm(I18N.confirm_archive)) return; await doAction('POST', 'admin/alcohol/archive/' + id); await load(); return; }
			if (action === 'verify')  { if (!ui.confirm(I18N.confirm_verify)) return; await doAction('POST', 'admin/alcohol/verify/' + id); await load(); return; }
		});

		async function doAction(method, path, body) {
			const r = await api.request(method, path, body || {});
			if (r.success) ui.successToast(); else ui.errorToast(r);
		}

		async function viewDetail(id) {
			ui.openModal('<div class="hnc-empty">' + ui.esc(I18N.loading) + '</div>');
			const r = await api.get('admin/alcohol/report/' + id);
			if (!r.success) { ui.errorToast(r); ui.closeModal(); return; }
			const d = r.data.report || {};
			let html = '<h2>Alcohol report ' + ui.esc(d.public_code || ('#' + d.id)) + '</h2>';
			html += '<div class="hnc-kv"><span>Status</span><strong>' + ui.badge(d.status) + '</strong></div>';
			html += '<div class="hnc-kv"><span>District</span><strong>' + ui.esc(d.district || '—') + '</strong></div>';
			html += '<div class="hnc-kv"><span>Category</span><strong>' + ui.esc(d.category || '—') + '</strong></div>';
			html += '<div class="hnc-kv"><span>Time pattern</span><strong>' + ui.esc(d.time_pattern || '—') + '</strong></div>';
			html += '<div class="hnc-kv"><span>Lat/Lng (public)</span><strong>' + ui.esc(d.lat) + ', ' + ui.esc(d.lng) + '</strong></div>';
			html += '<div class="hnc-kv"><span>Lat/Lng (raw)</span><strong>' + ui.esc(d.lat_raw) + ', ' + ui.esc(d.lng_raw) + '</strong></div>';
			html += '<div class="hnc-kv"><span>Report count</span><strong>' + ui.esc(d.report_count || 1) + '</strong></div>';
			html += '<div class="hnc-kv"><span>Submitted</span><strong>' + ui.esc(ui.fmtDate(d.submitted_at)) + '</strong></div>';
			if (d.moderated_at) html += '<div class="hnc-kv"><span>Moderated</span><strong>' + ui.esc(ui.fmtDate(d.moderated_at)) + '</strong></div>';
			if (d.merged_into) html += '<div class="hnc-kv"><span>Merged into</span><strong>#' + ui.esc(d.merged_into) + '</strong></div>';
			if (d.rejection_reason) html += '<div class="hnc-kv"><span>Rejection reason</span><strong>' + ui.esc(d.rejection_reason) + '</strong></div>';

			// Live photo preview. The endpoint returns 404 if the
			// file was already purged under retention, and the
			// renderer surfaces that cleanly.
			if (d.photo_uuid) {
				html += '<h3>Live photo</h3>'
					+ '<div class="hnc-media-frame" data-hnc-alcohol-photo></div>';
			} else {
				html += '<h3>Live photo</h3>'
					+ '<div class="hnc-desc-block">(no photo on this row)</div>';
			}

			html += '<h3>Reporter description</h3><div class="hnc-desc-block">' + ui.esc(d.description || '(none)') + '</div>';
			html += '<h3>Merge manually</h3>'
				+ '<div class="hnc-merge-form">'
				+   '<label>Merge THIS report (#' + ui.esc(d.id) + ') into target ID: <input type="number" data-merge-target /></label>'
				+   '<button type="button" class="button" data-merge-submit>Merge</button>'
				+   (d.merged_into ? '<button type="button" class="button" data-unmerge-submit>Unmerge from #' + ui.esc(d.merged_into) + '</button>' : '')
				+ '</div>';
			ui.openModal(html);

			const modal = document.querySelector('[data-hnc-modal]');
			const photoFrame = modal.querySelector('[data-hnc-alcohol-photo]');
			if (photoFrame) {
				ui.renderMediaPreview(photoFrame, 'admin/alcohol/photo/' + encodeURIComponent(d.id));
			}
			modal.querySelector('[data-merge-submit]')?.addEventListener('click', async () => {
				const t = parseInt(modal.querySelector('[data-merge-target]').value, 10);
				if (!t) return;
				const m = await api.post('admin/alcohol/merge', { source: parseInt(d.id, 10), target: t });
				if (m.success) { ui.successToast('Merged.'); ui.closeModal(); await load(); }
				else ui.errorToast(m);
			});
			modal.querySelector('[data-unmerge-submit]')?.addEventListener('click', async () => {
				const m = await api.post('admin/alcohol/unmerge/' + d.id);
				if (m.success) { ui.successToast('Unmerged.'); ui.closeModal(); await load(); }
				else ui.errorToast(m);
			});
		}

		root.querySelector('[data-hnc-action="refresh"]').addEventListener('click', () => { page = 1; load(); });
		prevBtn.addEventListener('click', () => { if (page > 1) { page--; load(); } });
		nextBtn.addEventListener('click', () => { page++; load(); });
		root.querySelectorAll('[data-hnc-filter]').forEach(el => el.addEventListener('change', () => { page = 1; load(); }));

		load();
	}

	/* ================================================================
	 * DRUG QUEUE SCREEN
	 * ================================================================ */

	function initDrug(root) {
		let page = 1;
		const canForward = root.getAttribute('data-hnc-can-forward') === '1';

		const queueEl = root.querySelector('[data-hnc-queue]');
		const countEl = root.querySelector('[data-hnc-queue-count]');
		const pageLbl = root.querySelector('[data-hnc-page-label]');
		const prevBtn = root.querySelector('[data-hnc-action="page-prev"]');
		const nextBtn = root.querySelector('[data-hnc-action="page-next"]');

		function filters() {
			return {
				status:       root.querySelector('[data-hnc-filter="status"]').value,
				district:     root.querySelector('[data-hnc-filter="district"]').value,
				category:     root.querySelector('[data-hnc-filter="category"]').value,
				severity_min: root.querySelector('[data-hnc-filter="severity_min"]').value || '0',
			};
		}

		async function load() {
			queueEl.innerHTML = '<div class="hnc-empty">' + ui.esc(I18N.loading) + '</div>';
			const f = filters();
			const qs = 'status=' + encodeURIComponent(f.status)
				+ '&district=' + encodeURIComponent(f.district)
				+ '&category=' + encodeURIComponent(f.category)
				+ '&severity_min=' + encodeURIComponent(f.severity_min)
				+ '&page=' + page + '&per_page=20';
			const r = await api.get('admin/drug/queue?' + qs);
			if (!r.success) { ui.errorToast(r); queueEl.innerHTML = ''; return; }
			render(r.data);
		}

		function render(data) {
			const rows = (data && data.rows) || [];
			const total = (data && data.total) || 0;
			countEl.textContent = total + ' report' + (total === 1 ? '' : 's');
			pageLbl.textContent = 'Page ' + page;
			prevBtn.disabled = (page === 1);
			nextBtn.disabled = (page * 20 >= total);

			if (!rows.length) {
				queueEl.innerHTML = '<div class="hnc-empty">' + ui.esc(I18N.empty_queue) + '</div>';
				return;
			}

			let html = '';
			for (const r of rows) {
				const phone = r.phone_vault_id ? ' <span class="hnc-pill hnc-pill-gold">phone</span>' : '';
				const media = r.media_uuid ? ' <span class="hnc-pill hnc-pill-gray">media</span>' : '';
				const sev = r.severity_flag ? ' <span class="hnc-sev hnc-sev-' + parseInt(r.severity_flag, 10) + '">sev ' + ui.esc(r.severity_flag) + '</span>' : '';
				html += '<div class="hnc-row" data-id="' + ui.esc(r.id) + '">'
					+   '<div class="hnc-row-head">'
					+     '<div class="hnc-row-code">' + ui.esc(r.public_code || ('#' + r.id)) + '</div>'
					+     ui.badge(r.status) + phone + media + sev
					+   '</div>'
					+   '<div class="hnc-row-meta">'
					+     '<span>' + ui.esc(r.district || '—') + '</span>'
					+     '<span>' + ui.esc(r.category || '—') + '</span>'
					+     '<span>' + ui.esc(ui.fmtDate(r.submitted_at)) + '</span>'
					+   '</div>'
					+   '<div class="hnc-row-actions">'
					+     '<button type="button" class="button" data-row-action="view" data-id="' + ui.esc(r.id) + '">View</button>'
					+     (r.status === 'pending' || r.status === 'hold' ? '<button type="button" class="button button-primary" data-row-action="approve" data-id="' + ui.esc(r.id) + '">Approve</button>' : '')
					+     (r.status !== 'rejected' && r.status !== 'archived' ? '<button type="button" class="button" data-row-action="reject" data-id="' + ui.esc(r.id) + '">Reject</button>' : '')
					+     (r.status === 'pending' ? '<button type="button" class="button" data-row-action="hold" data-id="' + ui.esc(r.id) + '">Hold</button>' : '')
					+     (r.status === 'hold' ? '<button type="button" class="button" data-row-action="unhold" data-id="' + ui.esc(r.id) + '">Unhold</button>' : '')
					+     (r.status === 'approved' ? '<button type="button" class="button" data-row-action="resolve" data-id="' + ui.esc(r.id) + '">Resolve</button>' : '')
					+     (r.status !== 'archived' && (r.status === 'approved' || r.status === 'resolved' || r.status === 'rejected') ? '<button type="button" class="button" data-row-action="archive" data-id="' + ui.esc(r.id) + '">Archive</button>' : '')
					+     '<button type="button" class="button" data-row-action="severity" data-id="' + ui.esc(r.id) + '">Severity</button>'
					+     (canForward && r.status === 'approved' ? '<button type="button" class="button" data-row-action="forward" data-id="' + ui.esc(r.id) + '">Forward</button>' : '')
					+   '</div>'
					+ '</div>';
			}
			queueEl.innerHTML = html;
		}

		root.addEventListener('click', async function (e) {
			const btn = e.target.closest('[data-row-action]');
			if (!btn) return;
			const action = btn.getAttribute('data-row-action');
			const id = btn.getAttribute('data-id');
			if (action === 'view') { viewDetail(id); return; }
			if (action === 'approve') { if (!ui.confirm(I18N.confirm_approve)) return; await doA('POST', 'admin/drug/approve/' + id, {}); return; }
			if (action === 'reject')  { const reason = ui.prompt('Rejection reason (short):'); if (!reason) return; await doA('POST', 'admin/drug/reject/' + id, { reason }); return; }
			if (action === 'hold')    { if (!ui.confirm(I18N.confirm_hold)) return; await doA('POST', 'admin/drug/hold/' + id, {}); return; }
			if (action === 'unhold')  { await doA('POST', 'admin/drug/unhold/' + id); return; }
			if (action === 'resolve') { if (!ui.confirm(I18N.confirm_resolve)) return; await doA('POST', 'admin/drug/resolve/' + id, {}); return; }
			if (action === 'archive') { if (!ui.confirm(I18N.confirm_archive)) return; await doA('POST', 'admin/drug/archive/' + id); return; }
			if (action === 'severity') {
				const s = ui.prompt('Severity (1-5):', '3');
				if (!s) return;
				const n = parseInt(s, 10);
				if (n < 1 || n > 5) { ui.toast('Severity must be 1-5.', 'error'); return; }
				await doA('POST', 'admin/drug/severity/' + id, { severity: n });
				return;
			}
			if (action === 'forward') {
				const partner = ui.prompt('Partner slug or numeric ID:', '');
				if (!partner) return;
				const note = ui.prompt('Note for partner (optional):', '') || '';
				await doA('POST', 'admin/drug/forward/' + id, { partner, note });
				return;
			}
		});

		async function doA(method, path, body) {
			const r = await api.request(method, path, body || {});
			if (r.success) { ui.successToast(); await load(); }
			else ui.errorToast(r);
		}

		async function viewDetail(id) {
			ui.openModal('<div class="hnc-empty">' + ui.esc(I18N.loading) + '</div>');
			const r = await api.get('admin/drug/report/' + id);
			if (!r.success) { ui.errorToast(r); ui.closeModal(); return; }
			const d = r.data.report || {};
			let html = '<h2>Drug report ' + ui.esc(d.public_code || ('#' + d.id)) + '</h2>';
			html += '<div class="hnc-kv"><span>Status</span><strong>' + ui.badge(d.status) + '</strong></div>';
			html += '<div class="hnc-kv"><span>District</span><strong>' + ui.esc(d.district || '—') + '</strong></div>';
			html += '<div class="hnc-kv"><span>Category</span><strong>' + ui.esc(d.category || '—') + '</strong></div>';
			if (d.severity_flag) html += '<div class="hnc-kv"><span>Severity</span><strong>' + ui.esc(d.severity_flag) + '/5</strong></div>';
			html += '<div class="hnc-kv"><span>Submission mode</span><strong>' + ui.esc(d.submission_mode) + '</strong></div>';
			html += '<div class="hnc-kv"><span>Submitted</span><strong>' + ui.esc(ui.fmtDate(d.submitted_at)) + '</strong></div>';
			if (d.moderated_at) html += '<div class="hnc-kv"><span>Moderated</span><strong>' + ui.esc(ui.fmtDate(d.moderated_at)) + '</strong></div>';
			if (d.resolved_at) html += '<div class="hnc-kv"><span>Resolved</span><strong>' + ui.esc(ui.fmtDate(d.resolved_at)) + '</strong></div>';

			html += '<h3>Area description</h3><div class="hnc-desc-block">' + ui.esc(d.area_desc || '(none)') + '</div>';
			html += '<h3>Pattern</h3><div class="hnc-desc-block">' + ui.esc(d.pattern || '(none)') + '</div>';
			if (d.vehicle_info) html += '<h3>Vehicle info</h3><div class="hnc-desc-block">' + ui.esc(d.vehicle_info) + '</div>';

			// Optional photo or video the reporter attached. Drug
			// media is stricter than alcohol — it auto-deletes on
			// reject/resolve/archive — so a 404 here is common and
			// the renderer surfaces it clearly.
			if (d.media_uuid) {
				const mediaLabel = (d.media_type === 'video') ? 'Reporter video' : 'Reporter media';
				html += '<h3>' + ui.esc(mediaLabel) + '</h3>'
					+ '<div class="hnc-media-frame" data-hnc-drug-media></div>';
			}

			if (d.phone_vault_id) {
				html += '<h3>Reporter phone</h3>';
				if (ui.capCan('hnc_reveal_phone')) {
					html += '<div class="hnc-reveal-block">'
						+ '<label><input type="checkbox" data-reveal-consent /> ' + ui.esc(I18N.reveal_confirm_text) + '</label>'
						+ '<label>' + ui.esc(I18N.reveal_reason_label) + '<input type="text" data-reveal-reason /></label>'
						+ '<button type="button" class="button button-warning" data-reveal-btn>Reveal phone</button>'
						+ '<div class="hnc-reveal-output" data-reveal-output></div>'
						+ '</div>';
				} else {
					html += '<p class="hnc-help-text">Phone is stored but you lack the capability to reveal it.</p>';
				}
			}

			if (canForward) {
				html += '<h3>Forward history</h3><div class="hnc-forward-history" data-forward-history>Loading...</div>';
			}

			ui.openModal(html);
			const modal = document.querySelector('[data-hnc-modal]');

			// Optional media renderer.
			const drugMedia = modal.querySelector('[data-hnc-drug-media]');
			if (drugMedia) {
				ui.renderMediaPreview(drugMedia, 'admin/drug/media/' + encodeURIComponent(d.id));
			}

			// Reveal wiring.
			const revealBtn = modal.querySelector('[data-reveal-btn]');
			if (revealBtn) {
				revealBtn.addEventListener('click', async () => {
					const consent = modal.querySelector('[data-reveal-consent]').checked;
					const reason = modal.querySelector('[data-reveal-reason]').value.trim();
					if (!consent) { ui.toast('Check the consent confirmation box.', 'error'); return; }
					if (reason.length < 5) { ui.toast('Reason must be at least 5 characters.', 'error'); return; }
					const r = await api.post('admin/vault/reveal/' + d.phone_vault_id, { second_consent: true, reason: reason });
					if (r.success && r.data && r.data.phone) {
						modal.querySelector('[data-reveal-output]').innerHTML = '<strong>' + ui.esc(r.data.phone) + '</strong>';
					} else {
						ui.errorToast(r);
					}
				});
			}

			// Forward history.
			if (canForward) {
				const fhBox = modal.querySelector('[data-forward-history]');
				const fh = await api.get('admin/drug/forward-history/' + d.id);
				if (fh.success && fh.data && fh.data.history) {
					if (!fh.data.history.length) fhBox.innerHTML = '<div class="hnc-empty">Never forwarded.</div>';
					else {
						let h = '<ul class="hnc-forward-list">';
						for (const ev of fh.data.history) {
							h += '<li>' + ui.esc(ui.fmtDate(ev.forwarded_at)) + ' → <code>' + ui.esc(ev.partner) + '</code>'
								+ (ev.note ? ' — ' + ui.esc(ev.note) : '')
								+ '</li>';
						}
						h += '</ul>';
						fhBox.innerHTML = h;
					}
				}
			}
		}

		root.querySelector('[data-hnc-action="refresh"]').addEventListener('click', () => { page = 1; load(); });
		prevBtn.addEventListener('click', () => { if (page > 1) { page--; load(); } });
		nextBtn.addEventListener('click', () => { page++; load(); });
		root.querySelectorAll('[data-hnc-filter]').forEach(el => el.addEventListener('change', () => { page = 1; load(); }));

		load();
	}

	/* ================================================================
	 * VAULT SCREEN
	 * ================================================================ */

	function initVault(root) {
		const statusCard = root.querySelector('[data-hnc-vault-status]');
		const setForm = root.querySelector('[data-hnc-passphrase-form]');

		// Read the effective minimum passphrase length from the wrap's
		// data attribute. PHP computes it from the
		// `hnc_vault_min_passphrase_length` filter (default 16, floor
		// 12) so client and server always agree.
		const minPassphrase = Math.max(12, parseInt(root.getAttribute('data-hnc-min-passphrase') || '16', 10));

		if (setForm) {
			setForm.querySelector('[data-hnc-action="set-passphrase"]').addEventListener('click', async () => {
				const p1 = setForm.querySelector('[data-hnc-passphrase]').value;
				const p2 = setForm.querySelector('[data-hnc-passphrase-confirm]').value;
				if (p1.length < minPassphrase) { ui.toast('Passphrase must be at least ' + minPassphrase + ' characters.', 'error'); return; }
				if (p1 !== p2) { ui.toast('Passphrases do not match.', 'error'); return; }
				if (!ui.confirm('Set this passphrase? Losing it means permanent data loss.')) return;
				const r = await api.post('vault/set-passphrase', { passphrase: p1 });
				if (r.success) { ui.successToast('Passphrase set.'); setTimeout(() => location.reload(), 800); }
				else ui.errorToast(r);
			});
		}

		if (statusCard) {
			statusCard.querySelector('[data-hnc-action="unlock"]').addEventListener('click', async () => {
				const p = statusCard.querySelector('[data-hnc-unlock-input]').value;
				if (!p) return;
				const r = await api.post('vault/unlock', { passphrase: p });
				if (r.success) {
					ui.successToast(I18N.vault_unlocked || 'Unlocked.');
					statusCard.querySelector('[data-hnc-unlock-input]').value = '';
					await refreshStatus();
				} else ui.errorToast(r);
			});
			statusCard.querySelector('[data-hnc-action="lock"]').addEventListener('click', async () => {
				const r = await api.post('vault/lock');
				if (r.success) { ui.successToast('Locked.'); await refreshStatus(); }
				else ui.errorToast(r);
			});
		}

		async function refreshStatus() {
			if (!statusCard) return;
			const ind = statusCard.querySelector('[data-hnc-vault-indicator]');
			const lbl = statusCard.querySelector('[data-hnc-vault-label]');
			const cnt = statusCard.querySelector('[data-hnc-vault-countdown]');
			const r = await api.get('vault/status');
			if (!r.success || !r.data) {
				ind.textContent = '?'; lbl.textContent = 'Status unavailable.';
				return;
			}
			if (r.data.unlocked) {
				ind.textContent = '🔓'; ind.className = 'hnc-vault-indicator hnc-vault-unlocked';
				lbl.textContent = I18N.vault_unlocked || 'Unlocked';
				cnt.textContent = 'Auto-lock in ' + (r.data.ttl_minutes || '?') + ' minutes idle.';
			} else {
				ind.textContent = '🔒'; ind.className = 'hnc-vault-indicator hnc-vault-locked';
				lbl.textContent = I18N.vault_locked || 'Locked';
				cnt.textContent = '';
			}
		}

		// Counts — populate the three stat cards from the real vault
		// counts endpoint. Cards stay as "—" on any error so an empty
		// response never looks like a confusing zero.
		async function refreshCounts() {
			const totalEl   = root.querySelector('[data-hnc-counts-total]');
			const alcoholEl = root.querySelector('[data-hnc-counts-alcohol]');
			const drugEl    = root.querySelector('[data-hnc-counts-drug]');
			if (!totalEl && !alcoholEl && !drugEl) return;
			try {
				const r = await api.get('admin/vault/counts');
				if (!r || !r.success || !r.data) {
					if (totalEl)   totalEl.textContent   = '—';
					if (alcoholEl) alcoholEl.textContent = '—';
					if (drugEl)    drugEl.textContent    = '—';
					return;
				}
				if (totalEl)   totalEl.textContent   = String(r.data.total   || 0);
				if (alcoholEl) alcoholEl.textContent = String(r.data.alcohol || 0);
				if (drugEl)    drugEl.textContent    = String(r.data.drug    || 0);
			} catch (e) {
				if (totalEl)   totalEl.textContent   = '—';
				if (alcoholEl) alcoholEl.textContent = '—';
				if (drugEl)    drugEl.textContent    = '—';
			}
		}
		root.querySelector('[data-hnc-action="refresh-counts"]')?.addEventListener('click', () => {
			refreshStatus();
			refreshCounts();
			loadRecentAudit();
		});

		async function loadRecentAudit() {
			const box = root.querySelector('[data-hnc-audit-recent]');
			if (!box) return;
			const r = await api.get('admin/audit?event_type=vault&per_page=10');
			if (r.success && r.data && r.data.rows) {
				if (r.data.rows.length) box.innerHTML = renderAuditRows(r.data.rows);
				else box.innerHTML = '<div class="hnc-empty">No vault events yet.</div>';
			} else {
				box.innerHTML = '<div class="hnc-empty">Unavailable.</div>';
			}
		}

		refreshStatus();
		refreshCounts();
		loadRecentAudit();
	}

	/* ================================================================
	 * TRANSPARENCY SCREEN
	 * ================================================================ */

	function initTransparency(root) {
		root.querySelector('[data-hnc-action="build"]').addEventListener('click', async () => {
			const year = parseInt(root.querySelector('[data-hnc-year]').value, 10);
			const month = parseInt(root.querySelector('[data-hnc-month]').value, 10);
			const r = await api.post('admin/transparency/build', { year, month });
			if (r.success) { ui.successToast('Snapshot built. Review then publish.'); await load(); }
			else ui.errorToast(r);
		});

		root.querySelector('[data-hnc-action="refresh-list"]').addEventListener('click', load);

		async function load() {
			const listEl = root.querySelector('[data-hnc-snapshot-list]');
			listEl.innerHTML = '<div class="hnc-empty">' + ui.esc(I18N.loading) + '</div>';
			const r = await api.get('transparency');
			if (!r.success) { ui.errorToast(r); listEl.innerHTML = ''; return; }
			const rows = r.data || [];
			if (!rows.length) { listEl.innerHTML = '<div class="hnc-empty">No published snapshots yet.</div>'; return; }
			let html = '<table class="hnc-snapshot-table"><thead><tr><th>Period</th><th>Alcohol</th><th>Drug</th><th>Published</th><th>Actions</th></tr></thead><tbody>';
			for (const s of rows) {
				const period = (s.period || (s.year + '-' + String(s.month).padStart(2, '0')));
				html += '<tr>'
					+ '<td><strong>' + ui.esc(period) + '</strong></td>'
					+ '<td>R:' + ui.esc(s.alcohol && s.alcohol.received) + ' / A:' + ui.esc(s.alcohol && s.alcohol.approved) + ' / Rj:' + ui.esc(s.alcohol && s.alcohol.rejected) + '</td>'
					+ '<td>R:' + ui.esc(s.drug && s.drug.received) + ' / A:' + ui.esc(s.drug && s.drug.approved) + ' / F:' + ui.esc(s.drug && s.drug.forwarded) + '</td>'
					+ '<td>' + ui.esc(ui.fmtDate(s.published_at)) + '</td>'
					+ '<td>'
					+   '<button type="button" class="button" data-unpublish data-year="' + ui.esc(s.year) + '" data-month="' + ui.esc(s.month) + '">Unpublish</button>'
					+   '<button type="button" class="button" data-republish data-year="' + ui.esc(s.year) + '" data-month="' + ui.esc(s.month) + '">Edit note</button>'
					+ '</td>'
					+ '</tr>';
			}
			html += '</tbody></table>';
			html += '<div class="hnc-publish-form">'
				+ '<label>Publish (or republish with note): '
				+ '<input type="number" min="2024" data-pub-year placeholder="Year" />'
				+ '<input type="number" min="1" max="12" data-pub-month placeholder="M" />'
				+ '<input type="text" data-pub-note placeholder="Optional note" />'
				+ '</label>'
				+ '<button type="button" class="button button-primary" data-pub-submit>Publish</button>'
				+ '</div>';
			listEl.innerHTML = html;

			listEl.querySelectorAll('[data-unpublish]').forEach(btn => {
				btn.addEventListener('click', async () => {
					if (!ui.confirm('Unpublish this period? Visitors will no longer see it.')) return;
					const r2 = await api.post('admin/transparency/unpublish', { year: parseInt(btn.dataset.year, 10), month: parseInt(btn.dataset.month, 10) });
					if (r2.success) { ui.successToast('Unpublished.'); load(); }
					else ui.errorToast(r2);
				});
			});
			listEl.querySelectorAll('[data-republish]').forEach(btn => {
				btn.addEventListener('click', async () => {
					const note = ui.prompt('New admin note for this period:', '') || '';
					const r2 = await api.post('admin/transparency/publish', { year: parseInt(btn.dataset.year, 10), month: parseInt(btn.dataset.month, 10), note: note });
					if (r2.success) { ui.successToast('Updated.'); load(); }
					else ui.errorToast(r2);
				});
			});
			listEl.querySelector('[data-pub-submit]')?.addEventListener('click', async () => {
				const y = parseInt(listEl.querySelector('[data-pub-year]').value, 10);
				const m = parseInt(listEl.querySelector('[data-pub-month]').value, 10);
				const n = listEl.querySelector('[data-pub-note]').value || '';
				const r2 = await api.post('admin/transparency/publish', { year: y, month: m, note: n });
				if (r2.success) { ui.successToast('Published.'); load(); }
				else ui.errorToast(r2);
			});
		}

		load();
	}

	/* ================================================================
	 * AUDIT SCREEN
	 * ================================================================ */

	function initAudit(root) {
		let page = 1;

		const listEl = root.querySelector('[data-hnc-audit-list]');
		const countEl = root.querySelector('[data-hnc-queue-count]');
		const pageLbl = root.querySelector('[data-hnc-page-label]');
		const prevBtn = root.querySelector('[data-hnc-action="page-prev"]');
		const nextBtn = root.querySelector('[data-hnc-action="page-next"]');

		// Prefill from data attrs if deep-linked.
		const prefill = {
			event_type: root.getAttribute('data-hnc-prefill-event') || '',
			report_type: root.getAttribute('data-hnc-prefill-rtype') || '',
			report_id: root.getAttribute('data-hnc-prefill-rid') || '',
		};
		for (const key of Object.keys(prefill)) {
			const el = root.querySelector('[data-hnc-filter="' + key + '"]');
			if (el && prefill[key]) el.value = prefill[key];
		}

		function f() {
			return {
				event_type:  root.querySelector('[data-hnc-filter="event_type"]').value,
				action:      root.querySelector('[data-hnc-filter="action"]').value,
				report_type: root.querySelector('[data-hnc-filter="report_type"]').value,
				report_id:   root.querySelector('[data-hnc-filter="report_id"]').value || '0',
			};
		}

		async function load() {
			listEl.innerHTML = '<div class="hnc-empty">' + ui.esc(I18N.loading) + '</div>';
			const v = f();
			const qs = Object.keys(v).map(k => k + '=' + encodeURIComponent(v[k])).join('&') + '&page=' + page + '&per_page=30';
			const r = await api.get('admin/audit?' + qs);
			if (!r.success) { ui.errorToast(r); listEl.innerHTML = ''; return; }
			const rows = (r.data && r.data.rows) || [];
			const total = (r.data && r.data.total) || 0;
			countEl.textContent = total + ' event' + (total === 1 ? '' : 's');
			pageLbl.textContent = 'Page ' + page;
			prevBtn.disabled = (page === 1);
			nextBtn.disabled = (page * 30 >= total);
			if (!rows.length) { listEl.innerHTML = '<div class="hnc-empty">No matching events.</div>'; return; }
			listEl.innerHTML = renderAuditTable(rows);
		}

		function renderAuditTable(rows) {
			let html = '<table class="hnc-audit-table"><thead><tr><th>Time</th><th>Actor</th><th>Event</th><th>Action</th><th>Report</th><th>Detail</th></tr></thead><tbody>';
			for (const r of rows) {
				let detail = r.detail || '';
				if (typeof detail === 'string' && detail.length > 200) detail = detail.substr(0, 200) + '…';
				html += '<tr>'
					+ '<td>' + ui.esc(ui.fmtDate(r.created_at)) + '</td>'
					+ '<td>' + (r.actor_id ? '#' + ui.esc(r.actor_id) : '—') + '</td>'
					+ '<td><code>' + ui.esc(r.event_type || '') + '</code></td>'
					+ '<td>' + ui.esc(r.action || '') + '</td>'
					+ '<td>' + (r.report_type ? ui.esc(r.report_type) + ' #' + ui.esc(r.report_id || '') : '—') + '</td>'
					+ '<td class="hnc-mono">' + ui.esc(detail) + '</td>'
					+ '</tr>';
			}
			html += '</tbody></table>';
			return html;
		}

		root.querySelector('[data-hnc-action="refresh"]').addEventListener('click', () => { page = 1; load(); });
		prevBtn.addEventListener('click', () => { if (page > 1) { page--; load(); } });
		nextBtn.addEventListener('click', () => { page++; load(); });

		load();
	}

	/* ================================================================
	 * SETTINGS SCREEN
	 * ================================================================ */

	function initSettings(root) {
		// The settings form submits to options.php via standard WordPress
		// register_setting flow. No JS needed except to highlight the form.
		// Intentionally minimal.
	}

	/* ================================================================
	 * DISPATCH
	 * ================================================================ */

	document.addEventListener('DOMContentLoaded', function () {
		const root = document.querySelector('[data-hnc-screen]');
		if (!root) return;
		const screen = root.getAttribute('data-hnc-screen');
		try {
			switch (screen) {
				case 'dashboard':    initDashboard(root); break;
				case 'alcohol':      initAlcohol(root); break;
				case 'drug':         initDrug(root); break;
				case 'vault':        initVault(root); break;
				case 'transparency': initTransparency(root); break;
				case 'audit':        initAudit(root); break;
				case 'settings':     initSettings(root); break;
			}
		} catch (e) {
			console.error('HNC admin screen init failed:', e);
			ui.toast('Admin UI failed to load. See browser console for details.', 'error');
		}
	});
})();
