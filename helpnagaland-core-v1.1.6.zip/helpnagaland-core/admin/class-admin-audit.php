<?php
/**
 * Admin Audit log screen.
 *
 * Read-only viewer for the immutable audit trail. Supports filtering by
 * event_type, action, report_type, and report_id. Paginated.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Admin_Audit
 */
final class HNC_Admin_Audit {


	/**
	 * Render the audit log viewer.
	 *
	 * @return void
	 */
	public static function render() {
		if ( ! current_user_can( 'hnc_view_audit' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'helpnagaland-core' ) );
		}

		// Allow deep-linking with ?event_type=vault etc.
		$prefill_event = isset( $_GET['event_type'] ) ? sanitize_key( wp_unslash( (string) $_GET['event_type'] ) ) : '';
		$prefill_rtype = isset( $_GET['report_type'] ) ? sanitize_key( wp_unslash( (string) $_GET['report_type'] ) ) : '';
		$prefill_rid   = isset( $_GET['report_id'] ) ? (int) $_GET['report_id'] : 0;

		$event_types = array(
			''             => __( 'All event types', 'helpnagaland-core' ),
			'alcohol'      => 'alcohol',
			'drug'         => 'drug',
			'vault'        => 'vault',
			'partner'      => 'partner',
			'transparency' => 'transparency',
			'settings'     => 'settings',
			'role'         => 'role',
			'killswitch'   => 'killswitch',
			'system'       => 'system',
			'security'     => 'security',
			'auth'         => 'auth',
		);

		?>
		<div class="wrap hnc-wrap" data-hnc-screen="audit"
			data-hnc-prefill-event="<?php echo esc_attr( $prefill_event ); ?>"
			data-hnc-prefill-rtype="<?php echo esc_attr( $prefill_rtype ); ?>"
			data-hnc-prefill-rid="<?php echo esc_attr( (string) $prefill_rid ); ?>">
			<h1 class="hnc-title">
				<?php esc_html_e( 'Audit Log', 'helpnagaland-core' ); ?>
				<span class="hnc-pill hnc-pill-neutral">IMMUTABLE</span>
			</h1>

			<p class="hnc-subtitle">
				<?php esc_html_e( 'Every mutation writes a row here. Logs are retained 5 years and cannot be deleted via the admin UI. Use this to investigate what happened and who did it.', 'helpnagaland-core' ); ?>
			</p>

			<div class="hnc-filter-bar">
				<label>
					<span><?php esc_html_e( 'Event type', 'helpnagaland-core' ); ?></span>
					<select data-hnc-filter="event_type">
						<?php foreach ( $event_types as $val => $label ) : ?>
							<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $val, $prefill_event ); ?>>
								<?php echo esc_html( (string) $label ); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</label>

				<label>
					<span><?php esc_html_e( 'Action', 'helpnagaland-core' ); ?></span>
					<input type="text" data-hnc-filter="action" placeholder="<?php esc_attr_e( 'e.g. approve, reject', 'helpnagaland-core' ); ?>" />
				</label>

				<label>
					<span><?php esc_html_e( 'Report type', 'helpnagaland-core' ); ?></span>
					<select data-hnc-filter="report_type">
						<option value="" <?php selected( '', $prefill_rtype ); ?>><?php esc_html_e( 'Any', 'helpnagaland-core' ); ?></option>
						<option value="alcohol" <?php selected( 'alcohol', $prefill_rtype ); ?>><?php esc_html_e( 'Alcohol', 'helpnagaland-core' ); ?></option>
						<option value="drug" <?php selected( 'drug', $prefill_rtype ); ?>><?php esc_html_e( 'Drug', 'helpnagaland-core' ); ?></option>
					</select>
				</label>

				<label>
					<span><?php esc_html_e( 'Report ID', 'helpnagaland-core' ); ?></span>
					<input type="number" min="0" data-hnc-filter="report_id" value="<?php echo esc_attr( (string) $prefill_rid ); ?>" />
				</label>

				<button type="button" class="button button-primary" data-hnc-action="refresh">
					<?php esc_html_e( 'Search', 'helpnagaland-core' ); ?>
				</button>
			</div>

			<div class="hnc-queue-meta">
				<span data-hnc-queue-count>—</span>
			</div>

			<div class="hnc-audit-list" data-hnc-audit-list>
				<div class="hnc-empty"><?php esc_html_e( 'Run a search to load audit events.', 'helpnagaland-core' ); ?></div>
			</div>

			<div class="hnc-pager">
				<button type="button" class="button" data-hnc-action="page-prev" disabled>← <?php esc_html_e( 'Prev', 'helpnagaland-core' ); ?></button>
				<span data-hnc-page-label>—</span>
				<button type="button" class="button" data-hnc-action="page-next">
					<?php esc_html_e( 'Next', 'helpnagaland-core' ); ?> →
				</button>
			</div>
		</div>
		<?php
	}
}
