<?php
/**
 * Partner Dashboard: the screen a partner sees when they log in.
 *
 * Completely separate from the moderator admin UI. A partner cannot see
 * the moderation queue, vault, audit log, or settings. They see only
 * their own forwarded cases.
 *
 * Registered as a sub-page under Clean Nagaland with the
 * hnc_partner_access capability gate. The partner's WordPress role
 * already grants them wp-admin access at the minimum level needed for
 * WordPress to render this page — Phase 1's role definition ensures the
 * hnc_partner role has `read` + `hnc_partner_access`.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Partner_Dashboard
 */
final class HNC_Admin_Partner_Dashboard {


	/**
	 * Render the partner dashboard page.
	 *
	 * @return void
	 */
	public static function render() {
		if ( ! current_user_can( 'hnc_partner_access' ) ) {
			wp_die( esc_html__( 'You do not have partner access.', 'helpnagaland-core' ), '', array( 'response' => 403 ) );
		}

		$uid     = (int) get_current_user_id();
		$partner = HNC_Partner_Model::get_by_wp_user( $uid );

		?>
		<div class="wrap hnc-wrap" data-hnc-screen="partner-dashboard">
			<h1 class="hnc-title"><?php esc_html_e( 'Partner Dashboard', 'helpnagaland-core' ); ?></h1>

			<?php if ( null === $partner ) : ?>
				<div class="hnc-card hnc-card-warning">
					<h2><?php esc_html_e( 'No partner record found.', 'helpnagaland-core' ); ?></h2>
					<p>
						<?php esc_html_e( 'Your user account has the partner capability but is not linked to a partner record. Contact the site operator.', 'helpnagaland-core' ); ?>
					</p>
				</div>
				</div>
				<?php
				return;
			endif;

			if ( (int) $partner->active !== 1 ) :
				?>
				<div class="hnc-card hnc-card-warning">
					<h2><?php esc_html_e( 'Your partner access is inactive.', 'helpnagaland-core' ); ?></h2>
					<p>
						<?php esc_html_e( 'The site operator has deactivated your partner account. New forwarded cases will not appear here until access is restored.', 'helpnagaland-core' ); ?>
					</p>
				</div>
				</div>
				<?php
				return;
			endif;
			?>

			<div class="hnc-card" style="margin-bottom:1.5rem;">
				<h2 style="margin-top:0"><?php echo esc_html( $partner->name ); ?></h2>
				<p class="description">
					<?php esc_html_e( 'Slug:', 'helpnagaland-core' ); ?> <code><?php echo esc_html( $partner->slug ); ?></code>
				</p>
				<p>
					<?php esc_html_e( 'This dashboard shows drug reports that Nagaland Me has forwarded to your organization. Please acknowledge each case you have seen, mark it as acted on when you have taken action, and close it when no further work remains.', 'helpnagaland-core' ); ?>
				</p>
			</div>

			<nav class="hnc-filter-bar" style="margin-bottom:1rem;">
				<?php
				$states = array(
					'unseen' => __( 'New (unacknowledged)', 'helpnagaland-core' ),
					'open'   => __( 'Open', 'helpnagaland-core' ),
					'acted'  => __( 'Acted', 'helpnagaland-core' ),
					'closed' => __( 'Closed', 'helpnagaland-core' ),
					'all'    => __( 'All', 'helpnagaland-core' ),
				);
				$current = isset( $_GET['state'] ) ? sanitize_key( wp_unslash( $_GET['state'] ) ) : 'unseen';
				if ( ! array_key_exists( $current, $states ) ) {
					$current = 'unseen';
				}
				foreach ( $states as $slug => $label ) {
					$url = add_query_arg( 'state', $slug, menu_page_url( 'helpnagaland-partner-dashboard', false ) );
					$is  = ( $current === $slug );
					printf(
						'<a class="button %s" href="%s">%s</a> ',
						$is ? 'button-primary' : '',
						esc_url( $url ),
						esc_html( $label )
					);
				}
				?>
			</nav>

			<div class="hnc-partner-queue" data-hnc-partner-state="<?php echo esc_attr( $current ); ?>">
				<p class="description"><?php esc_html_e( 'Loading your cases…', 'helpnagaland-core' ); ?></p>
			</div>
		</div>
		<?php
	}
}
