<?php
/**
 * Admin Alcohol queue screen.
 *
 * The moderation cockpit for alcohol reports. Renders a shell of:
 *
 *   - Filter bar: status, district, category, sort.
 *   - Table or card list of reports (populated client-side via REST).
 *   - Row actions: View, Approve, Reject, Hold, Archive, Verify-operator.
 *   - Detail panel with photo preview, merge UI, per-field fields.
 *
 * All data flow is through the Phase 6 REST endpoints. This PHP file
 * is deliberately skeletal so adding a new filter or action tomorrow
 * is a JS edit, not a PHP edit.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Admin_Alcohol
 */
final class HNC_Admin_Alcohol {


	/**
	 * Render the alcohol queue page.
	 *
	 * @return void
	 */
	public static function render() {
		if ( ! current_user_can( 'hnc_moderate_alcohol' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'helpnagaland-core' ) );
		}

		$categories_raw = get_option( 'hnc_alcohol_categories', '{}' );
		$categories     = json_decode( (string) $categories_raw, true );
		$categories     = is_array( $categories ) ? $categories : array();

		$districts_raw = get_option( 'hnc_districts', '[]' );
		$districts     = json_decode( (string) $districts_raw, true );
		$districts     = is_array( $districts ) ? $districts : array();

		?>
		<div class="wrap hnc-wrap" data-hnc-screen="alcohol">
			<h1 class="hnc-title">
				<?php esc_html_e( 'Alcohol Queue', 'helpnagaland-core' ); ?>
				<span class="hnc-pill hnc-pill-green">ALCOHOL</span>
			</h1>

			<div class="hnc-filter-bar">
				<label>
					<span><?php esc_html_e( 'Status', 'helpnagaland-core' ); ?></span>
					<select data-hnc-filter="status">
						<option value="pending" selected><?php esc_html_e( 'Pending', 'helpnagaland-core' ); ?></option>
						<option value="approved"><?php esc_html_e( 'Approved', 'helpnagaland-core' ); ?></option>
						<option value="rejected"><?php esc_html_e( 'Rejected', 'helpnagaland-core' ); ?></option>
						<option value="hold"><?php esc_html_e( 'On hold', 'helpnagaland-core' ); ?></option>
						<option value="archived"><?php esc_html_e( 'Archived', 'helpnagaland-core' ); ?></option>
					</select>
				</label>

				<label>
					<span><?php esc_html_e( 'District', 'helpnagaland-core' ); ?></span>
					<select data-hnc-filter="district">
						<option value=""><?php esc_html_e( 'All districts', 'helpnagaland-core' ); ?></option>
						<?php foreach ( $districts as $d ) : ?>
							<option value="<?php echo esc_attr( $d ); ?>"><?php echo esc_html( $d ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>

				<label>
					<span><?php esc_html_e( 'Category', 'helpnagaland-core' ); ?></span>
					<select data-hnc-filter="category">
						<option value=""><?php esc_html_e( 'All categories', 'helpnagaland-core' ); ?></option>
						<?php foreach ( $categories as $key => $label ) : ?>
							<option value="<?php echo esc_attr( (string) $key ); ?>"><?php echo esc_html( (string) $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>

				<label>
					<span><?php esc_html_e( 'Sort', 'helpnagaland-core' ); ?></span>
					<select data-hnc-filter="sort">
						<option value="asc" selected><?php esc_html_e( 'Oldest first', 'helpnagaland-core' ); ?></option>
						<option value="desc"><?php esc_html_e( 'Newest first', 'helpnagaland-core' ); ?></option>
					</select>
				</label>

				<button type="button" class="button button-primary" data-hnc-action="refresh">
					<?php esc_html_e( 'Refresh', 'helpnagaland-core' ); ?>
				</button>
			</div>

			<div class="hnc-queue-meta">
				<span data-hnc-queue-count>—</span>
			</div>

			<div class="hnc-queue" data-hnc-queue>
				<div class="hnc-empty"><?php esc_html_e( 'Loading queue...', 'helpnagaland-core' ); ?></div>
			</div>

			<div class="hnc-pager">
				<button type="button" class="button" data-hnc-action="page-prev" disabled>← <?php esc_html_e( 'Prev', 'helpnagaland-core' ); ?></button>
				<span data-hnc-page-label>—</span>
				<button type="button" class="button" data-hnc-action="page-next">
					<?php esc_html_e( 'Next', 'helpnagaland-core' ); ?> →
				</button>
			</div>

			<!-- Detail modal gets populated by admin.js -->
			<div class="hnc-modal" data-hnc-modal hidden>
				<div class="hnc-modal-backdrop" data-hnc-modal-close></div>
				<div class="hnc-modal-panel">
					<button type="button" class="hnc-modal-x" data-hnc-modal-close aria-label="Close">&times;</button>
					<div class="hnc-modal-body" data-hnc-modal-body>—</div>
				</div>
			</div>
		</div>
		<?php
	}
}
