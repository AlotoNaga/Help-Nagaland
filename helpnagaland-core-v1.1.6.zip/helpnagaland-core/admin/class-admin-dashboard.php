<?php
/**
 * Admin Dashboard screen: landing page.
 *
 * Shows at-a-glance counts, recent audit events, and the killswitch
 * control for users with the operate_killswitch capability. All data
 * is loaded client-side from the REST endpoints so this PHP is a thin
 * shell.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Admin_Dashboard
 */
final class HNC_Admin_Dashboard {


	/**
	 * Render the dashboard page.
	 *
	 * @return void
	 */
	public static function render() {
		?>
		<div class="wrap hnc-wrap" data-hnc-screen="dashboard">
			<h1 class="hnc-title">
				<span class="hnc-logo">CN</span>
				<?php esc_html_e( 'Clean Nagaland', 'helpnagaland-core' ); ?>
			</h1>
			<p class="hnc-subtitle"><?php esc_html_e( 'Civic platform for alcohol and drug activity reporting in Nagaland.', 'helpnagaland-core' ); ?></p>

			<div class="hnc-grid hnc-grid-3">
				<div class="hnc-card hnc-card-stat" data-hnc-stat="alcohol-pending">
					<div class="hnc-stat-label"><?php esc_html_e( 'Alcohol pending', 'helpnagaland-core' ); ?></div>
					<div class="hnc-stat-value" data-hnc-value>—</div>
					<a class="hnc-card-link" href="<?php echo esc_url( admin_url( 'admin.php?page=' . HNC_Admin_Menu::MENU_SLUG_ALCOHOL ) ); ?>">
						<?php esc_html_e( 'Review →', 'helpnagaland-core' ); ?>
					</a>
				</div>
				<div class="hnc-card hnc-card-stat" data-hnc-stat="drug-pending">
					<div class="hnc-stat-label"><?php esc_html_e( 'Drug pending', 'helpnagaland-core' ); ?></div>
					<div class="hnc-stat-value" data-hnc-value>—</div>
					<a class="hnc-card-link" href="<?php echo esc_url( admin_url( 'admin.php?page=' . HNC_Admin_Menu::MENU_SLUG_DRUG ) ); ?>">
						<?php esc_html_e( 'Review →', 'helpnagaland-core' ); ?>
					</a>
				</div>
				<div class="hnc-card hnc-card-stat" data-hnc-stat="alcohol-approved">
					<div class="hnc-stat-label"><?php esc_html_e( 'Alcohol pins visible', 'helpnagaland-core' ); ?></div>
					<div class="hnc-stat-value" data-hnc-value>—</div>
					<a class="hnc-card-link" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank">
						<?php esc_html_e( 'Public map →', 'helpnagaland-core' ); ?>
					</a>
				</div>
			</div>

			<?php if ( current_user_can( 'hnc_operate_killswitch' ) ) : ?>
			<div class="hnc-card hnc-card-killswitch" data-hnc-killswitch>
				<div class="hnc-card-header">
					<h2><?php esc_html_e( 'Killswitch', 'helpnagaland-core' ); ?></h2>
					<div class="hnc-killswitch-state" data-hnc-killswitch-state>—</div>
				</div>
				<p class="hnc-help-text">
					<?php esc_html_e( 'The killswitch pauses every public endpoint (submissions, map reads, status lookups). Use this if a coordinated spam campaign, legal emergency, or urgent safety issue requires shutting down intake. Admin remains fully accessible.', 'helpnagaland-core' ); ?>
				</p>
				<div class="hnc-killswitch-actions">
					<button type="button" class="button button-danger" data-hnc-action="killswitch-activate">
						<?php esc_html_e( 'Activate killswitch', 'helpnagaland-core' ); ?>
					</button>
					<button type="button" class="button" data-hnc-action="killswitch-deactivate">
						<?php esc_html_e( 'Deactivate killswitch', 'helpnagaland-core' ); ?>
					</button>
				</div>
				<div class="hnc-killswitch-message" data-hnc-killswitch-message></div>
			</div>
			<?php endif; ?>

			<div class="hnc-card">
				<div class="hnc-card-header">
					<h2><?php esc_html_e( 'Recent activity', 'helpnagaland-core' ); ?></h2>
					<?php if ( current_user_can( 'hnc_view_audit' ) ) : ?>
					<a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=' . HNC_Admin_Menu::MENU_SLUG_AUDIT ) ); ?>">
						<?php esc_html_e( 'Full audit log', 'helpnagaland-core' ); ?>
					</a>
					<?php endif; ?>
				</div>
				<div class="hnc-recent-activity" data-hnc-recent-activity>
					<div class="hnc-empty"><?php esc_html_e( 'Loading recent events...', 'helpnagaland-core' ); ?></div>
				</div>
			</div>

			<div class="hnc-card">
				<h2><?php esc_html_e( 'Health', 'helpnagaland-core' ); ?></h2>
				<div class="hnc-health" data-hnc-health>
					<div class="hnc-empty">—</div>
				</div>
			</div>
		</div>
		<?php
	}
}
