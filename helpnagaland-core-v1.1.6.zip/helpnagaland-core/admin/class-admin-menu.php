<?php
/**
 * Admin menu: register every admin page and load assets.
 *
 * The plugin adds one top-level menu, "Clean Nagaland", with seven
 * sub-pages. Each sub-page is gated on an HNC capability so a moderator
 * who only has one responsibility sees only the menus they can use.
 *
 * This class is the single place that owns:
 *
 *   - The top-level menu registration (admin_menu hook).
 *   - The sub-page registrations with capability gates.
 *   - Asset enqueue for the plugin's admin pages only (never polluting
 *     other admin screens).
 *   - The localized config object that admin.js reads at boot time
 *     (REST namespace, nonce, current user caps, i18n strings).
 *
 * Every screen class follows the same pattern: a static `render()`
 * method that outputs the HTML shell. admin.js looks at
 * data-hnc-screen on the root element and dispatches to a per-screen
 * init function.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Admin_Menu
 */
final class HNC_Admin_Menu {


	const MENU_SLUG_ROOT              = 'helpnagaland';
	const MENU_SLUG_DASHBOARD         = 'helpnagaland';
	const MENU_SLUG_ALCOHOL           = 'helpnagaland-alcohol';
	const MENU_SLUG_DRUG              = 'helpnagaland-drug';
	const MENU_SLUG_VAULT             = 'helpnagaland-vault';
	const MENU_SLUG_TRANSPARENCY      = 'helpnagaland-transparency';
	const MENU_SLUG_AUDIT             = 'helpnagaland-audit';
	const MENU_SLUG_SETTINGS          = 'helpnagaland-settings';
	const MENU_SLUG_PARTNERS          = 'helpnagaland-partners';
	const MENU_SLUG_PARTNER_DASHBOARD = 'helpnagaland-partner-dashboard';


	/* ------------------------------------------------------------------
	 * BOOTSTRAP
	 * ------------------------------------------------------------------ */

	/**
	 * Wire menu registration and asset enqueue.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_notices', array( __CLASS__, 'maybe_show_killswitch_banner' ) );
	}


	/* ------------------------------------------------------------------
	 * MENU REGISTRATION
	 * ------------------------------------------------------------------ */

	/**
	 * Register the top-level menu and every sub-page.
	 *
	 * Each sub-page is capability-gated. A user without the capability
	 * simply does not see the menu item. WordPress also refuses to
	 * render the page body, so this is a belt-and-braces check.
	 *
	 * @return void
	 */
	public static function register_menu() {
		$root_cap = self::pick_root_cap();
		if ( '' === $root_cap ) {
			return; // Current user has zero HNC caps. Do not render any menu.
		}

		add_menu_page(
			__( 'Clean Nagaland', 'helpnagaland-core' ),
			__( 'Clean Nagaland', 'helpnagaland-core' ),
			$root_cap,
			self::MENU_SLUG_ROOT,
			array( 'HNC_Admin_Dashboard', 'render' ),
			'dashicons-shield-alt',
			26
		);

		add_submenu_page(
			self::MENU_SLUG_ROOT,
			__( 'Dashboard', 'helpnagaland-core' ),
			__( 'Dashboard', 'helpnagaland-core' ),
			$root_cap,
			self::MENU_SLUG_DASHBOARD,
			array( 'HNC_Admin_Dashboard', 'render' )
		);

		add_submenu_page(
			self::MENU_SLUG_ROOT,
			__( 'Alcohol Queue', 'helpnagaland-core' ),
			__( 'Alcohol Queue', 'helpnagaland-core' ),
			'hnc_moderate_alcohol',
			self::MENU_SLUG_ALCOHOL,
			array( 'HNC_Admin_Alcohol', 'render' )
		);

		add_submenu_page(
			self::MENU_SLUG_ROOT,
			__( 'Drug Queue', 'helpnagaland-core' ),
			__( 'Drug Queue', 'helpnagaland-core' ),
			'hnc_moderate_drug',
			self::MENU_SLUG_DRUG,
			array( 'HNC_Admin_Drug', 'render' )
		);

		add_submenu_page(
			self::MENU_SLUG_ROOT,
			__( 'Phone Vault', 'helpnagaland-core' ),
			__( 'Phone Vault', 'helpnagaland-core' ),
			'hnc_manage_vault',
			self::MENU_SLUG_VAULT,
			array( 'HNC_Admin_Vault', 'render' )
		);

		add_submenu_page(
			self::MENU_SLUG_ROOT,
			__( 'Transparency', 'helpnagaland-core' ),
			__( 'Transparency', 'helpnagaland-core' ),
			'hnc_publish_transparency',
			self::MENU_SLUG_TRANSPARENCY,
			array( 'HNC_Admin_Transparency', 'render' )
		);

		add_submenu_page(
			self::MENU_SLUG_ROOT,
			__( 'Audit Log', 'helpnagaland-core' ),
			__( 'Audit Log', 'helpnagaland-core' ),
			'hnc_view_audit',
			self::MENU_SLUG_AUDIT,
			array( 'HNC_Admin_Audit', 'render' )
		);

		add_submenu_page(
			self::MENU_SLUG_ROOT,
			__( 'Partners', 'helpnagaland-core' ),
			__( 'Partners', 'helpnagaland-core' ),
			'hnc_manage_partners',
			self::MENU_SLUG_PARTNERS,
			array( 'HNC_Admin_Partners', 'render' )
		);

		// Partner Dashboard is visible ONLY to users with hnc_partner_access.
		// Internal moderators typically don't have that cap, so they won't
		// see the submenu. Partners, on the other hand, won't see any of
		// the cap-gated moderator menus above because they lack those caps.
		add_submenu_page(
			self::MENU_SLUG_ROOT,
			__( 'Partner Dashboard', 'helpnagaland-core' ),
			__( 'Partner Dashboard', 'helpnagaland-core' ),
			'hnc_partner_access',
			self::MENU_SLUG_PARTNER_DASHBOARD,
			array( 'HNC_Admin_Partner_Dashboard', 'render' )
		);

		add_submenu_page(
			self::MENU_SLUG_ROOT,
			__( 'Settings', 'helpnagaland-core' ),
			__( 'Settings', 'helpnagaland-core' ),
			'hnc_manage_settings',
			self::MENU_SLUG_SETTINGS,
			array( 'HNC_Admin_Settings', 'render' )
		);
	}


	/* ------------------------------------------------------------------
	 * ASSETS
	 * ------------------------------------------------------------------ */

	/**
	 * Enqueue the plugin's admin CSS and JS, only on HNC admin pages.
	 *
	 * @param string $hook_suffix The current admin page hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook_suffix ) {
		if ( ! self::is_hnc_admin_page( $hook_suffix ) ) {
			return;
		}

		wp_enqueue_style(
			'hnc-admin',
			HNC_URL . 'admin/css/admin.css',
			array(),
			HNC_VERSION
		);

		wp_enqueue_script(
			'hnc-admin',
			HNC_URL . 'admin/js/admin.js',
			array(),
			HNC_VERSION,
			true
		);

		wp_localize_script(
			'hnc-admin',
			'HNC_CONFIG',
			array(
				'rest_url'   => esc_url_raw( rest_url( HNC_API_NAMESPACE . '/' ) ),
				'nonce'      => wp_create_nonce( 'wp_rest' ),
				'caps'       => self::current_user_hnc_caps(),
				'version'    => HNC_VERSION,
				'site_url'   => esc_url_raw( site_url() ),
				'killswitch' => class_exists( 'HNC_Killswitch' ) ? (bool) HNC_Killswitch::is_active() : false,
				'menu'       => array(
					'dashboard'    => admin_url( 'admin.php?page=' . self::MENU_SLUG_DASHBOARD ),
					'alcohol'      => admin_url( 'admin.php?page=' . self::MENU_SLUG_ALCOHOL ),
					'drug'         => admin_url( 'admin.php?page=' . self::MENU_SLUG_DRUG ),
					'vault'        => admin_url( 'admin.php?page=' . self::MENU_SLUG_VAULT ),
					'transparency' => admin_url( 'admin.php?page=' . self::MENU_SLUG_TRANSPARENCY ),
					'audit'        => admin_url( 'admin.php?page=' . self::MENU_SLUG_AUDIT ),
					'settings'     => admin_url( 'admin.php?page=' . self::MENU_SLUG_SETTINGS ),
				),
				'i18n'       => self::i18n_strings(),
			)
		);
	}


	/* ------------------------------------------------------------------
	 * KILLSWITCH BANNER
	 * ------------------------------------------------------------------ */

	/**
	 * Show a persistent banner when the killswitch is active, on every
	 * HNC admin page. The banner links to the dashboard where the
	 * moderator can lift it.
	 *
	 * @return void
	 */
	public static function maybe_show_killswitch_banner() {
		if ( ! class_exists( 'HNC_Killswitch' ) || ! HNC_Killswitch::is_active() ) {
			return;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen ) {
			return;
		}
		$id = (string) $screen->id;
		if ( false === strpos( $id, 'helpnagaland' ) ) {
			return;
		}

		$msg = esc_html__( 'Public endpoints are currently paused via the killswitch.', 'helpnagaland-core' );
		$url = esc_url( admin_url( 'admin.php?page=' . self::MENU_SLUG_DASHBOARD ) );

		echo '<div class="notice notice-error hnc-killswitch-notice" style="border-left-color:#dc2626;">';
		echo '<p><strong>' . esc_html__( 'Platform paused:', 'helpnagaland-core' ) . '</strong> '
			. $msg
			. ' <a href="' . $url . '">' . esc_html__( 'Manage', 'helpnagaland-core' ) . '</a></p>';
		echo '</div>';
	}


	/* ------------------------------------------------------------------
	 * INTERNAL HELPERS
	 * ------------------------------------------------------------------ */

	/**
	 * Pick the capability that gates access to the top-level menu.
	 * Returns the first HNC capability the current user has, or empty.
	 * This avoids showing "Clean Nagaland" in the menu to users who
	 * cannot use any sub-page.
	 *
	 * @return string
	 */
	private static function pick_root_cap() {
		$candidates = array(
			'hnc_admin',
			'hnc_moderate_alcohol',
			'hnc_moderate_drug',
			'hnc_view_audit',
			'hnc_manage_vault',
			'hnc_publish_transparency',
			'hnc_manage_settings',
			'hnc_operate_killswitch',
			'hnc_manage_partners',
			'hnc_partner_access',
		);
		foreach ( $candidates as $cap ) {
			if ( current_user_can( $cap ) ) {
				return $cap;
			}
		}
		return '';
	}

	/**
	 * Return the HNC capabilities the current user has, for client-side
	 * UI gating. The JS uses this to hide buttons the user cannot use,
	 * independent of the server-side REST capability check that always
	 * runs regardless.
	 *
	 * @return array
	 */
	private static function current_user_hnc_caps() {
		$all = array(
			'hnc_admin',
			'hnc_moderate_alcohol',
			'hnc_moderate_drug',
			'hnc_view_audit',
			'hnc_manage_vault',
			'hnc_reveal_phone',
			'hnc_forward_drug',
			'hnc_publish_transparency',
			'hnc_manage_settings',
			'hnc_operate_killswitch',
			'hnc_manage_partners',
			'hnc_partner_access',
		);
		$out = array();
		foreach ( $all as $cap ) {
			if ( current_user_can( $cap ) ) {
				$out[] = $cap;
			}
		}
		return $out;
	}

	/**
	 * Whether the current admin hook suffix is one of the HNC pages.
	 *
	 * @param string $hook Hook suffix.
	 * @return bool
	 */
	private static function is_hnc_admin_page( $hook ) {
		if ( ! is_string( $hook ) || '' === $hook ) {
			return false;
		}
		return ( false !== strpos( $hook, 'helpnagaland' ) );
	}

	/**
	 * Localized strings bundled into HNC_CONFIG.i18n for admin.js.
	 *
	 * Keeping all user-facing strings here means translators only need
	 * to work with PHP files. admin.js never emits hard-coded English.
	 *
	 * @return array
	 */
	private static function i18n_strings() {
		return array(
			'loading'               => __( 'Loading...', 'helpnagaland-core' ),
			'empty_queue'           => __( 'No reports match these filters.', 'helpnagaland-core' ),
			'confirm_approve'       => __( 'Approve this report?', 'helpnagaland-core' ),
			'confirm_reject'        => __( 'Reject this report? You will need to give a reason.', 'helpnagaland-core' ),
			'confirm_hold'          => __( 'Put this report on hold?', 'helpnagaland-core' ),
			'confirm_archive'       => __( 'Archive this report?', 'helpnagaland-core' ),
			'confirm_resolve'       => __( 'Mark this report as resolved? Media will be deleted.', 'helpnagaland-core' ),
			'confirm_verify'        => __( 'Verify this pin as operator-visited? Report count becomes at least 3.', 'helpnagaland-core' ),
			'confirm_delete_vault'  => __( 'Delete this phone vault entry? This cannot be undone.', 'helpnagaland-core' ),
			'confirm_killswitch_on' => __( 'Activate the killswitch? This pauses all public endpoints.', 'helpnagaland-core' ),
			'confirm_killswitch_off'=> __( 'Deactivate the killswitch and resume public endpoints?', 'helpnagaland-core' ),
			'action_failed'         => __( 'Action failed.', 'helpnagaland-core' ),
			'action_succeeded'      => __( 'Action succeeded.', 'helpnagaland-core' ),
			'reveal_confirm_text'   => __( 'I confirm I have captured the reporter\'s second consent for this specific purpose.', 'helpnagaland-core' ),
			'reveal_reason_label'   => __( 'Reason for revealing (min 5 characters):', 'helpnagaland-core' ),
			'unlock_label'          => __( 'Enter vault passphrase to unlock:', 'helpnagaland-core' ),
			'vault_locked'          => __( 'Vault is locked', 'helpnagaland-core' ),
			'vault_unlocked'        => __( 'Vault unlocked', 'helpnagaland-core' ),
			'rate_limited'          => __( 'You are doing that too fast. Please wait.', 'helpnagaland-core' ),
			'forbidden'             => __( 'You do not have permission.', 'helpnagaland-core' ),
			'expired_session'       => __( 'Your session expired. Refresh the page.', 'helpnagaland-core' ),
		);
	}
}
