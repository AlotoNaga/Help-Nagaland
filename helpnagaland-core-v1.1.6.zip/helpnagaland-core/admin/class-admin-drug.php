<?php
/**
 * Admin Drug queue screen.
 *
 * Mirrors the alcohol queue but with drug-specific affordances:
 *   - No public map preview, ever.
 *   - Severity filter (1-5) in addition to status, district, category.
 *   - Resolve action (unique to drug pipeline).
 *   - Forward to partner action (requires separate capability).
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Admin_Drug
 */
final class HNC_Admin_Drug {


	/**
	 * Render the drug queue page.
	 *
	 * @return void
	 */
	public static function render() {
		if ( ! current_user_can( 'hnc_moderate_drug' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'helpnagaland-core' ) );
		}

		$categories_raw = get_option( 'hnc_drug_categories', '{}' );
		$categories     = json_decode( (string) $categories_raw, true );
		$categories     = is_array( $categories ) ? $categories : array();

		$districts_raw = get_option( 'hnc_districts', '[]' );
		$districts     = json_decode( (string) $districts_raw, true );
		$districts     = is_array( $districts ) ? $districts : array();

		$can_forward = current_user_can( 'hnc_forward_drug' );

		?>
		<div class="wrap hnc-wrap" data-hnc-screen="drug" data-hnc-can-forward="<?php echo $can_forward ? '1' : '0'; ?>">
			<h1 class="hnc-title">
				<?php esc_html_e( 'Drug Queue', 'helpnagaland-core' ); ?>
				<span class="hnc-pill hnc-pill-red">CONFIDENTIAL</span>
			</h1>

			<p class="hnc-warning-banner">
				<?php esc_html_e( 'Drug reports are never public. Everything below is for moderator eyes only. Nothing here appears on the map, in transparency exports, or anywhere else a non-authenticated user can see.', 'helpnagaland-core' ); ?>
			</p>

			<div class="hnc-filter-bar">
				<label>
					<span><?php esc_html_e( 'Status', 'helpnagaland-core' ); ?></span>
					<select data-hnc-filter="status">
						<option value="pending" selected><?php esc_html_e( 'Pending', 'helpnagaland-core' ); ?></option>
						<option value="approved"><?php esc_html_e( 'Approved', 'helpnagaland-core' ); ?></option>
						<option value="hold"><?php esc_html_e( 'On hold', 'helpnagaland-core' ); ?></option>
						<option value="resolved"><?php esc_html_e( 'Resolved', 'helpnagaland-core' ); ?></option>
						<option value="rejected"><?php esc_html_e( 'Rejected', 'helpnagaland-core' ); ?></option>
						<option value="archived"><?php esc_html_e( 'Archived', 'helpnagaland-core' ); ?></option>
					</select>
				</label>

				<label>
					<span><?php esc_html_e( 'District', 'helpnagaland-core' ); ?></span>
					<select data-hnc-filter="district">
						<option value=""><?php esc_html_e( 'All districts', 'helpnagaland-core' ); ?></option>
						<?php foreach ( $districts as $d ) : ?>
							<option value="<?php echo esc_attr( $d ); ?>"><?php echo esc_html( $d ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>

				<label>
					<span><?php esc_html_e( 'Category', 'helpnagaland-core' ); ?></span>
					<select data-hnc-filter="category">
						<option value=""><?php esc_html_e( 'All categories', 'helpnagaland-core' ); ?></option>
						<?php foreach ( $categories as $key => $label ) : ?>
							<option value="<?php echo esc_attr( (string) $key ); ?>"><?php echo esc_html( (string) $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>

				<label>
					<span><?php esc_html_e( 'Min severity', 'helpnagaland-core' ); ?></span>
					<select data-hnc-filter="severity_min">
						<option value="0"><?php esc_html_e( 'Any', 'helpnagaland-core' ); ?></option>
						<option value="1">≥ 1</option>
						<option value="2">≥ 2</option>
						<option value="3">≥ 3</option>
						<option value="4">≥ 4 (High)</option>
						<option value="5">5 (Critical only)</option>
					</select>
				</label>

				<button type="button" class="button button-primary" data-hnc-action="refresh">
					<?php esc_html_e( 'Refresh', 'helpnagaland-core' ); ?>
				</button>
			</div>

			<div class="hnc-queue-meta">
				<span data-hnc-queue-count>—</span>
			</div>

			<div class="hnc-queue" data-hnc-queue>
				<div class="hnc-empty"><?php esc_html_e( 'Loading queue...', 'helpnagaland-core' ); ?></div>
			</div>

			<div class="hnc-pager">
				<button type="button" class="button" data-hnc-action="page-prev" disabled>← <?php esc_html_e( 'Prev', 'helpnagaland-core' ); ?></button>
				<span data-hnc-page-label>—</span>
				<button type="button" class="button" data-hnc-action="page-next">
					<?php esc_html_e( 'Next', 'helpnagaland-core' ); ?> →
				</button>
			</div>

			<div class="hnc-modal" data-hnc-modal hidden>
				<div class="hnc-modal-backdrop" data-hnc-modal-close></div>
				<div class="hnc-modal-panel">
					<button type="button" class="hnc-modal-x" data-hnc-modal-close aria-label="Close">&times;</button>
					<div class="hnc-modal-body" data-hnc-modal-body>—</div>
				</div>
			</div>
		</div>
		<?php
	}
}
