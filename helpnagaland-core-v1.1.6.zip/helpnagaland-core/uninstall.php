<?php
/**
 * Plugin uninstall handler.
 *
 * This file is executed only when the admin deletes the plugin from the
 * WP-Admin plugins screen. It is NOT executed on deactivate.
 *
 * ========================================================================
 * SAFETY PHILOSOPHY
 * ========================================================================
 *
 * Clean Nagaland stores sensitive civic reports. Accidentally deleting them
 * would be catastrophic. Even a well meaning admin who deletes the plugin
 * to "move it to a different directory" must not lose data as a side effect.
 *
 * Therefore this uninstall script is a NO-OP by default.
 *
 * For actual data destruction to occur, the admin must have explicitly set
 * the option hnc_allow_data_deletion_on_uninstall to 1, via a deliberate
 * action inside the Danger Zone section of the plugin settings screen
 * (added in Phase 7).
 *
 * Without that opt-in:
 *   - Tables are NOT dropped.
 *   - Options are NOT deleted.
 *   - Roles and capabilities are NOT removed.
 *   - Uploads directory is NOT deleted.
 *
 * The admin can always re-install the plugin to regain access to their data.
 *
 * ========================================================================
 * WHAT HAPPENS WHEN OPT IN IS TRUE
 * ========================================================================
 *
 * With opt-in, this script:
 *   1. Drops every HNC table.
 *   2. Deletes every option with the hnc_ prefix.
 *   3. Removes every HNC capability from the administrator role.
 *   4. Deletes the HNC custom roles.
 *   5. Recursively deletes wp-content/uploads/hnc-private/ and all files inside.
 *
 * After this script runs with opt-in, no trace of Clean Nagaland data
 * remains in the database or on the filesystem.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

// Block direct web access. This file must only run from the WordPress uninstall handler.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Also guard against running outside of a WordPress context.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/* ============================================================
 * OPT IN CHECK
 * ============================================================
 *
 * The option must be set to the integer 1 or the string "1". Any other
 * value, including missing option, empty string, zero, boolean false, or
 * "yes", causes this uninstall to take NO destructive action.
 *
 * This deliberately strict comparison prevents typos from becoming data
 * loss events.
 */

$hnc_uninstall_allow = get_option( 'hnc_allow_data_deletion_on_uninstall', 0 );

if ( (int) $hnc_uninstall_allow !== 1 ) {
	// Not opted in. Leave everything intact.
	return;
}


/* ============================================================
 * LOAD PLUGIN CLASSES (if available) FOR CLEAN REMOVAL
 * ============================================================
 *
 * If the plugin files are still on disk at this point (they usually are,
 * because WordPress calls uninstall.php before deleting plugin files),
 * load the Schema and Roles classes so we can use their removal methods.
 * If the files are missing, fall back to manual SQL and manual role cleanup.
 */

$hnc_plugin_dir = plugin_dir_path( __FILE__ );

$hnc_schema_file = $hnc_plugin_dir . 'includes/class-hnc-schema.php';
$hnc_roles_file  = $hnc_plugin_dir . 'includes/class-hnc-roles.php';

if ( file_exists( $hnc_schema_file ) ) {
	require_once $hnc_schema_file;
}
if ( file_exists( $hnc_roles_file ) ) {
	require_once $hnc_roles_file;
}


/* ============================================================
 * 1. DROP ALL TABLES
 * ============================================================ */

global $wpdb;

if ( class_exists( 'HNC_Schema' ) ) {
	HNC_Schema::drop_all();
} else {
	// Fallback: hardcoded table list. Kept in sync with HNC_Schema::all_tables()
	// manually. If you change table names, update this list too.
	$hnc_fallback_tables = array(
		$wpdb->prefix . 'hnc_alcohol_reports',
		$wpdb->prefix . 'hnc_drug_reports',
		$wpdb->prefix . 'hnc_phone_vault',
		$wpdb->prefix . 'hnc_audit_log',
		$wpdb->prefix . 'hnc_device_fingerprints',
		$wpdb->prefix . 'hnc_transparency_snapshots',
		$wpdb->prefix . 'hnc_partners',
	);
	foreach ( $hnc_fallback_tables as $hnc_table ) {
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( "DROP TABLE IF EXISTS {$hnc_table}" );
	}
}


/* ============================================================
 * 2. DELETE ALL OPTIONS
 * ============================================================
 *
 * Delete both the known explicit options AND a LIKE sweep for anything
 * starting with hnc_ in the options table.
 */

$hnc_known_options = array(
	'hnc_version',
	'hnc_db_version',
	'hnc_activated_at',
	'hnc_deactivated_at',
	'hnc_killswitch_active',
	'hnc_maintenance_mode',
	'hnc_maintenance_message',
	'hnc_rate_limit_per_device_24h',
	'hnc_rate_limit_per_ip_hour',
	'hnc_min_submit_seconds',
	'hnc_photo_retention_days',
	'hnc_alcohol_archive_months',
	'hnc_alcohol_rejected_purge_days',
	'hnc_drug_archive_months',
	'hnc_drug_rejected_purge_hours',
	'hnc_phone_retention_days_after_resolved',
	'hnc_phone_retention_days_max',
	'hnc_audit_retention_years',
	'hnc_device_retention_months',
	'hnc_ip_retention_days',
	'hnc_ip_daily_salt',
	'hnc_ip_salt_rotated_at',
	'hnc_device_hash_salt',
	'hnc_snap_grid_meters',
	'hnc_gps_tolerance_meters',
	'hnc_photo_freshness_max_seconds',
	'hnc_nagaland_bounds',
	'hnc_districts',
	'hnc_alcohol_categories',
	'hnc_drug_categories',
	'hnc_time_patterns',
	'hnc_vault_session_minutes',
	'hnc_vault_passphrase_hash',
	'hnc_vault_passphrase_set_at',
	'hnc_transparency_auto_publish',
	'hnc_transparency_publish_day_of_month',
	'hnc_allow_data_deletion_on_uninstall',
	'hnc_stats_alcohol_pending',
	'hnc_stats_drug_pending',
	'hnc_stats_alcohol_approved_total',
	'hnc_stats_drug_approved_total',
);

foreach ( $hnc_known_options as $hnc_option_key ) {
	delete_option( $hnc_option_key );
}

// Belt and braces: sweep anything else starting with hnc_ that we may have missed.
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
$wpdb->query(
	"DELETE FROM {$wpdb->options} WHERE option_name LIKE 'hnc\\_%' ESCAPE '\\\\'"
);

// Also clear any transients.
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
$wpdb->query(
	"DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_hnc\\_%' ESCAPE '\\\\' OR option_name LIKE '\\_transient\\_timeout\\_hnc\\_%' ESCAPE '\\\\'"
);


/* ============================================================
 * 3. REMOVE ROLES AND CAPABILITIES
 * ============================================================ */

if ( class_exists( 'HNC_Roles' ) ) {
	HNC_Roles::remove_all();
} else {
	// Fallback: manual cap and role removal.
	$hnc_fallback_caps = array(
		'hnc_admin',
		'hnc_moderate_alcohol',
		'hnc_moderate_drug',
		'hnc_view_audit',
		'hnc_manage_vault',
		'hnc_reveal_phone',
		'hnc_forward_drug',
		'hnc_manage_partners',
		'hnc_manage_settings',
		'hnc_operate_killswitch',
		'hnc_publish_transparency',
		'hnc_partner_access',
	);

	$hnc_admin_role = get_role( 'administrator' );
	if ( $hnc_admin_role ) {
		foreach ( $hnc_fallback_caps as $hnc_cap ) {
			$hnc_admin_role->remove_cap( $hnc_cap );
		}
	}
	remove_role( 'hnc_moderator' );
	remove_role( 'hnc_partner' );
}


/* ============================================================
 * 4. DELETE PROTECTED UPLOADS DIRECTORY
 * ============================================================ */

$hnc_upload_dir = wp_upload_dir();
if ( empty( $hnc_upload_dir['error'] ) ) {
	$hnc_base = trailingslashit( $hnc_upload_dir['basedir'] ) . 'hnc-private';
	if ( is_dir( $hnc_base ) ) {
		hnc_uninstall_rrmdir( $hnc_base );
	}
}


/* ============================================================
 * 5. CLEAN SCHEDULED CRON EVENTS (belt and braces)
 * ============================================================ */

$hnc_cron_hooks = array(
	'hnc_retention_sweep_daily',
	'hnc_alcohol_photo_cleanup',
	'hnc_alcohol_archive_old_pins',
	'hnc_alcohol_purge_rejected',
	'hnc_drug_media_cleanup',
	'hnc_drug_archive_old',
	'hnc_drug_purge_rejected',
	'hnc_phone_vault_cleanup',
	'hnc_device_fingerprint_cleanup',
	'hnc_ip_salt_rotate_daily',
	'hnc_transparency_auto_publish_monthly',
	'hnc_audit_log_archive_yearly',
);

foreach ( $hnc_cron_hooks as $hnc_hook ) {
	wp_clear_scheduled_hook( $hnc_hook );
}


/* ============================================================
 * HELPER: Recursive directory removal
 * ============================================================
 *
 * PHP has no built in rrmdir. We implement it defensively, skipping
 * symlinks (to avoid escaping the intended tree), and catching errors
 * silently since nothing useful can be done at this point.
 */

/**
 * Recursively remove a directory and all its contents.
 *
 * @param string $dir Absolute path to directory.
 * @return void
 */
function hnc_uninstall_rrmdir( $dir ) {
	if ( ! is_dir( $dir ) || is_link( $dir ) ) {
		return;
	}

	$items = @scandir( $dir ); // phpcs:ignore
	if ( ! is_array( $items ) ) {
		return;
	}

	foreach ( $items as $item ) {
		if ( '.' === $item || '..' === $item ) {
			continue;
		}
		$path = $dir . DIRECTORY_SEPARATOR . $item;

		if ( is_link( $path ) ) {
			// Never follow symlinks during delete. Just unlink the link itself.
			@unlink( $path ); // phpcs:ignore
			continue;
		}

		if ( is_dir( $path ) ) {
			hnc_uninstall_rrmdir( $path );
		} else {
			@unlink( $path ); // phpcs:ignore
		}
	}

	@rmdir( $dir ); // phpcs:ignore
}
